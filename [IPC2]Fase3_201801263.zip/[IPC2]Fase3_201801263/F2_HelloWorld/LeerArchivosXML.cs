﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Windows.Forms;
using System.Xml;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class LeerArchivosXML
    {
        public SqlConnection conexion;
        public string error;

        public LeerArchivosXML()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        public void leerXML(string Ruta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into ClienteEmpresa2 values (@NIT,@Nombre, @Direccion, @Telefono, @idContactoEncargado, @Correo,@LimiteCredito,@TiempoCredito,@idCodigoCategoria,@idEstadoCliente)";
            if (Ruta != null)
            {
                XmlReader xmlReader = XmlReader.Create(Ruta);
                           while (xmlReader.Read())
                {
                    if ((xmlReader.NodeType == XmlNodeType.Element) && (xmlReader.Name == "clientes"))
                    {
                        
                        if ((xmlReader.NodeType == XmlNodeType.Element) && (xmlReader.Name == "NIT"))
                        {
                            comando.Parameters.AddWithValue("@NIT", xmlReader.Value);
                        }
                        else if ((xmlReader.NodeType == XmlNodeType.Element) && (xmlReader.Name == "nombre"))
                        {
                            comando.Parameters.AddWithValue("@Nombre", xmlReader.Value);
                        }
                        else if ((xmlReader.NodeType == XmlNodeType.Element) && (xmlReader.Name == "direccion"))
                        {
                            comando.Parameters.AddWithValue("@Direccion", xmlReader.Value);
                        }
                        else if ((xmlReader.NodeType == XmlNodeType.Element) && (xmlReader.Name == "telefono"))
                        {
                            comando.Parameters.AddWithValue("@Telefono", xmlReader.Value);
                        }
                        else if ((xmlReader.NodeType == XmlNodeType.Element) && (xmlReader.Name == "personaContacto"))
                        {
                            comando.Parameters.AddWithValue("@idContactoEncargado", xmlReader.Value);
                        }
                        else if ((xmlReader.NodeType == XmlNodeType.Element) && (xmlReader.Name == "correoElectronico"))
                        {
                            comando.Parameters.AddWithValue("@Correo", xmlReader.Value);
                        }
                        else if ((xmlReader.NodeType == XmlNodeType.Element) && (xmlReader.Name == "limiteCredito"))
                        {
                            comando.Parameters.AddWithValue("@LimiteCredito", Convert.ToInt32(xmlReader.Value));
                        }
                        else if ((xmlReader.NodeType == XmlNodeType.Element) && (xmlReader.Name == "diasCredito"))
                        {
                            comando.Parameters.AddWithValue("@TiempoCredito", Convert.ToByte(xmlReader.Value));
                        }
                        else if ((xmlReader.NodeType == XmlNodeType.Element) && (xmlReader.Name == "categoria"))
                        {
                            SqlCommand comando2 = new SqlCommand();
                            comando2.Connection = conexion;
                            comando2.CommandText = "insert into CategoriaCliente2 values(@Abreviatura, @Descripcion)";
                            if ((xmlReader.NodeType == XmlNodeType.Element) && (xmlReader.Name == "codigo"))
                            {
                                comando2.Parameters.AddWithValue("@Abreviatura", xmlReader.Value);
                            }
                            else if ((xmlReader.NodeType == XmlNodeType.Element) && (xmlReader.Name == "descripcion"))
                            {
                                comando2.Parameters.AddWithValue("@Descripcion", xmlReader.Value);
                            }
                            comando2.ExecuteNonQuery();
                            comando2.Parameters.Clear();
                            SqlCommand comando3 = new SqlCommand();
                            comando3.Connection = conexion;
                            comando3.CommandText = "SELECT TOP 1 codigoCategoria FROM CategoriaCliente ORDER BY codigoCategoria DESC";                            
                            SqlDataReader registro = comando3.ExecuteReader();
                            comando.Parameters.Clear();
                            if (registro.Read())
                            {
                                comando.Parameters.AddWithValue("@idCodigoCategoria", registro.GetByte(0));                                 
                                registro.Close();                               
                            }
                        }
                        comando.Parameters.AddWithValue("@idEstadoCliente", 1);
                        comando.ExecuteNonQuery();
                        comando.Parameters.Clear();                       
                       
                    }
                    else
                    {
                        Console.WriteLine("No se ha cargado ningun archivo inicial");
                        MessageBox.Show("No se ha cargado ningun archivo inicial");
                    }
                }
                Console.ReadKey();
            }



        }

        public void leerXMLdoc(string Ruta) {
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load(Ruta);
            
            XmlNodeList xElementoClientes = xDoc.GetElementsByTagName("clientes");
            XmlNodeList xListaNit = ((XmlElement)xElementoClientes[0]).GetElementsByTagName("NIT");
            //XmlNodeList xListaNombew = ((XmlElement)xElementoClientes[0]).GetElementsByTagName("nombre");
            foreach (XmlElement nodo in xListaNit) {
                string xNIT= nodo.InnerText;
                Console.WriteLine(xNIT);
                
            }
        }

        public void prueba(string Ruta) {
            XmlReader xmlReader = XmlReader.Create(Ruta);
            while (xmlReader.Read()) {

            }
        }
    }
}