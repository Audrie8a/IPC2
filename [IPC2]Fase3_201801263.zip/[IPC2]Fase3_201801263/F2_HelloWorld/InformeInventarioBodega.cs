﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class InformeInventarioBodega
    {
        private byte idUbicacion;
        private string tipoGestion;
        private byte idGestion;
        private byte codigoProducto;
        private string ubicacion;
        private int Cantidad;
        private int Precio;

        public InformeInventarioBodega()
        {
        }

        public InformeInventarioBodega(byte idUbicacion, string tipoGestion, byte idGestion, byte codigoProducto, string ubicacion, int cantidad, int precio)
        {
            this.idUbicacion = idUbicacion;
            this.tipoGestion = tipoGestion;
            this.idGestion = idGestion;
            this.codigoProducto = codigoProducto;
            this.ubicacion = ubicacion;
            Cantidad = cantidad;
            Precio = precio;
        }

        public byte IdUbicacion { get => idUbicacion; set => idUbicacion = value; }
        public string TipoGestion { get => tipoGestion; set => tipoGestion = value; }
        public byte IdGestion { get => idGestion; set => idGestion = value; }
        public byte CodigoProducto { get => codigoProducto; set => codigoProducto = value; }
        public string Ubicacion { get => ubicacion; set => ubicacion = value; }
        public int Cantidad1 { get => Cantidad; set => Cantidad = value; }
        public int Precio1 { get => Precio; set => Precio = value; }
    }
}