﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Pasillo
    {
        private int numPasillo;
        private int largoPasillo;
        private int AnchoPasillo;
        private byte idBodega;

        public Pasillo()
        {
        }

        public Pasillo(int numPasillo, int largoPasillo, int anchoPasillo, byte idBodega)
        {
            this.numPasillo = numPasillo;
            this.largoPasillo = largoPasillo;
            AnchoPasillo = anchoPasillo;
            this.idBodega = idBodega;
        }

        public int NumPasillo { get => numPasillo; set => numPasillo = value; }
        public int LargoPasillo { get => largoPasillo; set => largoPasillo = value; }
        public int AnchoPasillo1 { get => AnchoPasillo; set => AnchoPasillo = value; }
        public byte IdBodega { get => idBodega; set => idBodega = value; }
    }
}