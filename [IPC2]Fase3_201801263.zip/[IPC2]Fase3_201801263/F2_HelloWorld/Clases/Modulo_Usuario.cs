﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Modulo_Usuario
    {
        private byte idModulo_Usuario;
        private byte idUsuario;
        private byte idPagoSus;

        public Modulo_Usuario()
        {
        }

        public Modulo_Usuario(byte idModulo_Usuario, byte idUsuario, byte idPagoSus)
        {
            this.idModulo_Usuario = idModulo_Usuario;
            this.idUsuario = idUsuario;
            this.idPagoSus = idPagoSus;
        }

        public byte IdModulo_Usuario { get => idModulo_Usuario; set => idModulo_Usuario = value; }
        public byte IdUsuario { get => idUsuario; set => idUsuario = value; }
        public byte IdPagoSus { get => idPagoSus; set => idPagoSus = value; }
    }
}