﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Empleado
    {
        private byte idEmpleado;
        private string Nombre;
        private string Puesto;

        public Empleado()
        {
        }

        public Empleado(byte idEmpleado, string nombre, string puesto)
        {
            this.idEmpleado = idEmpleado;
            Nombre = nombre;
            Puesto = puesto;
        }

        public byte IdEmpleado { get => idEmpleado; set => idEmpleado = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public string Puesto1 { get => Puesto; set => Puesto = value; }
    }
}