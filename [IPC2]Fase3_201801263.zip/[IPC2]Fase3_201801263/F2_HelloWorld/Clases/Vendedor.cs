﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Vendedor
    {
        private byte idEmpleado;
        private string Nombre;

        public Vendedor() { }
        public Vendedor(byte idEmpleado, string nombre)
        {
            this.idEmpleado = idEmpleado;
            Nombre = nombre;
        }

        public byte IdEmpleado { get => idEmpleado; set => idEmpleado = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
    }
}