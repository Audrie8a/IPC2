﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Contacto
    {
        private byte idContacto;
        private int DPI;
        private string Nombre;
        private string Celular;
        private string Telefono;
        private string Extension;
        private string Email;
        private string DireccionOff;
        private byte idCliente;
        private byte idTipoContacto;

        public Contacto()
        {
        }

        public Contacto(byte idContacto, int dPI, string nombre, string celular, string telefono, string extension, string email, string direccionOff, byte idCliente, byte idTipoContacto)
        {
            this.idContacto = idContacto;
            DPI = dPI;
            Nombre = nombre;
            Celular = celular;
            Telefono = telefono;
            Extension = extension;
            Email = email;
            DireccionOff = direccionOff;
            this.idCliente = idCliente;
            this.idTipoContacto = idTipoContacto;
        }

        public byte IdContacto { get => idContacto; set => idContacto = value; }
        public int DPI1 { get => DPI; set => DPI = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public string Celular1 { get => Celular; set => Celular = value; }
        public string Telefono1 { get => Telefono; set => Telefono = value; }
        public string Extension1 { get => Extension; set => Extension = value; }
        public string Email1 { get => Email; set => Email = value; }
        public string DireccionOff1 { get => DireccionOff; set => DireccionOff = value; }
        public byte IdCliente { get => idCliente; set => idCliente = value; }
        public byte IdTipoContacto { get => idTipoContacto; set => idTipoContacto = value; }
    }
}