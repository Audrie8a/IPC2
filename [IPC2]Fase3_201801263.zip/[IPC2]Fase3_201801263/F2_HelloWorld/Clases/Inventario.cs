﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Inventario
    {
        private byte idInventario;
        private string inventarioA;

        public Inventario()
        {

        }

        public Inventario(byte idInventario, string inventarioA)
        {
            this.idInventario = idInventario;
            this.inventarioA = inventarioA;
        }

        public byte IdInventario { get => idInventario; set => idInventario = value; }
        public string InventarioA { get => inventarioA; set => inventarioA = value; }
    }
}