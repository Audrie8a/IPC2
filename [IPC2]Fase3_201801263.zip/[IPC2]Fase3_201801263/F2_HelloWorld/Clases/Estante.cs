﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Estante
    {
        private string identificacion;
        private int Largo;
        private int Ancho;
        private int Altura;
        private int idPasillo;

        public Estante()
        {
        }

        public Estante(string identificacion, int largo, int ancho, int altura, int idPasillo)
        {
            this.identificacion = identificacion;
            Largo = largo;
            Ancho = ancho;
            Altura = altura;
            this.idPasillo = idPasillo;
        }

        public string Identificacion { get => identificacion; set => identificacion = value; }
        public int Largo1 { get => Largo; set => Largo = value; }
        public int Ancho1 { get => Ancho; set => Ancho = value; }
        public int Altura1 { get => Altura; set => Altura = value; }
        public int IdPasillo { get => idPasillo; set => idPasillo = value; }
    }
}