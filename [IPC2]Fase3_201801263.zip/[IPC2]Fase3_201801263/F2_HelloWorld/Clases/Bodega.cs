﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Bodega
    {
        private byte idBodega;
        private string BodegaN;
        private string Descripcion;
        private string Direccion;
        private byte idInventario;

        public Bodega() {
        }

        public Bodega(byte idBodega, string bodegaN, string descripcion, string direccion, byte idInventario)
        {
            this.idBodega = idBodega;
            BodegaN = bodegaN;
            Descripcion = descripcion;
            Direccion = direccion;
            this.idInventario = idInventario;
        }

        public byte IdBodega { get => idBodega; set => idBodega = value; }
        public string BodegaN1 { get => BodegaN; set => BodegaN = value; }
        public string Descripcion1 { get => Descripcion; set => Descripcion = value; }
        public string Direccion1 { get => Direccion; set => Direccion = value; }
        public byte IdInventario { get => idInventario; set => idInventario = value; }
    }
}