﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class PresentacionProducto
    {
        private byte idPresentacionProducto;
        private string presentacionP;

        public PresentacionProducto() { }

        public PresentacionProducto(byte idPresentacionProducto, string presentacionP)
        {
            this.idPresentacionProducto = idPresentacionProducto;
            this.presentacionP = presentacionP;
        }

        public byte IdPresentacionProducto { get => idPresentacionProducto; set => idPresentacionProducto = value; }
        public string PresentacionP { get => presentacionP; set => presentacionP = value; }
    }
}