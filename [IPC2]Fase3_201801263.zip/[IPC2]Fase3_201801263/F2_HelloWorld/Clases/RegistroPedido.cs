﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class RegistroPedido
    {
        private byte idRegistroPedido;
        private byte idPedido;
        private byte codigoProducto;
        private int MontoTotal;
        private DateTime FechaPedido;
        private DateTime FechaRecibido;
        private byte idProveedor;
        private int cantidad;
        private int precio;
        

        public RegistroPedido() { }

        public RegistroPedido(byte idRegistroPedido, byte idPedido, byte codigoProducto, int montoTotal, DateTime fechaPedido, DateTime fechaRecibido, byte idProveedor, int cantidad, int precio)
        {
            this.idRegistroPedido = idRegistroPedido;
            this.idPedido = idPedido;
            this.codigoProducto = codigoProducto;
            MontoTotal = montoTotal;
            FechaPedido = fechaPedido;
            FechaRecibido = fechaRecibido;
            this.idProveedor = idProveedor;
            this.cantidad = cantidad;
            this.precio = precio;
        }

        public byte IdRegistroPedido { get => idRegistroPedido; set => idRegistroPedido = value; }
        public byte IdPedido { get => idPedido; set => idPedido = value; }
        public byte CodigoProducto { get => codigoProducto; set => codigoProducto = value; }
        public int MontoTotal1 { get => MontoTotal; set => MontoTotal = value; }
        public DateTime FechaPedido1 { get => FechaPedido; set => FechaPedido = value; }
        public DateTime FechaRecibido1 { get => FechaRecibido; set => FechaRecibido = value; }
        public byte IdProveedor { get => idProveedor; set => idProveedor = value; }
        public int Cantidad { get => cantidad; set => cantidad = value; }
        public int Precio { get => precio; set => precio = value; }
    }
}