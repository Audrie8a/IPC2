﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Transaccion
    {
        private byte idTransaccion;
        private DateTime Fecha;
        private string Hora;
        private byte idTipoTransaccion;
        private byte codigoProducto;
        private string Producto;
        private byte Cliente;
        private byte Proveedor;
        private int Cantidad;
        private int CostoProducto;
        private int CostoTotal;

        public Transaccion()
        {
        }

        public Transaccion(byte idTransaccion, DateTime fecha, string hora, byte idTipoTransaccion, byte codigoProducto, string producto, byte cliente, byte proveedor, int cantidad, int costoProducto, int costoTotal)
        {
            this.idTransaccion = idTransaccion;
            Fecha = fecha;
            Hora = hora;
            this.idTipoTransaccion = idTipoTransaccion;
            this.codigoProducto = codigoProducto;
            Producto = producto;
            Cliente = cliente;
            Proveedor = proveedor;
            Cantidad = cantidad;
            CostoProducto = costoProducto;
            CostoTotal = costoTotal;
        }

        public byte IdTransaccion { get => idTransaccion; set => idTransaccion = value; }
        public DateTime Fecha1 { get => Fecha; set => Fecha = value; }
        public string Hora1 { get => Hora; set => Hora = value; }
        public byte IdTipoTransaccion { get => idTipoTransaccion; set => idTipoTransaccion = value; }
        public byte CodigoProducto { get => codigoProducto; set => codigoProducto = value; }
        public string Producto1 { get => Producto; set => Producto = value; }
        public byte Cliente1 { get => Cliente; set => Cliente = value; }
        public byte Proveedor1 { get => Proveedor; set => Proveedor = value; }
        public int Cantidad1 { get => Cantidad; set => Cantidad = value; }
        public int CostoProducto1 { get => CostoProducto; set => CostoProducto = value; }
        public int CostoTotal1 { get => CostoTotal; set => CostoTotal = value; }
    }
}