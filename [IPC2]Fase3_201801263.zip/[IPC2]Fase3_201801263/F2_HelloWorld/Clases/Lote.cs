﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Lote
    {
        private byte idLote;
        private string LoteN;
        private int Precio;
        private byte idTipoLogica;

        public Lote() {
        }

        public Lote(byte idLote, string loteN, int precio, byte idTipoLogica)
        {
            this.idLote = idLote;
            LoteN = loteN;
            Precio = precio;
            this.idTipoLogica = idTipoLogica;
        }

        public byte IdLote { get => idLote; set => idLote = value; }
        public string LoteN1 { get => LoteN; set => LoteN = value; }
        public int Precio1 { get => Precio; set => Precio = value; }
        public byte IdTipoLogica { get => idTipoLogica; set => idTipoLogica = value; }
    }
}