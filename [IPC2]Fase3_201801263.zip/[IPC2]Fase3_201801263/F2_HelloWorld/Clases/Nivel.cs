﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Nivel
    {
        private int numNivel;
        private int Altura;
        private int Largo;
        private int Ancho;
        private string idEstante;

        public Nivel()
        {
        }

        public Nivel(int numNivel, int altura, int largo, int ancho, string idEstante)
        {
            this.numNivel = numNivel;
            Altura = altura;
            Largo = largo;
            Ancho = ancho;
            this.idEstante = idEstante;
        }

        public int NumNivel { get => numNivel; set => numNivel = value; }
        public int Altura1 { get => Altura; set => Altura = value; }
        public int Largo1 { get => Largo; set => Largo = value; }
        public int Ancho1 { get => Ancho; set => Ancho = value; }
        public string IdEstante { get => idEstante; set => idEstante = value; }
    }
}