﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class TransaccionProducto
    {
        private byte idTrans_Produc;
        private byte idBodega;
        private byte codigoProducto;
        private byte idTransaccion;

        public TransaccionProducto()
        {
        }

        public TransaccionProducto(byte idTrans_Produc, byte idBodega, byte codigoProducto, byte idTransaccion)
        {
            this.idTrans_Produc = idTrans_Produc;
            this.idBodega = idBodega;
            this.codigoProducto = codigoProducto;
            this.idTransaccion = idTransaccion;
        }

        public byte IdTrans_Produc { get => idTrans_Produc; set => idTrans_Produc = value; }
        public byte IdBodega { get => idBodega; set => idBodega = value; }
        public byte CodigoProducto { get => codigoProducto; set => codigoProducto = value; }
        public byte IdTransaccion { get => idTransaccion; set => idTransaccion = value; }
    }
}