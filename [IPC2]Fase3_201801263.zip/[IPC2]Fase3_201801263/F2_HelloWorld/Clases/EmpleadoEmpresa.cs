﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class EmpleadoEmpresa
    {
        private byte idEmpleadoE;
        private string Nombre;
        private string telefono;
        private byte idPuesto;
        private byte idUsuario;

        public EmpleadoEmpresa()
        {
        }

        public EmpleadoEmpresa(byte idEmpleadoE, string nombre, string telefono, byte idPuesto, byte idUsuario)
        {
            this.idEmpleadoE = idEmpleadoE;
            Nombre = nombre;
            this.telefono = telefono;
            this.idPuesto = idPuesto;
            this.idUsuario = idUsuario;
        }

        public byte IdEmpleadoE { get => idEmpleadoE; set => idEmpleadoE = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public string Telefono { get => telefono; set => telefono = value; }
        public byte IdPuesto { get => idPuesto; set => idPuesto = value; }
        public byte IdUsuario { get => idUsuario; set => idUsuario = value; }
    }
}