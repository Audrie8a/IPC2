﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Saldo
    {
        private byte idSaldo;
        private string SaldoN;
        private int Costo;

        public Saldo()
        {
        }

        public Saldo(byte idSaldo, string saldoN, int costo)
        {
            this.idSaldo = idSaldo;
            SaldoN = saldoN;
            Costo = costo;
        }

        public byte IdSaldo { get => idSaldo; set => idSaldo = value; }
        public string SaldoN1 { get => SaldoN; set => SaldoN = value; }
        public int Costo1 { get => Costo; set => Costo = value; }
    }
}