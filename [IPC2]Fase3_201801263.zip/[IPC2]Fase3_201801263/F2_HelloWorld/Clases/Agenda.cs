﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Agenda
    {
        private byte idAgenda;
        private string Anyo;

        public Agenda()
        {
        }

        public Agenda(byte idAgenda, string anyo)
        {
            this.idAgenda = idAgenda;
            Anyo = anyo;
        }

        public byte IdAgenda { get => idAgenda; set => idAgenda = value; }
        public string Anyo1 { get => Anyo; set => Anyo = value; }
    }
}