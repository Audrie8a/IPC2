﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Puesto
    {
        private byte idPuesto;
        private string Nombre;

        public Puesto()
        {
        }

        public Puesto(byte idPuesto, string nombre)
        {
            this.idPuesto = idPuesto;
            Nombre = nombre;
        }

        public byte IdPuesto { get => idPuesto; set => idPuesto = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
    }
}