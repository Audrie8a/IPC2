﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class UbicacionProductoGestion
    {
        private byte idUbicacion;
        private string tipoGestio;
        private byte idGestion;
        private byte codigoProducto;
        private string Ubicacion;
        private int Cantidad;

        public UbicacionProductoGestion()
        {
        }

        public UbicacionProductoGestion(byte idUbicacion, string tipoGestio, byte idGestion, byte codigoProducto, string ubicacion, int cantidad)
        {
            this.idUbicacion = idUbicacion;
            this.tipoGestio = tipoGestio;
            this.idGestion = idGestion;
            this.codigoProducto = codigoProducto;
            Ubicacion = ubicacion;
            Cantidad = cantidad;
        }

        public byte IdUbicacion { get => idUbicacion; set => idUbicacion = value; }
        public string TipoGestio { get => tipoGestio; set => tipoGestio = value; }
        public byte IdGestion { get => idGestion; set => idGestion = value; }
        public byte CodigoProducto { get => codigoProducto; set => codigoProducto = value; }
        public string Ubicacion1 { get => Ubicacion; set => Ubicacion = value; }
        public int Cantidad1 { get => Cantidad; set => Cantidad = value; }
    }
}