﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Pedido
    {
        private byte idPedido;
        private DateTime FechaPedido;
        private DateTime FechaRecibido;
        private int cantidad;
        private int precio;
        private byte idProveedor;

        public Pedido() { }
        public Pedido(byte idPedido, DateTime fechaPedido, DateTime fechaRecibido, int cantidad, int precio, byte idProveedor)
        {
            this.idPedido = idPedido;
            FechaPedido = fechaPedido;
            FechaRecibido = fechaRecibido;
            this.cantidad = cantidad;
            this.precio = precio;
            this.idProveedor = idProveedor;
        }

        public byte IdPedido { get => idPedido; set => idPedido = value; }
        public DateTime FechaPedido1 { get => FechaPedido; set => FechaPedido = value; }
        public DateTime FechaRecibido1 { get => FechaRecibido; set => FechaRecibido = value; }
        public int Cantidad { get => cantidad; set => cantidad = value; }
        public int Precio { get => precio; set => precio = value; }
        public byte IdProveedor { get => idProveedor; set => idProveedor = value; }
    }
}