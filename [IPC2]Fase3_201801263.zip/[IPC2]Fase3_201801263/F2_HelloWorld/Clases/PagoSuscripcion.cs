﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class PagoSuscripcion
    {
        private byte idPagoSuscripcion;
        private byte idTipoSuscripcion;
        private int PrecioModulo;
        private byte idRangoUsuario;
        private byte codigoModulo;
        private byte idListaPrecio;

        public PagoSuscripcion()
        {
        }

        public PagoSuscripcion(byte idPagoSuscripcion, byte idTipoSuscripcion, int precioModulo, byte idRangoUsuario, byte codigoModulo, byte idListaPrecio)
        {
            this.idPagoSuscripcion = idPagoSuscripcion;
            this.idTipoSuscripcion = idTipoSuscripcion;
            PrecioModulo = precioModulo;
            this.idRangoUsuario = idRangoUsuario;
            this.codigoModulo = codigoModulo;
            this.idListaPrecio = idListaPrecio;
        }

        public byte IdPagoSuscripcion { get => idPagoSuscripcion; set => idPagoSuscripcion = value; }
        public byte IdTipoSuscripcion { get => idTipoSuscripcion; set => idTipoSuscripcion = value; }
        public int PrecioModulo1 { get => PrecioModulo; set => PrecioModulo = value; }
        public byte IdRangoUsuario { get => idRangoUsuario; set => idRangoUsuario = value; }
        public byte CodigoModulo { get => codigoModulo; set => codigoModulo = value; }
        public byte IdListaPrecio { get => idListaPrecio; set => idListaPrecio = value; }
    }
}