﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class TipoTarjeta
    {
        private byte idTipoTarjeta;
        private string TipoT;

        public TipoTarjeta()
        {
        }

        public TipoTarjeta(byte idTipoTarjeta, string tipoT)
        {
            this.idTipoTarjeta = idTipoTarjeta;
            TipoT = tipoT;
        }

        public byte IdTipoTarjeta { get => idTipoTarjeta; set => idTipoTarjeta = value; }
        public string TipoT1 { get => TipoT; set => TipoT = value; }
    }
}