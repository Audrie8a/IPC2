﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Anuncio
    {
        private byte idAnuncio;
        private byte idBlog;
        private string Anuncios;
        private string Autor;

        public Anuncio()
        {
        }

        public Anuncio(byte idAnuncio, byte idBlog, string anuncios, string autor)
        {
            this.idAnuncio = idAnuncio;
            this.idBlog = idBlog;
            Anuncios = anuncios;
            Autor = autor;
        }

        public byte IdAnuncio { get => idAnuncio; set => idAnuncio = value; }
        public byte IdBlog { get => idBlog; set => idBlog = value; }
        public string Anuncios1 { get => Anuncios; set => Anuncios = value; }
        public string Autor1 { get => Autor; set => Autor = value; }
    }
}