﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace F2_HelloWorld
{
    public partial class Login : System.Web.UI.Page
    {
        GD_Login login = new GD_Login();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnIngresar_Click(object sender, EventArgs e)
        {
            int id = -1;            

            id = login.validar_usuario(txtUsuario.Text, txtContrasena.Text);

            if (id == -1)
            {
                MessageBox.Show("Usuario no encontrado");
            }
            else if(id==0){
                byte tipoContacto = login.determinarTipoContacto(Convert.ToByte(txtUsuario.Text));
                /*
                    Si tipoContacto=1 Contacto Comercial
                    Si tipoContacto=2 Contacto Gerencial
                    Si tipoContacto=3 Contacto Admiistrador
                 */
                byte tipoUsuario = login.determinarTipoUsuario(Convert.ToByte(txtUsuario.Text));

                /*
                    Si tipo usuario=1 Administrador del Servicio
                    Si tipoUsuario =2 Usuario Operativo
                    Si tipoUsuario =3 Administrador del Sistema
                 */
                if (tipoUsuario == 1) {
                    Response.Redirect("PW/pwAdminDeServicio.aspx");
                } else if (tipoUsuario == 2) {
                    Response.Redirect("PW/pwUsuarioOperativo.aspx");
                } else if (tipoUsuario == 3 || tipoContacto == 3) {
                    Response.Redirect("PW/pwAdminDelSistema.aspx");
                } else if (tipoContacto == 1 || tipoContacto==2 && tipoUsuario==2) {
                    Response.Redirect("PW/pwContactoGerencial");
                }
                
            }
        }
    }
}