﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class InventarioPorProducto
    {
        private byte codigoProducto;
        private string codigoBarra;
        private string Nombre;
        private string Descripción;
        private byte idPresentacionProducto;
        private byte idClasificacionProducto;
        private byte idEstadoProducto;
        private string tipoGestionLetra;
        private byte TipoGestionNúmero;
        private int Precio;
        private int CantidadDisponible;
        private string ubicacion;

        public InventarioPorProducto()
        {
        }

        public InventarioPorProducto(byte codigoProducto, string codigoBarra, string nombre, string descripción, byte idPresentacionProducto, byte idClasificacionProducto, byte idEstadoProducto, string tipoGestionLetra, byte tipoGestionNúmero, int precio, int cantidadDisponible, string ubicacion)
        {
            this.codigoProducto = codigoProducto;
            this.codigoBarra = codigoBarra;
            Nombre = nombre;
            Descripción = descripción;
            this.idPresentacionProducto = idPresentacionProducto;
            this.idClasificacionProducto = idClasificacionProducto;
            this.idEstadoProducto = idEstadoProducto;
            this.tipoGestionLetra = tipoGestionLetra;
            TipoGestionNúmero = tipoGestionNúmero;
            Precio = precio;
            CantidadDisponible = cantidadDisponible;
            this.ubicacion = ubicacion;
        }

        public byte CodigoProducto { get => codigoProducto; set => codigoProducto = value; }
        public string CodigoBarra { get => codigoBarra; set => codigoBarra = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public string Descripción1 { get => Descripción; set => Descripción = value; }
        public byte IdPresentacionProducto { get => idPresentacionProducto; set => idPresentacionProducto = value; }
        public byte IdClasificacionProducto { get => idClasificacionProducto; set => idClasificacionProducto = value; }
        public byte IdEstadoProducto { get => idEstadoProducto; set => idEstadoProducto = value; }
        public string TipoGestionLetra { get => tipoGestionLetra; set => tipoGestionLetra = value; }
        public byte TipoGestionNúmero1 { get => TipoGestionNúmero; set => TipoGestionNúmero = value; }
        public int Precio1 { get => Precio; set => Precio = value; }
        public int CantidadDisponible1 { get => CantidadDisponible; set => CantidadDisponible = value; }
        public string Ubicacion { get => ubicacion; set => ubicacion = value; }
    }
}