﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWCliente : System.Web.UI.Page
    {
        GD_Cliente Cliente = new GD_Cliente();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente Objeto = new Cliente();
                Objeto.NIT1 = txtNit.Text;
                Objeto.Nombre1 = txtNombre.Text;
                Objeto.Id_TipoEmpresa = Convert.ToByte(DDLtipoE.Text);
                Objeto.Id_TamanoEmpresa= Convert.ToByte(DDLtamaE.Text);
                Objeto.Id_TarjetaCredito= Convert.ToByte(DDLtarjetaC.Text);
                Objeto.IdUsuarioAdministrador = Convert.ToByte(DDLusuarioAdmin.Text);

                if (txtNombre.Text != null && txtNit.Text != null && DDLtamaE.SelectedIndex !=0 && DDLtarjetaC.SelectedIndex != 0 && DDLtipoE.SelectedIndex != 0 && DDLusuarioAdmin.SelectedIndex != 0)
                {
                    bool agregado = Cliente.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Cliente Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Cliente.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte Cliente a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string Nit = txtNit.Text;
                    string Nombre = txtNombre.Text;
                    byte idTipoE = Convert.ToByte(DDLtipoE.Text);
                    byte idTamaE= Convert.ToByte(DDLtamaE.Text);
                    byte idTarjetaC = Convert.ToByte(DDLtarjetaC.Text);
                    byte idUsuarioA = Convert.ToByte(DDLusuarioAdmin.Text);

                    Cliente.editar(identificacion, Nit, Nombre, idTipoE, idTamaE, idTarjetaC, idUsuarioA);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Cliente.eliminar(identificacion);
                    lblMensaje.Text = "Cliente Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de Cliente a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de Cliente a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Cliente objeto = Cliente.consultar(identificacion);
                if (objeto != null)
                {
                    txtNombre.Text = objeto.Nombre1;
                    txtNit.Text = objeto.NIT1;
                    DDLtamaE.Text = Convert.ToString(objeto.Id_TamanoEmpresa);
                    DDLtarjetaC.Text = Convert.ToString(objeto.Id_TarjetaCredito);
                    DDLtipoE.Text = Convert.ToString(objeto.Id_TipoEmpresa);
                    DDLusuarioAdmin.Text = Convert.ToString(objeto.IdUsuarioAdministrador);

                    lblMensaje.Text = "Cliente consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Cliente agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de Cliente a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Cliente> Lista = Cliente.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Cliente agregados en la base de datos";
            }
            else
            {
                gvCliente.DataSource = Lista;
                gvCliente.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtNombre.Text = "";
            txtNit.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = Cliente.Consultar("Select idCliente from Cliente");
            DDLidentificacion.DataTextField = "idCliente";
            DDLidentificacion.DataValueField = "idCliente";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLtamaE.DataSource = Cliente.Consultar("Select id_TamañoEmpresa, TamñoEmpresa from TamañoEmpresa");
            DDLtamaE.DataTextField = "TamñoEmpresa";
            DDLtamaE.DataValueField = "id_TamañoEmpresa";
            DDLtamaE.DataBind();
            DDLtamaE.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLtarjetaC.DataSource = Cliente.Consultar("Select numTarjeta from TarjetaCredito");
            DDLtarjetaC.DataTextField = "numTarjeta";
            DDLtarjetaC.DataValueField = "numTarjeta";
            DDLtarjetaC.DataBind();
            DDLtarjetaC.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLtipoE.DataSource = Cliente.Consultar("Select id_Tipoempresa, TipoEmpresa from TipoEmpresa");
            DDLtipoE.DataTextField = "TipoEmpresa";
            DDLtipoE.DataValueField = "id_Tipoempresa";
            DDLtipoE.DataBind();
            DDLtipoE.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLusuarioAdmin.DataSource = Cliente.Consultar("Select idUsuario from Usuario");
            DDLusuarioAdmin.DataTextField = "idUsuario";
            DDLusuarioAdmin.DataValueField = "idUsuario";
            DDLusuarioAdmin.DataBind();
            DDLusuarioAdmin.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PW/pwAdminDelSistema.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWTipoEmpresa.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWTarjetaCredito.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWContacto.aspx");
        }
    }
}