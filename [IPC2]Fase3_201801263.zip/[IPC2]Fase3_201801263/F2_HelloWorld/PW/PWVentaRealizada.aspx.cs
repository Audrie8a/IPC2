﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWVentaRealizada : System.Web.UI.Page
    {
        GD_VentaRealizada VentaRealizada = new GD_VentaRealizada();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                VentaRealizada Objeto = new VentaRealizada();
                
                Objeto.Fecha = calendarioVenta.SelectedDate;
                Objeto.IdFacturacion = Convert.ToByte(DDLfacturacion.Text);
                Objeto.ImpuestosDato1 = Convert.ToInt32(txtImpuestoDato.Text);

                if (calendarioVenta.SelectedDate != null && DDLfacturacion.SelectedIndex!=0 && txtImpuestoDato.Text!=null)
                {
                    bool agregado = VentaRealizada.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Venta Realizada Agregada Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += VentaRealizada.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception ex)
            {
                lblMensaje.Text += ex+"Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte la Venta Realizada a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    DateTime Fecha = calendarioVenta.SelectedDate;
                    int ImpuestoDato = Convert.ToInt32(txtImpuestoDato.Text);
                    byte idFacturacion = Convert.ToByte(DDLfacturacion.Text);
                    int Impuesto = 0;//Convert.ToInt32(lblimpuesto.Text);
                    int ImporteTotal = 0;//Convert.ToInt32(lblimporteTotal.Text);

                    VentaRealizada.editar(identificacion, ImporteTotal, Impuesto,Fecha, ImpuestoDato, idFacturacion);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    VentaRealizada.eliminar(identificacion);
                    lblMensaje.Text = "Venta Realizada Eliminada exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de la Venta Realizada a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de la Venta Realizada a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                VentaRealizada objeto = VentaRealizada.consultar(identificacion);
                if (objeto != null)
                {
                    txtImpuestoDato.Text = Convert.ToString(objeto.ImpuestosDato1);
                    calendarioVenta.SelectedDate = Convert.ToDateTime(objeto.Fecha);
                    DDLfacturacion.Text = Convert.ToString(objeto.IdFacturacion);
                    lblimporteTotal.Text = Convert.ToString(objeto.ImporteTotalVenta);
                    lblimpuesto.Text = Convert.ToString(objeto.Impuesto1);
                    lblMensaje.Text = "Venta consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Ventas agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de la Venta a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<VentaRealizada> Lista = VentaRealizada.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Ventas Realizada agregados en la base de datos";
            }
            else
            {
                gvVentarR.DataSource = Lista;
                gvVentarR.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtImpuestoDato.Text = "";
            lblMensaje.Text = "RESULTADO: ";
            lblimporteTotal.Text = "";
            lblimpuesto.Text = "";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = VentaRealizada.Consultar("Select idVentaRealizada from VentaRealizada");
            DDLidentificacion.DataTextField = "idVentaRealizada";
            DDLidentificacion.DataValueField = "idVentaRealizada";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación ]", "0"));

            //Datos idPresentacionProducto
            DDLfacturacion.DataSource = VentaRealizada.Consultar("Select idFacturacion from Facturacion");
            DDLfacturacion.DataTextField = "idFacturacion";
            DDLfacturacion.DataValueField = "idFacturacion";
            DDLfacturacion.DataBind();
            DDLfacturacion.Items.Insert(0, new ListItem("[Seleccionar identificación ]", "0"));
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWVentaProducto.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWFacturacion.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWVendedor.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWProductoEmpresa.aspx");
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWclienteEmpresa.aspx");
        }
    }
}