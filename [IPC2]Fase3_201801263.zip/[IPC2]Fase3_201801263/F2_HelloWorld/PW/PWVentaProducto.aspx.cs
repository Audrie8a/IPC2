﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWVentaProducto : System.Web.UI.Page
    {
        GD_VentaProducto VentaProducto = new GD_VentaProducto();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                VentaProducto Objeto = new VentaProducto();
                Objeto.IdFacturacion = Convert.ToByte(DDLfacturacion.Text);
                Objeto.CodigoProducto = Convert.ToByte(DDLproducto.Text);
                Objeto.Cantidad = Convert.ToInt32(txtCantidad.Text);
                Objeto.Pago1 = Convert.ToInt32(txtPago.Text);

                if (txtCantidad.Text != null && txtPago.Text != null && DDLfacturacion.SelectedIndex!=0 && DDLproducto.SelectedIndex !=0)
                {
                    bool agregado = VentaProducto.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Informacion Venta Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += VentaProducto.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte la información de la Venta a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    byte idFacturacion = Convert.ToByte(DDLfacturacion.Text);
                    byte codigoProducto = Convert.ToByte(DDLproducto.Text);
                    int cantidad = Convert.ToInt32(txtCantidad.Text);
                    int pago = Convert.ToInt32(txtPago.Text);
                    VentaProducto.editar(identificacion, idFacturacion, codigoProducto,cantidad,pago);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    VentaProducto.eliminar(identificacion);
                    lblMensaje.Text = "Informacion de la venta Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de la venta a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de la venta a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                VentaProducto objeto = VentaProducto.consultar(identificacion);
                if (objeto != null)
                {
                    txtCantidad.Text = Convert.ToString(objeto.Cantidad);
                    txtPago.Text = Convert.ToString(objeto.Pago1);
                    DDLfacturacion.Text = Convert.ToString(objeto.IdFacturacion);
                    DDLproducto.Text = Convert.ToString(objeto.CodigoProducto);
                    lblMensaje.Text = "Venta consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Ventas agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de la venta a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<VentaProducto> Lista = VentaProducto.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay ventas agregados en la base de datos";
            }
            else
            {
                gvGestionVentas.DataSource = Lista;
                gvGestionVentas.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtCantidad.Text = "";
            txtPago.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idVentaProducto
            DDLidentificacion.DataSource = VentaProducto.Consultar("Select idVentaProducto from VentaProducto");
            DDLidentificacion.DataTextField = "idVentaProducto";
            DDLidentificacion.DataValueField = "idVentaProducto";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));

            //Datos codigoProducto
            DDLproducto.DataSource = VentaProducto.Consultar("Select codigoProducto, Nombre from ProductoEmpresa");
            DDLproducto.DataTextField = "Nombre";
            DDLproducto.DataValueField = "codigoProducto";
            DDLproducto.DataBind();
            DDLproducto.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idFacturacion
            DDLfacturacion.DataSource = VentaProducto.Consultar("Select idFacturacion from Facturacion");
            DDLfacturacion.DataTextField = "idFacturacion";
            DDLfacturacion.DataValueField = "idFacturacion";
            DDLfacturacion.DataBind();
            DDLfacturacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }
    }
}