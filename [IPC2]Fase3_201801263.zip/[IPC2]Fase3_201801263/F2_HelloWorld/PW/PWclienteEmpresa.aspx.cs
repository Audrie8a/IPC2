﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWclienteEmpresa : System.Web.UI.Page
    {
        GD_ClienteEmpresa ClienteEmpresa = new GD_ClienteEmpresa();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) {
                IniciarLLenadoDropDownList();
                btnEliminarCE.Enabled = false;
                btnEditarClienteE.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList() {

            //Datos CategoriaCliente
            DDLcodigoCategoriaClienteE.DataSource = ClienteEmpresa.Consultar("Select codigoCategoria, Abreviatura from CategoriaCliente");
            DDLcodigoCategoriaClienteE.DataTextField = "Abreviatura";
            DDLcodigoCategoriaClienteE.DataValueField = "codigoCategoria";
            DDLcodigoCategoriaClienteE.DataBind();
            DDLcodigoCategoriaClienteE.Items.Insert(0,new ListItem("[Seleccionar]","0"));

            //Datos EstadoCliente
            DDLestadoClienteE.DataSource = ClienteEmpresa.Consultar("Select idEstadoCliente, EstadoCliente from EstadoCliente");
            DDLestadoClienteE.DataTextField = "EstadoCliente";
            DDLestadoClienteE.DataValueField = "idEstadoCliente";
            DDLestadoClienteE.DataBind();
            DDLestadoClienteE.Items.Insert(0, new ListItem("[Seleccionar]", "0"));

            //Datos idCliente
            DDLidentificacionCliente.DataSource = ClienteEmpresa.Consultar("Select idClienteE from ClienteEmpresa");
            DDLidentificacionCliente.DataTextField = "idClienteE";
            DDLidentificacionCliente.DataValueField = "idClienteE";
            DDLidentificacionCliente.DataBind();
            DDLidentificacionCliente.Items.Insert(0, new ListItem("[Seleccionar identificación Cliente]", "0"));            
        }


        //Botón para agregar nuevo Cliente
        protected void Button1_Click(object sender, EventArgs e)
        {
            try {
                ClienteEmpresa ClienteE = new ClienteEmpresa();
                ClienteE.Nit = txtNITclienteE.Text;
                ClienteE.NOMBRE = txtNombreClienteE.Text;
                ClienteE.DIRECCION = txtDirecciónClienteE.Text;
                ClienteE.TELEFONO = txtTelefonoClienteE.Text;
                ClienteE.CONTACTO_ENCARGADO = txtContactoEncargado.Text;
                ClienteE.CORREO = txtCorreoClienteE.Text;
                ClienteE.CODIGO_CATEGORIA = Convert.ToByte(DDLcodigoCategoriaClienteE.Text);
                ClienteE.LIMITE_CREDITO = Convert.ToInt32(txtLimiteCredito.Text);
                ClienteE.TIEMPO_CREDITO = Convert.ToByte(txtTiempoCredito.Text);
                ClienteE.ESTADO_CLIENTE = Convert.ToByte(DDLestadoClienteE.Text);


                if (txtNITclienteE.Text != null && txtNombreClienteE.Text != null && txtDirecciónClienteE.Text != null && txtTelefonoClienteE.Text != null && txtTiempoCredito.Text != null
                    && txtCorreoClienteE.Text != null && DDLcodigoCategoriaClienteE.Text != null && txtLimiteCredito.Text != null && DDLestadoClienteE.Text != null)
                {
                    bool agregado = ClienteEmpresa.agregarClienteEmpresa(ClienteE);
                    if (agregado)
                    {
                        lblMensaje.Text += "Cliente Agregado Exitosamente";
                        limpiar();
                        ListaClientes();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += ClienteEmpresa.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            } catch (Exception) {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
            

            
        }

        //Método para limpiar la tabla después de ingresar Datos 
        private void limpiar()
        {
            txtNITclienteE.Text = "";
            txtNombreClienteE.Text = "";
            txtDirecciónClienteE.Text = "";
            txtTelefonoClienteE.Text = "";
            txtLimiteCredito.Text = "";
            txtCorreoClienteE.Text = "";
            //DDLcodigoCategoriaClienteE.Text = "";
            txtTiempoCredito.Text = "";
            //DDLestadoClienteE.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Botón para buscar los datos del cliente por id
        protected void btnConsultarCE_Click(object sender, EventArgs e)
        {
            ConsultarClientes();
            btnEditarClienteE.Enabled = true;
            btnEliminarCE.Enabled = true;

        }

        //Botón para eliminar Clientes de la empresa
        protected void btnEliminarCE_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacionCliente.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacionCliente.Text);


                    ClienteEmpresa.eliminarClienteEmpresa(identificacion);
                    lblMensaje.Text = "Cliente Eliminado exitosamente";
                    ListaClientes();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else {
                    lblMensaje.Text += "Favor ingresar identificación del Cliente a eliminar";
                }
                
            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación del Cliente a eliminar"; }

        }

        //Fue el botón con el que probé la conexión a la base de datos
        protected void Button1_Click1(object sender, EventArgs e)
        {
            //Probando la conexion
            Conexion DB = new Conexion();
            if (DB.GetConection())
            {
                lblMensaje.Text = "Conectado";
            }
            else
            {
                lblMensaje.Text = "No Conectado!";
            }
        }

        //Boton Para listar los clientes de la empresa registrados 
        protected void btnListarCE_Click(object sender, EventArgs e)
        {
            ListaClientes();           
             
        }

        //Metodo para listaClientes

        public void ListaClientes() {
            List<ClienteEmpresa> lstClienteEmpresa = ClienteEmpresa.lstClientesEmpresa();
            if (lstClienteEmpresa.Count == 0)
            {
                lblMensaje.Text += "No hay Clientes agregados en la base de datos";
            }
            else
            {
                gvClienteEmpresa.DataSource = lstClienteEmpresa;
                gvClienteEmpresa.DataBind();
            }
        }

        //Metodo para Consultar Clientes
        public void ConsultarClientes() {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacionCliente.Text);

                ClienteEmpresa cliente = ClienteEmpresa.consultarClienteEmpresa(identificacion);
                if (cliente != null)
                {
                    txtNITclienteE.Text = cliente.Nit;
                    txtNombreClienteE.Text = cliente.NOMBRE;
                    txtDirecciónClienteE.Text = cliente.DIRECCION;
                    txtTelefonoClienteE.Text = cliente.TELEFONO;
                    txtLimiteCredito.Text = Convert.ToString(cliente.LIMITE_CREDITO);
                    txtCorreoClienteE.Text = cliente.CORREO;
                    txtContactoEncargado.Text = cliente.CONTACTO_ENCARGADO;
                    DDLcodigoCategoriaClienteE.Text = Convert.ToString(cliente.CODIGO_CATEGORIA);
                    txtTiempoCredito.Text = Convert.ToString(cliente.TIEMPO_CREDITO);
                    DDLestadoClienteE.Text = Convert.ToString(cliente.ESTADO_CLIENTE);
                    lblMensaje.Text = "Cliente consultado";                    
                }
                else
                {
                    lblMensaje.Text = "No hay personas agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación del Cliente a buscar"; }
        }

        //Boton para editar Clientes
        protected void btnEditarClienteE_Click(object sender, EventArgs e)
        {
            if (DDLidentificacionCliente.SelectedIndex==0)
            {
                lblMensaje.Text += "Favor consulte el Cliente a Editar";
            }
            else {
                try
                {
                    //if (txtNITclienteE.Text.Length !=0) { }
                    
                    

                    byte identificacion = Convert.ToByte(DDLidentificacionCliente.Text);
                    string Nit = txtNITclienteE.Text;
                    string NOMBRE = txtNombreClienteE.Text;
                    string DIRECCION = txtDirecciónClienteE.Text;
                    string TELEFONO = txtTelefonoClienteE.Text;
                    string CONTACTO_ENCARGADO = txtContactoEncargado.Text;
                    string CORREO = txtCorreoClienteE.Text;
                    byte CODIGO_CATEGORIA = Convert.ToByte(DDLcodigoCategoriaClienteE.Text);
                    int LIMITE_CREDITO = Convert.ToInt32(txtLimiteCredito.Text);
                    byte TIEMPO_CREDITO = Convert.ToByte(txtTiempoCredito.Text);
                    byte ESTADO_CLIENTE = Convert.ToByte(DDLestadoClienteE.Text);


                    ClienteEmpresa.editarClienteEmpres(identificacion, Nit, NOMBRE, DIRECCION, TELEFONO, CONTACTO_ENCARGADO, CORREO, CODIGO_CATEGORIA, LIMITE_CREDITO, TIEMPO_CREDITO, ESTADO_CLIENTE);
                    ListaClientes();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " "+ex; }
            }
            
        }

        protected void DDLidentificacionCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        protected void btnSubir_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile) {
                string ext = System.IO.Path.GetExtension(FileUpload1.FileName);
                ext = ext.ToLower();

                if (ext == ".xml")
                {
                    try
                    {
                        LeerArchivosXML leerXML = new LeerArchivosXML();
                        leerXML.prueba(Server.MapPath(FileUpload1.FileName));
                    }
                    catch (Exception ex) { Response.Write(ex); }

                }
                else {
                    Response.Write("Seleccione un archivo XML");
                }
            }
            else {
                Response.Write("Seleccione el archivo a subir");
            }
        }

        protected void Button1_Click2(object sender, EventArgs e)
        {
            Response.Redirect("PWCategoriaCliente");
        }
    }
} 