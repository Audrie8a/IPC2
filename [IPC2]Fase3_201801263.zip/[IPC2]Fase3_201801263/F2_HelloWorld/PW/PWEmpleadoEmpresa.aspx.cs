﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWEmpleadoEmpresa : System.Web.UI.Page
    {
        GD_EmpleadoEmpresa EmpleadoEmpresa = new GD_EmpleadoEmpresa();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                EmpleadoEmpresa Objeto = new EmpleadoEmpresa();
                Objeto.Nombre1 = txtNombre.Text;
                Objeto.Telefono = txtTelefono.Text;
                Objeto.IdPuesto = Convert.ToByte(DDLPuesto.Text);
                Objeto.IdUsuario = Convert.ToByte(DDLUsaurio.Text);

                if (txtNombre.Text != null && txtTelefono.Text != null && DDLPuesto.SelectedIndex!= 0 && DDLUsaurio.SelectedIndex!=0)
                {
                    bool agregado = EmpleadoEmpresa.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "EmpleadoEmpresa Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += EmpleadoEmpresa.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte EmpleadoEmpresa a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string Nombre = txtNombre.Text;
                    string telefono = txtTelefono.Text;
                    byte idPuesto = Convert.ToByte(DDLPuesto.Text);
                    byte idUsuario = Convert.ToByte(DDLUsaurio.Text);
                    EmpleadoEmpresa.editar(identificacion, Nombre, telefono, idPuesto, idUsuario);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    EmpleadoEmpresa.eliminar(identificacion);
                    lblMensaje.Text = "EmpleadoEmpresa Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación EmpleadoEmpresa a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación EmpleadoEmpresa a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }
        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                EmpleadoEmpresa objeto = EmpleadoEmpresa.consultar(identificacion);
                if (objeto != null)
                {
                    txtNombre.Text = objeto.Nombre1;
                    txtTelefono.Text = objeto.Telefono;
                    DDLPuesto.Text = Convert.ToString(objeto.IdPuesto);
                    DDLUsaurio.Text = Convert.ToString(objeto.IdUsuario);
                    lblMensaje.Text = "Presentación Producto consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay EmpleadoEmpresa agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación EmpleadoEmpresa a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<EmpleadoEmpresa> Lista = EmpleadoEmpresa.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay EmpleadoEmpresa agregados en la base de datos";
            }
            else
            {
                gvEmpleadoEmpres.DataSource = Lista;
                gvEmpleadoEmpres.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtNombre.Text = "";
            txtTelefono.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = EmpleadoEmpresa.Consultar("Select idEmpleado from EmpleadoEmpres");
            DDLidentificacion.DataTextField = "idEmpleado";
            DDLidentificacion.DataValueField = "idEmpleado";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLPuesto.DataSource = EmpleadoEmpresa.Consultar("Select idPuesto, Puesto from Puesto");
            DDLPuesto.DataTextField = "Puesto";
            DDLPuesto.DataValueField = "idPuesto";
            DDLPuesto.DataBind();
            DDLPuesto.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLUsaurio.DataSource = EmpleadoEmpresa.Consultar("Select idUsuario, Nombre from Usuario");
            DDLUsaurio.DataTextField = "Nombre";
            DDLUsaurio.DataValueField = "idUsuario";
            DDLUsaurio.DataBind();
            DDLUsaurio.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWPuesto.aspx");
        }
    }
}