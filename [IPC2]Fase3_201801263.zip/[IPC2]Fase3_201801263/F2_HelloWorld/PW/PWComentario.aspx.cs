﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWComentario : System.Web.UI.Page
    {
        GD_Comentario Comentario = new GD_Comentario();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Comentario Objeto = new Comentario();
                Objeto.Ccomentario1 = txtComentario.Text;
                Objeto.Autro1 = txtAutor.Text;
                Objeto.IdAnuncio = Convert.ToByte(DDLanuncio.Text);

                if (txtComentario.Text != null && txtAutor.Text != null && DDLanuncio.SelectedIndex !=0)
                {
                    bool agregado = Comentario.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Comentario Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Comentario.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {

            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte Comentario a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string Comentariox = txtComentario.Text;
                    string Autor = txtAutor.Text;
                    byte idAnuncio = Convert.ToByte(DDLanuncio.Text);

                    Comentario.editar(identificacion, Comentariox, Autor,idAnuncio );
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Comentario.eliminar(identificacion);
                    lblMensaje.Text = "Comentario Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación Comentario a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación Comentario a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Comentario objeto = Comentario.consultar(identificacion);
                if (objeto != null)
                {
                    txtComentario.Text = objeto.Ccomentario1;
                    txtAutor.Text = objeto.Autro1;
                    DDLanuncio.Text = Convert.ToString(objeto.IdAnuncio);
                    lblMensaje.Text = "Comentario consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Comentario agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de Comentario a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Comentario> Lista = Comentario.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Comentario agregados en la base de datos";
            }
            else
            {
                gvComentario.DataSource = Lista;
                gvComentario.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtAutor.Text = "";
            txtComentario.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = Comentario.Consultar("Select idComentario from Comentario");
            DDLidentificacion.DataTextField = "idComentario";
            DDLidentificacion.DataValueField = "idComentario";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación Presentación Producto]", "0"));

            //Datos idPresentacionProducto
            DDLanuncio.DataSource = Comentario.Consultar("Select idAnuncio from Anuncio");
            DDLanuncio.DataTextField = "idAnuncio";
            DDLanuncio.DataValueField = "idAnuncio";
            DDLanuncio.DataBind();
            DDLanuncio.Items.Insert(0, new ListItem("[Seleccionar identificación Presentación Producto]", "0"));
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWAnuncio.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWBlog.aspx");
        }
    }
}