﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWPedido : System.Web.UI.Page
    {
        GD_Pedido Pedido = new GD_Pedido();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Pedido Objeto = new Pedido();
                Objeto.FechaPedido1 = CfechaPedido.SelectedDate;
                Objeto.FechaRecibido1 = CfechaRecibo.SelectedDate;
                Objeto.Cantidad = Convert.ToInt32(txtCantidad.Text);
                Objeto.Precio = Convert.ToInt32(txtPrecio.Text);
                Objeto.IdProveedor = Convert.ToByte(DDLproveedor.Text);

                if (CfechaPedido.SelectedDate != null && CfechaRecibo.SelectedDate !=null && txtCantidad.Text !=null && txtPrecio.Text !=null && DDLproveedor.SelectedIndex !=0)
                {
                    bool agregado = Pedido.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Pedido Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Pedido.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte el Pedido a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    DateTime fechaPedido = CfechaPedido.SelectedDate;
                    DateTime fechaRecibido = CfechaRecibo.SelectedDate;
                    int cantidad = Convert.ToInt32(txtCantidad.Text);
                    int Precio = Convert.ToInt32(txtPrecio.Text);
                    byte idProveedor = Convert.ToByte(DDLproveedor.Text);

                    Pedido.editar(identificacion, fechaPedido, fechaRecibido,cantidad,Precio,idProveedor);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Pedido.eliminar(identificacion);
                    lblMensaje.Text = "Pedido Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación del Pedido a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación del Pedido a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Pedido objeto = Pedido.consultar(identificacion);
                if (objeto != null)
                {
                    CfechaPedido.SelectedDate= objeto.FechaPedido1;
                    CfechaRecibo.SelectedDate = objeto.FechaRecibido1;
                    txtCantidad.Text = Convert.ToString(objeto.Cantidad);
                    txtPrecio.Text = Convert.ToString(objeto.Precio);
                    DDLproveedor.Text= Convert.ToString(objeto.IdProveedor);
                    lblMensaje.Text = "Pedido consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Pedidos agregados a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de Pedidos a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Pedido> Lista = Pedido.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Pedidos agregados en la base de datos";
            }
            else
            {
                gvPedido.DataSource = Lista;
                gvPedido.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtCantidad.Text = "";
            txtPrecio.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPedido
            DDLidentificacion.DataSource = Pedido.Consultar("Select idPedido from Pedido");
            DDLidentificacion.DataTextField = "idPedido";
            DDLidentificacion.DataValueField = "idPedido";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));

            //Datos idProveedor
            DDLproveedor.DataSource = Pedido.Consultar("Select idProveedor from ProveedorEmpresa");
            DDLproveedor.DataTextField = "idProveedor";
            DDLproveedor.DataValueField = "idProveedor";
            DDLproveedor.DataBind();
            DDLproveedor.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }
    }
}