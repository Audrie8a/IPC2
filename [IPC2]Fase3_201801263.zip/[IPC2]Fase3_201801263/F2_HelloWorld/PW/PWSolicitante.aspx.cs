﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWSolicitante : System.Web.UI.Page
    {
        GD_Solicitante Solicitante = new GD_Solicitante();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Solicitante Objeto = new Solicitante();
                Objeto.Nombre1 = txtNombre.Text;
                Objeto.Descripcion1 = txtDescripcion.Text;

                if (txtNombre.Text != null&& txtDescripcion.Text != null)
                {
                    bool agregado = Solicitante.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Solicitante Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Solicitante.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {

            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte Solicitante a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string Nombre = txtNombre.Text;
                    string Descrip = txtDescripcion.Text;

                    Solicitante.editar(identificacion, Nombre,Descrip);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Solicitante.eliminar(identificacion);
                    lblMensaje.Text = "Solicitante Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de Solicitante a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de Solicitante a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Solicitante objeto = Solicitante.consultar(identificacion);
                if (objeto != null)
                {
                    txtNombre.Text = objeto.Nombre1;
                    txtDescripcion.Text = objeto.Descripcion1;
                    lblMensaje.Text = "Solicitante consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Solicitante agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de Solicitante a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Solicitante> Lista = Solicitante.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Solicitante en la base de datos";
            }
            else
            {
                gvSolicitante.DataSource = Lista;
                gvSolicitante.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtNombre.Text = "";
            txtDescripcion.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = Solicitante.Consultar("Select idSolicitante from Solicitante");
            DDLidentificacion.DataTextField = "idSolicitante";
            DDLidentificacion.DataValueField = "idSolicitante";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }
    }
}