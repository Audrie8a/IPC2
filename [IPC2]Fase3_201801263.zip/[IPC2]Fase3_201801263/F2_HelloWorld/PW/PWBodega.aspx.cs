﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWBodega : System.Web.UI.Page
    {
        GD_Bodega Bodega = new GD_Bodega();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Listar();
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Bodega Objeto = new Bodega();
                Objeto.BodegaN1 = txtBodega.Text;
                Objeto.Descripcion1 = txtDescripcion.Text;
                Objeto.Direccion1 = txtDireccion.Text;
                Objeto.IdInventario =Convert.ToByte( DDLinventario.Text);

                if (txtBodega.Text != null && txtDescripcion.Text != null && txtDireccion.Text != null && DDLinventario.SelectedIndex !=0)
                {
                    bool agregado = Bodega.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Bodega Agregada Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Bodega.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte la Bodega a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string BodegaN = txtBodega.Text;
                    string Direccion = txtDireccion.Text;
                    string Descripcion = txtDescripcion.Text;
                    byte idInventario = Convert.ToByte(DDLinventario.Text);

                    Bodega.editar(identificacion, BodegaN, Descripcion, Direccion, idInventario);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Bodega.eliminar(identificacion);
                    lblMensaje.Text = "Bodega Eliminada exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de la Bodega a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de la Bodega a eliminar"; }
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Bodega objeto = Bodega.consultar(identificacion);
                if (objeto != null)
                {
                    txtBodega.Text = objeto.BodegaN1;
                    txtDescripcion.Text = objeto.Descripcion1;
                    txtDireccion.Text = objeto.Direccion1;
                    DDLinventario.Text = Convert.ToString(objeto.IdInventario);
                    lblMensaje.Text = "Bodega consultada";
                }
                else
                {
                    lblMensaje.Text = "No hay Bodegas agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de la Bodega a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Bodega> Lista = Bodega.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Bodegas agregados en la base de datos";
            }
            else
            {
                gvBodega.DataSource = Lista;
                gvBodega.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtBodega.Text = "";
            txtDireccion.Text = "";
            txtDescripcion.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idBodega
            DDLidentificacion.DataSource = Bodega.Consultar("Select codigoBodega, Nombre from Bodega");
            DDLidentificacion.DataTextField = "Nombre";
            DDLidentificacion.DataValueField = "codigoBodega";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación Bodega]", "0"));

            //Datos idInventario
            DDLinventario.DataSource = Bodega.Consultar("Select idInventario, Inventario from Inventario");
            DDLinventario.DataTextField = "idInventario";
            DDLinventario.DataValueField = "idInventario";
            DDLinventario.DataBind();
            DDLinventario.Items.Insert(0, new ListItem("[Seleccionar identificación Inventario ]", "0"));
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("pwDivisionLogicaBodega.aspx");
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("PWProductoEmpresa.aspx");
        }
    }
}