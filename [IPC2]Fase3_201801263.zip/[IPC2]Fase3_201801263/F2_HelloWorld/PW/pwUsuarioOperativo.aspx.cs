﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld.PW
{
    public partial class pwUsuarioOperativo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("GestionInventario.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWVentaRealizada.aspx"); 
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWRegistroPedido.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("pwModuloGestionFacturacion.aspx");
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("pwModuloReclutamiento.aspx");
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWBlog.aspx");
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWEmpleadoEmpresa.aspx");
        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWProveedorEmpresa.aspx");
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWProductoEmpresa");
        }
    }
}