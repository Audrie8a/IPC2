﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class pwTransaccion : System.Web.UI.Page
    {
        GD_Transaccion Transaccion = new GD_Transaccion();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                //DateTime fecha = new DateTime();
                Transaccion Objeto = new Transaccion();
                byte idTipoTransaccionSelected =Convert.ToByte( DDLtipoTrans.Text);
                Objeto.Fecha1 = cFecha.SelectedDate;
                Objeto.Hora1 =txtHora.Text;
                Objeto.CodigoProducto = Convert.ToByte(DDLcodigoProducto.Text);
                Objeto.Producto1 = txtProducto.Text;
                Objeto.Cantidad1 = Convert.ToInt32(txtCantidad.Text);
                Objeto.CostoTotal1 = Convert.ToInt32(txtCostoTotal.Text);
                Objeto.IdTipoTransaccion = idTipoTransaccionSelected;

                if (idTipoTransaccionSelected == 1) {
                    //Entrada
                    Objeto.Proveedor1 = Convert.ToByte( DDLproveedor.Text);
                    Objeto.CostoProducto1 = Convert.ToInt32(txtCostoProducto.Text);
                    Objeto.Cliente1 = 0;

                    if (DDLcodigoProducto.SelectedIndex != 0 && txtProducto.Text != null && txtCantidad.Text != null && txtCostoTotal.Text != null && DDLproveedor.SelectedIndex !=0 && txtCostoProducto.Text != null)
                    {
                        bool agregado = Transaccion.agregarEntrada(Objeto);
                        if (agregado)
                        {
                            lblMensaje.Text += "Transaccion Agregada Exitosamente";
                            limpiar();
                            Listar();
                            IniciarLLenadoDropDownList();
                        }
                        else
                        {
                            lblMensaje.Text += Transaccion.error;
                            DDLcliente.Enabled = false;
                        }
                    }
                    else
                    {
                        lblMensaje.Text += "Favor Llenar todos los datos";
                        DDLcliente.Enabled = false;
                    }
                }
                else if (idTipoTransaccionSelected==2) {
                    //Salida
                    Objeto.Cliente1 = Convert.ToByte(DDLcliente.Text);
                    Objeto.Proveedor1 = 0;
                    Objeto.CostoProducto1 = 0;

                    if (DDLcodigoProducto.SelectedIndex != 0 && txtProducto.Text != null && txtCantidad.Text != null && txtCostoTotal.Text != null && DDLcliente.SelectedIndex !=0 )
                    {
                        bool agregado = Transaccion.agregarSalida(Objeto);
                        if (agregado)
                        {
                            lblMensaje.Text += "Transaccion Agregada Exitosamente";
                            limpiar();
                            Listar();
                            IniciarLLenadoDropDownList();
                        }
                        else
                        {
                            lblMensaje.Text += Transaccion.error;
                        }
                    }
                    else
                    {
                        lblMensaje.Text += "Favor Llenar todos los datos";
                    }
                }

                
            }
            catch (Exception ex)
            {
                lblMensaje.Text += ex+ "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {

            Consultar();
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
           
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Transaccion objeto = Transaccion.consultar(identificacion);
                if (objeto != null)
                {
                    cFecha.SelectedDate = objeto.Fecha1;
                    txtHora.Text = objeto.Hora1;
                    DDLtipoTrans.Text =Convert.ToString( objeto.IdTipoTransaccion);
                    DDLcodigoProducto.Text =Convert.ToString( objeto.CodigoProducto);
                    txtProducto.Text = objeto.Producto1;
                    DDLcliente.Text = Convert.ToString(objeto.Cliente1);
                    DDLproveedor.Text = Convert.ToString(objeto.Proveedor1);
                    txtCantidad.Text =Convert.ToString( objeto.Cantidad1);
                    txtCostoProducto.Text =Convert.ToString( objeto.CostoProducto1);
                    txtCostoTotal.Text =Convert.ToString( objeto.CostoTotal1);
                    lblMensaje.Text = "Transaccion consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Transaccion agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de la Transaccion a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Transaccion> Lista = Transaccion.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Transaccion agregados en la base de datos";
            }
            else
            {
                gvTransaccion.DataSource = Lista;
                gvTransaccion.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtHora.Text = "";
            txtProducto.Text = "";
            txtCantidad.Text = "";
            txtCostoProducto.Text = "";
            txtCostoTotal.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = Transaccion.Consultar("Select idTransaccion from Transaccion");
            DDLidentificacion.DataTextField = "idTransaccion";
            DDLidentificacion.DataValueField = "idTransaccion";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación Transaccion]", "0"));

            //Datos TipoTransaccion
            DDLtipoTrans.DataSource = Transaccion.Consultar("Select idTipoTrans, TipoTrans from TipoTransaccion");
            DDLtipoTrans.DataTextField = "TipoTrans";
            DDLtipoTrans.DataValueField = "idTipoTrans";
            DDLtipoTrans.DataBind();
            DDLtipoTrans.Items.Insert(0, new ListItem("[Seleccionar identificación Tipo Transaccion]", "0"));

            
        }

        private void iniciarDDLClient() {
            //Datos Cliente
            DDLcliente.DataSource = Transaccion.Consultar("Select idCliente, Nombre  from Cliente");
            DDLcliente.DataTextField = "Nombre";
            DDLcliente.DataValueField = "idCliente";
            DDLcliente.DataBind();
            DDLcliente.Items.Insert(0, new ListItem("[Seleccionar identificación Cliente]", "0"));
        }

        private void iniciarDDLProveedor() {
            //Datos Proveedor
            DDLproveedor.DataSource = Transaccion.Consultar("Select idProveedor, Nombre from ProveedorEmpresa");
            DDLproveedor.DataTextField = "Nombre";
            DDLproveedor.DataValueField = "idProveedor";
            DDLproveedor.DataBind();
            DDLproveedor.Items.Insert(0, new ListItem("[Seleccionar identificación Proveedor]", "0"));
        }

        private void iniciarDDLProducto(byte tipoTrans) {
            if (tipoTrans == 1) {
                //Datos TipoTransaccion
                DDLcodigoProducto.DataSource = Transaccion.Consultar("Select codigoProducto,Nombre from ProductoEmpresa Except select codigoProducto, Producto from Transaccion");
                DDLcodigoProducto.DataTextField = "Nombre";
                DDLcodigoProducto.DataValueField = "codigoProducto";
                DDLcodigoProducto.DataBind();
                DDLcodigoProducto.Items.Insert(0, new ListItem("[Seleccionar identificación Producto]", "0"));
            } else if (tipoTrans==2) {
                //Datos TipoTransaccion
                DDLcodigoProducto.DataSource = Transaccion.Consultar("Select codigoProducto, Nombre from ProductoEmpresa ");
                DDLcodigoProducto.DataTextField = "Nombre";
                DDLcodigoProducto.DataValueField = "codigoProducto";
                DDLcodigoProducto.DataBind();
                DDLcodigoProducto.Items.Insert(0, new ListItem("[Seleccionar identificación Producto]", "0"));
            }
            
        }
        

        protected void DDLtipoTransaccion_SelectedIndexChanged(object sender, EventArgs e)
        {
            byte TipoTransaccionSelected = Convert.ToByte(DDLtipoTrans.Text);
            iniciarDDLProducto(TipoTransaccionSelected);
            if (TipoTransaccionSelected==2) {
                //Salida
                DDLcliente.Enabled = true;
                iniciarDDLClient();
                DDLproveedor.Enabled = false;
                txtCostoProducto.Enabled = false;


            } else if (TipoTransaccionSelected==1) {
                //Entrada
                DDLproveedor.Enabled = true;
                txtCostoProducto.Enabled = true;
                iniciarDDLProveedor();
                DDLcliente.Enabled = false;
            }

        }
    }
}