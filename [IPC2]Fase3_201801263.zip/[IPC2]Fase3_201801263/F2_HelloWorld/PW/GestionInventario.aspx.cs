﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class GestionInventario : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnInventario_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWInventario.aspx");
        }

        protected void btnGestionBodegas_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWBodega.aspx");
        }

        protected void btnGestiondeCostos_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWProductoEmpresa.aspx");
        }

        protected void btnTransacciones_Click(object sender, EventArgs e)
        {
            Response.Redirect("pwTransaccion.aspx");
        }

        protected void btnInformes_Click(object sender, EventArgs e)
        {
            Response.Redirect("pwInformeInventarioPorBodegas.aspx");
        }
    }
}