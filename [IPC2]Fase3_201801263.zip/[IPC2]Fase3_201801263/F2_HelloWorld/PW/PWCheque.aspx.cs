﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWCheque : System.Web.UI.Page
    {
        GD_Cheque Cheque = new GD_Cheque();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Cheque Objeto = new Cheque();
                Objeto.Banco1 = txtBanco.Text;
                Objeto.CuentaBanco = txtCuentaBancaria.Text;
                Objeto.IdEmpleado = Convert.ToByte(DDLfirmaEmpleado.Text);

                if (txtBanco.Text != null && txtCuentaBancaria.Text != null && DDLfirmaEmpleado.SelectedIndex !=0)
                {
                    bool agregado = Cheque.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Cheque Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Cheque.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte Cheque a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string Banco = txtBanco.Text;
                    string CuenteBanco = txtCuentaBancaria.Text;
                    byte idEmpleado = Convert.ToByte( DDLfirmaEmpleado.Text);


                    Cheque.editar(identificacion, Banco, CuenteBanco,idEmpleado);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);


                    Cheque.eliminar(identificacion);
                    lblMensaje.Text = "Cheque Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación del Cheque a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación del Cheque a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                byte identificacion = Convert.ToByte( DDLidentificacion.Text);

                Cheque objeto = Cheque.consultar(identificacion);
                if (objeto != null)
                {
                    txtBanco.Text = objeto.Banco1;
                    txtCuentaBancaria.Text = objeto.CuentaBanco;
                    DDLfirmaEmpleado.Text = Convert.ToString(objeto.IdEmpleado);
                    lblMensaje.Text = "Cheque consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Cheques agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación Cheque a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Cheque> Lista = Cheque.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Cheque agregados en la base de datos";
            }
            else
            {
                gvCheque.DataSource = Lista;
                gvCheque.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtBanco.Text = "";
            txtCuentaBancaria.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = Cheque.Consultar("Select numCheque from Cheque");
            DDLidentificacion.DataTextField = "numCheque";
            DDLidentificacion.DataValueField = "numCheque";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));

            //Datos idPresentacionProducto
            DDLfirmaEmpleado.DataSource = Cheque.Consultar("Select idEmpleado, Nombre from Empleado");
            DDLfirmaEmpleado.DataTextField = "Nombre";
            DDLfirmaEmpleado.DataValueField = "idEmpleado";
            DDLfirmaEmpleado.DataBind();
            DDLfirmaEmpleado.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWEmpleado.aspx");
        }
    }
}