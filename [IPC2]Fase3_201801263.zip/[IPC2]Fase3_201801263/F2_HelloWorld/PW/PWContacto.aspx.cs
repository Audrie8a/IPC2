﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWContacto : System.Web.UI.Page
    {
        GD_Contacto Contacto = new GD_Contacto();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Contacto Objeto = new Contacto();
                Objeto.DPI1 = Convert.ToInt32(txtDPI.Text);
                Objeto.Nombre1 = txtNombre.Text;
                Objeto.Celular1 = txtCelular.Text;
                Objeto.Telefono1 = txtTelefono.Text;
                Objeto.Extension1 = txtExtend.Text;
                Objeto.Email1 = txtEmail.Text;
                Objeto.DireccionOff1 = txtDireccionO.Text;
                Objeto.IdCliente = Convert.ToByte(DDLcliente.Text);
                Objeto.IdTipoContacto = Convert.ToByte(DDLcontacto.Text);

                if (txtCelular.Text != null && txtDireccionO.Text != null && txtDPI.Text != null && txtEmail.Text != null && txtExtend.Text != null && txtNombre.Text != null
                    && txtTelefono.Text != null && DDLcontacto.SelectedIndex !=0 && DDLcliente.SelectedIndex != 0)
                {
                    bool agregado = Contacto.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Contacto Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Contacto.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte Contacto a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    int DPI1 = Convert.ToInt32(txtDPI.Text);
                    string Nombre1 = txtNombre.Text;
                    string Celular1 = txtCelular.Text;
                    string Telefono1 = txtTelefono.Text;
                    string Extension1 = txtExtend.Text;
                    string Email1 = txtEmail.Text;
                    string DireccionOff1 = txtDireccionO.Text;
                    byte IdCliente = Convert.ToByte(DDLcliente.Text);
                    byte IdTipoContacto = Convert.ToByte(DDLcontacto.Text);

                    Contacto.editar(identificacion, DPI1, Nombre1, Celular1, Telefono1, Extension1, Email1, DireccionOff1, IdCliente, IdTipoContacto);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Contacto.eliminar(identificacion);
                    lblMensaje.Text = "Contacto Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de la Presentación del Producto a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de la Presentación del Producto a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Contacto Objeto = Contacto.consultar(identificacion);
                if (Objeto != null)
                {
                    txtDPI.Text = Convert.ToString(Objeto.DPI1);
                    txtNombre.Text = Objeto.Nombre1;
                    txtCelular.Text = Objeto.Celular1;
                    txtTelefono.Text = Objeto.Telefono1;
                    txtExtend.Text = Objeto.Extension1;
                    txtEmail.Text = Objeto.Email1;
                    txtDireccionO.Text = Objeto.DireccionOff1;
                    DDLcliente.Text =Convert.ToString( Objeto.IdCliente);
                    DDLcontacto.Text =Convert.ToString( Objeto.IdTipoContacto);
                    lblMensaje.Text = "Contacto consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Contacto agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de Contacto a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Contacto> Lista = Contacto.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Contacto agregados en la base de datos";
            }
            else
            {
                gvContacto.DataSource = Lista;
                gvContacto.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtCelular.Text = "";
            txtDireccionO.Text = "";
            txtDPI.Text = "";
            txtEmail.Text = "";
            txtExtend.Text = "";
            txtNombre.Text = "";
            txtTelefono.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = Contacto.Consultar("Select idContacto from Contacto");
            DDLidentificacion.DataTextField = "idContacto";
            DDLidentificacion.DataValueField = "idContacto";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLcliente.DataSource = Contacto.Consultar("Select idCliente from Cliente");
            DDLcliente.DataTextField = "idCliente";
            DDLcliente.DataValueField = "idCliente";
            DDLcliente.DataBind();
            DDLcliente.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLcontacto.DataSource = Contacto.Consultar("Select idTipoContacto, TipoContacto from TipoContacto");
            DDLcontacto.DataTextField = "TipoContacto";
            DDLcontacto.DataValueField = "idTipoContacto";
            DDLcontacto.DataBind();
            DDLcontacto.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }
    }
}