﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class pwUbicacionProductoGestion : System.Web.UI.Page
    {
        GD_UbicacionProductoGestion UbicacionProductoGestion = new GD_UbicacionProductoGestion();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                UbicacionProductoGestion Objeto = new UbicacionProductoGestion();
                Objeto.CodigoProducto =Convert.ToByte( DDLproducto.Text);
                Objeto.Ubicacion1 = DDLidBodega.Text + DDLPasillo.Text + DDLestante.Text + DDLnivel.Text;
                Objeto.Cantidad1 =Convert.ToInt32( txtCantidad.Text);

                if (txtCantidad.Text != null && DDLidBodega.SelectedIndex != 0 && DDLestante.SelectedIndex != 0
                    && DDLnivel.SelectedIndex != 0 && DDLPasillo.SelectedIndex != 0 && DDLproducto.SelectedIndex != 0)
                {
                    bool agregado = UbicacionProductoGestion.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Producto Asignado a una ubicación Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += UbicacionProductoGestion.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void DDLidBodega_SelectedIndexChanged(object sender, EventArgs e)
        {
            byte BodegaSelected = Convert.ToByte(DDLidBodega.Text);

            //Datos Pasillo            
            DDLPasillo.DataSource = UbicacionProductoGestion.ConsultarPasillo("Select numPasillo from Pasillo where ", BodegaSelected);
            DDLPasillo.DataTextField = "numPasillo";
            DDLPasillo.DataValueField = "numPasillo";
            DDLPasillo.DataBind();
            DDLPasillo.Items.Insert(0, new ListItem("[Seleccionar identificación Pasillo]", "0"));

        }
        protected void DDLPasillo_SelectedIndexChanged(object sender, EventArgs e)
        {
            int PasilloSelected = Convert.ToInt32(DDLPasillo.Text);
            //Datos Estante
            DDLestante.DataSource = UbicacionProductoGestion.ConsultarEstante("Select identificacion from Estante where ", PasilloSelected);
            DDLestante.DataTextField = "identificacion";
            DDLestante.DataValueField = "identificacion";
            DDLestante.DataBind();
            DDLestante.Items.Insert(0, new ListItem("[Seleccionar identificación Estante]", "0"));


        }
        protected void DDLEstante_SelectedIndexChanged(object sender, EventArgs e)
        {
            string EstanteSelected = DDLestante.Text;
            //Datos Nivel
            DDLnivel.DataSource = UbicacionProductoGestion.ConsultarNivel("Select  numNivel from Nivel where ", EstanteSelected);
            DDLnivel.DataTextField = "numNivel";
            DDLnivel.DataValueField = "numNivel";
            DDLnivel.DataBind();
            DDLnivel.Items.Insert(0, new ListItem("[Seleccionar identificación Nivel]", "0"));
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte la Ubicación del producto a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidBodega.Text);
                    byte codigoProducto = Convert.ToByte(DDLproducto.Text);
                    string ubicacion = DDLidBodega.Text + DDLPasillo.Text + DDLestante.Text + DDLnivel.Text;
                    int Cantidad = Convert.ToInt32(txtCantidad.Text);

                    UbicacionProductoGestion.editar(codigoProducto,ubicacion,Cantidad,identificacion);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    UbicacionProductoGestion.eliminar(identificacion);
                    lblMensaje.Text = "Ubicación del Producto Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar el código del Producto a eliminar ubicación";
                }
                 
            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar el código del Producto a eliminar ubicación"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            List<UbicacionProductoGestion> Lista = UbicacionProductoGestion.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Ubicacion de Productos agregados en la base de datos";
            }
            else
            {
                gvUbicacionProducto.DataSource = Lista;
                gvUbicacionProducto.DataBind();
            }
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                UbicacionProductoGestion objeto = UbicacionProductoGestion.consultar(identificacion);
                if (objeto != null)
                {
                    lblTipoGestion.Text = objeto.TipoGestio;
                    lblIDgestion.Text = Convert.ToString(objeto.IdGestion);
                    DDLproducto.Text =Convert.ToString( objeto.CodigoProducto);
                    lblUbicacion.Text = Convert.ToString(objeto.Ubicacion1);
                    txtCantidad.Text = Convert.ToString(objeto.Cantidad1);

                    lblMensaje.Text = "Ubicacion Producto consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Ubicación de Productos agregados a la base de datos con ese código";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de la Ubicación a buscar"; }
        }

        //Metodo para listaProducto
        public void Listar()
        {
            List<UbicacionProductoGestion> Lista = UbicacionProductoGestion.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Ubicadión de Productos agregados en la base de datos";
            }
            else
            {
                gvUbicacionProducto.DataSource = Lista;
                gvUbicacionProducto.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtCantidad.Text = "";
            lblIDgestion.Text = "";
            lblTipoGestion.Text = "";
            lblUbicacion.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos Presentación Producto
            DDLidentificacion.DataSource = UbicacionProductoGestion.Consultar("Select idUbicacion from UbicacionProductoSaldo ");
            DDLidentificacion.DataTextField = "idUbicacion";
            DDLidentificacion.DataValueField = "idUbicacion";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar]", "0"));

            //Datos codigoProducto
            DDLproducto.DataSource = UbicacionProductoGestion.Consultar("Select P.codigoProducto from ProductoEmpresa as P intersect select T.codigoProducto  from Transaccion as T");
            DDLproducto.DataTextField = "codigoProducto";
            DDLproducto.DataValueField = "codigoProducto";
            DDLproducto.DataBind();
            DDLproducto.Items.Insert(0, new ListItem("[Seleccionar identificación Cliente]", "0"));

            //Datos Bodega
            DDLidBodega.DataSource = UbicacionProductoGestion.Consultar("Select codigoBodega from Bodega");
            DDLidBodega.DataTextField = "codigoBodega";
            DDLidBodega.DataValueField = "codigoBodega";
            DDLidBodega.DataBind();
            DDLidBodega.Items.Insert(0, new ListItem("[Seleccionar identificación Cliente]", "0"));
        }
    }
}