﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWProveedorEmpresa : System.Web.UI.Page
    {
        GD_ProveedorEmpresa ProveedorEmpresa = new GD_ProveedorEmpresa();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        //Botón Agregar
        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                ProveedorEmpresa Objeto = new ProveedorEmpresa();
                Objeto.NIT1= txtNITp.Text;
                Objeto.Nombre1 = txtNombreP.Text;
                Objeto.Direccion1 = txtDireccionP.Text;
                Objeto.Telefono1 = txtTelefonoP.Text;
                Objeto.ContactoEncargado1 = txtContactoEP.Text;
                Objeto.LimiteCredito1 = Convert.ToInt32(txtLimiteCreditoP.Text);
                Objeto.Correo1= txtCorreoP.Text;
                Objeto.IdestadoProveedor= Convert.ToByte(DDLestadoProvedor.Text);
                

                if (txtNITp.Text != null && txtNombreP.Text != null && txtDireccionP.Text != null && txtTelefonoP.Text != null && txtContactoEP.Text != null
                    && txtLimiteCreditoP.Text != null && txtCorreoP.Text != null && DDLestadoProvedor.SelectedIndex != 0)
                {
                    bool agregado = ProveedorEmpresa.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Proveedor Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += ProveedorEmpresa.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }
        //Botón Consultar
        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacionP.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacionP.Text);


                    ProveedorEmpresa.eliminar(identificacion);
                    lblMensaje.Text = "Proveedor Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación del Proveedor a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación del Cliente a eliminar"; }
        }

        //Botón para Editar
        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacionP.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte el Proveedor a Editar";
            }
            else
            {
                try
                {
                    //if (txtNITclienteE.Text.Length !=0) { }



                    byte identificacion = Convert.ToByte(DDLidentificacionP.Text);
                    string Nit = txtNITp.Text;
                    string NOMBRE = txtNombreP.Text;
                    string DIRECCION = txtDireccionP.Text;
                    string TELEFONO = txtTelefonoP.Text;
                    string CONTACTO_ENCARGADO = txtContactoEP.Text;
                    string CORREO = txtCorreoP.Text;
                    int LIMITE_CREDITO = Convert.ToInt32(txtLimiteCreditoP.Text);
                    byte EstadoProveedor = Convert.ToByte(DDLestadoProvedor.Text);

                    ProveedorEmpresa.editar(identificacion, Nit, NOMBRE, DIRECCION, TELEFONO, CONTACTO_ENCARGADO, LIMITE_CREDITO, CORREO,EstadoProveedor);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        //Botón para Listar 
        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacionP.Text);

                ProveedorEmpresa objeto= ProveedorEmpresa.consultar(identificacion);
                if (objeto != null)
                {
                    txtNITp.Text = objeto.NIT1;
                    txtNombreP.Text = objeto.Nombre1;
                    txtDireccionP.Text = objeto.Direccion1;
                    txtTelefonoP.Text = objeto.Telefono1;
                    txtContactoEP.Text = Convert.ToString(objeto.ContactoEncargado1);
                    txtLimiteCreditoP.Text = Convert.ToString(objeto.LimiteCredito1);
                    txtCorreoP.Text = objeto.Correo1;
                    DDLestadoProvedor.Text = Convert.ToString(objeto.IdestadoProveedor);                    
                    lblMensaje.Text = "Cliente consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay proveedores agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación del Proveedor a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<ProveedorEmpresa> Lista = ProveedorEmpresa.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Proveedores agregados en la base de datos";
            }
            else
            {
                gvProveedores.DataSource = Lista;
                gvProveedores.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtNITp.Text = "";
            txtNombreP.Text = "";
            txtDireccionP.Text = "";
            txtTelefonoP.Text = "";
            txtContactoEP.Text = "";
            txtLimiteCreditoP.Text = "";
            txtCorreoP.Text = "";            
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {

            //Datos EstadoProveedor
            DDLestadoProvedor.DataSource = ProveedorEmpresa.Consultar("Select idEstadoProveedro, EstadoProveedor from EstadoProveedor");
            DDLestadoProvedor.DataTextField = "EstadoProveedor";
            DDLestadoProvedor.DataValueField = "idEstadoProveedro";
            DDLestadoProvedor.DataBind();
            DDLestadoProvedor.Items.Insert(0, new ListItem("[Seleccionar]", "0"));
           

            //Datos idProveedor
            DDLidentificacionP.DataSource = ProveedorEmpresa.Consultar("Select idProveedor from ProveedorEmpresa");
            DDLidentificacionP.DataTextField = "idProveedor";
            DDLidentificacionP.DataValueField = "idProveedor";
            DDLidentificacionP.DataBind();
            DDLidentificacionP.Items.Insert(0, new ListItem("[Seleccionar identificación Cliente]", "0"));
        }
    }
}