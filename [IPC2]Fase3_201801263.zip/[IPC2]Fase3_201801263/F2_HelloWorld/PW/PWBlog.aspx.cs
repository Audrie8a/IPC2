﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWBlog : System.Web.UI.Page
    {
        GD_Blog Blog = new GD_Blog();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Blog Objeto = new Blog();
                Objeto.Descripcion1 = txtDescrip.Text;

                if (txtDescrip.Text != null)
                {
                    bool agregado = Blog.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Blog Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Blog.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte Blog a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string Descrip = txtDescrip.Text;

                    Blog.editar(identificacion, Descrip);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Blog.eliminar(identificacion);
                    lblMensaje.Text = " Blog Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de Blog a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de Blog a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Blog objeto = Blog.consultar(identificacion);
                if (objeto != null)
                {
                    txtDescrip.Text = objeto.Descripcion1;
                    lblMensaje.Text = "Blog consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Blogs agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de Blog a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Blog> Lista = Blog.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Blogs agregados en la base de datos";
            }
            else
            {
                gvBlog.DataSource = Lista;
                gvBlog.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtDescrip.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = Blog.Consultar("Select idBlog from Blog");
            DDLidentificacion.DataTextField = "idBlog";
            DDLidentificacion.DataValueField = "idBlog";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }
    }
}