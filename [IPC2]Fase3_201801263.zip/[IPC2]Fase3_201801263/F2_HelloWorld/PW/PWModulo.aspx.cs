﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWModulo : System.Web.UI.Page
    {
        GD_Modulo Modulo = new GD_Modulo();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Modulo Objeto = new Modulo();
                Objeto.Nombre1 = txtNombre.Text;
                Objeto.Abreviatura1 = txtAbre.Text;
                Objeto.Descripcion1 = txtDescrip.Text;
                Objeto.IdTipoModulo = Convert.ToByte(DDLtipoMod.Text);
                Objeto.IdEstadoModulo = Convert.ToByte(DDLestadoMod.Text);


                if (txtNombre.Text != null && txtAbre.Text != null && txtDescrip.Text != null && DDLestadoMod.SelectedIndex !=0 && DDLtipoMod.SelectedIndex!=0)
                {
                    bool agregado = Modulo.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Modulo Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Modulo.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte Modulo a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string Nom = txtNombre.Text;
                    string Abr = txtAbre.Text;
                    string Desc = txtDescrip.Text;
                    byte idTipMod = Convert.ToByte(DDLtipoMod.Text);
                    byte idEstaMod = Convert.ToByte(DDLestadoMod.Text);

                    Modulo.editar(identificacion, Nom, Abr, Desc, idTipMod, idEstaMod);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Modulo.eliminar(identificacion);
                    lblMensaje.Text = "Modulo Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de Modulo a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de Modulo a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Modulo objeto = Modulo.consultar(identificacion);
                if (objeto != null)
                {
                    txtNombre.Text = objeto.Nombre1;
                    txtAbre.Text = objeto.Abreviatura1;
                    txtDescrip.Text = objeto.Descripcion1;
                    DDLtipoMod.Text = Convert.ToString(objeto.IdTipoModulo);
                    DDLestadoMod.Text = Convert.ToString(objeto.IdEstadoModulo);
                    lblMensaje.Text = "Modulo consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Modulo agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación Modulo a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Modulo> Lista = Modulo.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Modulo agregados en la base de datos";
            }
            else
            {
                gvModulo.DataSource = Lista;
                gvModulo.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtNombre.Text = "";
            txtDescrip.Text = "";
            txtAbre.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = Modulo.Consultar("Select codigoModulo from Modulo");
            DDLidentificacion.DataTextField = "codigoModulo";
            DDLidentificacion.DataValueField = "codigoModulo";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLtipoMod.DataSource = Modulo.Consultar("Select idTipoModulo, TipoModulo from TipoModulo");
            DDLtipoMod.DataTextField = "TipoModulo";
            DDLtipoMod.DataValueField = "idTipoModulo";
            DDLtipoMod.DataBind();
            DDLtipoMod.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLestadoMod.DataSource = Modulo.Consultar("Select idEstadoMOdulo, EstadoModulo from EstadoModulo");
            DDLestadoMod.DataTextField = "EstadoModulo";
            DDLestadoMod.DataValueField = "idEstadoMOdulo";
            DDLestadoMod.DataBind();
            DDLestadoMod.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWPagoSuscripcion.aspx");
        }
    }
}