﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWPagoSuscripcion : System.Web.UI.Page
    {
        GD_PagoSuscripcion PagoSuscripcion = new GD_PagoSuscripcion();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                PagoSuscripcion Objeto = new PagoSuscripcion();
                Objeto.IdTipoSuscripcion = Convert.ToByte(DDLtipoSus.Text);
                Objeto.PrecioModulo1 = Convert.ToInt32(txtPrecioMod.Text);
                Objeto.IdRangoUsuario = Convert.ToByte(DDLrangoUsuario.Text);
                Objeto.CodigoModulo = Convert.ToByte(DDLcodigoModulo.Text);
                Objeto.IdListaPrecio = Convert.ToByte(DDLidListaPrecio.Text);

                if (txtPrecioMod.Text != null && DDLcodigoModulo.Text != null && DDLidListaPrecio.Text != null && DDLrangoUsuario.Text != null && DDLtipoSus.Text != null)
                {
                    bool agregado = PagoSuscripcion.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += " PagoSuscripcion Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += PagoSuscripcion.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte la PagoSuscripcion a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    byte IdTipoSuscripcion = Convert.ToByte(DDLtipoSus.Text);
                    int PrecioModulo1 = Convert.ToInt32(txtPrecioMod.Text);
                    byte IdRangoUsuario = Convert.ToByte(DDLrangoUsuario.Text);
                    byte CodigoModulo = Convert.ToByte(DDLcodigoModulo.Text);
                    byte IdListaPrecio = Convert.ToByte(DDLidListaPrecio.Text);

                    PagoSuscripcion.editar(identificacion, IdTipoSuscripcion,PrecioModulo1,IdRangoUsuario,CodigoModulo,IdListaPrecio);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    PagoSuscripcion.eliminar(identificacion);
                    lblMensaje.Text = "PagoSuscripcion Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de PagoSuscripcion a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de PagoSuscripcion a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                PagoSuscripcion Objeto = PagoSuscripcion.consultar(identificacion);
                if (Objeto != null)
                {
                    DDLtipoSus.Text=Convert.ToString(Objeto.IdTipoSuscripcion);
                    txtPrecioMod.Text = Convert.ToString(Objeto.PrecioModulo1);
                    DDLrangoUsuario.Text = Convert.ToString(Objeto.IdRangoUsuario);
                    DDLcodigoModulo.Text = Convert.ToString(Objeto.CodigoModulo);
                    DDLidListaPrecio.Text = Convert.ToString(Objeto.IdListaPrecio);                                      
                    lblMensaje.Text = "PagoSuscripcion consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay PagoSuscripcion agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de PagoSuscripcion a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<PagoSuscripcion> Lista = PagoSuscripcion.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay PagoSuscripcion agregados en la base de datos";
            }
            else
            {
                gvPagoSus.DataSource = Lista;
                gvPagoSus.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtPrecioMod.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = PagoSuscripcion.Consultar("Select idPagoSuscripcion from PagoSuscripcion");
            DDLidentificacion.DataTextField = "idPagoSuscripcion";
            DDLidentificacion.DataValueField = "idPagoSuscripcion";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLcodigoModulo.DataSource = PagoSuscripcion.Consultar("Select codigoModulo, Nombre from Modulo");
            DDLcodigoModulo.DataTextField = "Nombre";
            DDLcodigoModulo.DataValueField = "codigoModulo";
            DDLcodigoModulo.DataBind();
            DDLcodigoModulo.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLidListaPrecio.DataSource = PagoSuscripcion.Consultar("Select idListaPrecio from ListaPrecio");
            DDLidListaPrecio.DataTextField = "idListaPrecio";
            DDLidListaPrecio.DataValueField = "idListaPrecio";
            DDLidListaPrecio.DataBind();
            DDLidListaPrecio.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLrangoUsuario.DataSource = PagoSuscripcion.Consultar("Select idRangoUsuario,RangoUsuario from RangoUsuario");
            DDLrangoUsuario.DataTextField = "RangoUsuario";
            DDLrangoUsuario.DataValueField = "idRangoUsuario";
            DDLrangoUsuario.DataBind();
            DDLrangoUsuario.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLtipoSus.DataSource = PagoSuscripcion.Consultar("Select idTipoSuscripcion, TipoSuscripcion from TipoSuscripcion");
            DDLtipoSus.DataTextField = "TipoSuscripcion";
            DDLtipoSus.DataValueField = "idTipoSuscripcion";
            DDLtipoSus.DataBind();
            DDLtipoSus.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWListaPrecio.aspx");
        }
    }
}