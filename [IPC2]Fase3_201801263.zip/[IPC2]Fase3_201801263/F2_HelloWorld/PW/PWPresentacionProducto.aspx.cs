﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWPresentacionProducto : System.Web.UI.Page
    {
        GD_PresentacionProducto PresentacionProducto = new GD_PresentacionProducto();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        //Botón Agregar
        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                PresentacionProducto Objeto = new PresentacionProducto();
                Objeto.PresentacionP= txtPresentacionProducto.Text; 

                if (txtPresentacionProducto.Text != null )
                {
                    bool agregado = PresentacionProducto.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Presentación Producto Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += PresentacionProducto.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        //Botón Consultar
        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        //Botón Editar
        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte la Presentación Producto a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string PresentacionP = txtPresentacionProducto.Text;                    

                    PresentacionProducto.editar(identificacion, PresentacionP);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        //Botón Eliminar
        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    PresentacionProducto.eliminar(identificacion);
                    lblMensaje.Text = "Presentación del Producto Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de la Presentación del Producto a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de la Presentación del Producto a eliminar"; }
        }

        //Botón Listar
        protected void btnListar_Click(object sender, EventArgs e)  
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                PresentacionProducto objeto = PresentacionProducto.consultar(identificacion);
                if (objeto != null)
                {
                    txtPresentacionProducto.Text = objeto.PresentacionP;                   
                    lblMensaje.Text = "Presentación Producto consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Presentaciones del Producto agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de la Presentación del Producto a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<PresentacionProducto> Lista = PresentacionProducto.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Presentaciones del Producto agregados en la base de datos";
            }
            else
            {
               gvPresentacionP.DataSource = Lista;
                gvPresentacionP.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtPresentacionProducto.Text = "";            
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {           
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = PresentacionProducto.Consultar("Select idPresentacionProducto, PresentacionProducto from PresentacionProducto");
            DDLidentificacion.DataTextField = "idPresentacionProducto";
            DDLidentificacion.DataValueField = "idPresentacionProducto";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación Presentación Producto]", "0"));
        }
        

    }
}