﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class pwDivisionLogicaBodega : System.Web.UI.Page
    {
        GD_DivisionLogica DivisionLogica = new GD_DivisionLogica();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
            }
            lblMensajeP.Text = "RESULTADO:  ";
            lblMensajeN.Text = "RESULTADO:  ";
            lblMensajeE.Text = "RESULTADO:  ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPasillo
            DDLidPasillo.DataSource = DivisionLogica.Consultar("Select numPasillo from Pasillo");
            DDLidPasillo.DataTextField = "numPasillo";
            DDLidPasillo.DataValueField = "numPasillo";
            DDLidPasillo.DataBind();
            DDLidPasillo.Items.Insert(0, new ListItem("[Seleccionar identificación Estante]", "0"));
            //Datos idEstante
            DDLidEstante.DataSource = DivisionLogica.Consultar("Select identificacion from Estante");
            DDLidEstante.DataTextField = "identificacion";
            DDLidEstante.DataValueField = "identificacion";
            DDLidEstante.DataBind();
            DDLidEstante.Items.Insert(0, new ListItem("[Seleccionar identificación Estante]", "0"));
            // Datos idNivel
            DDLidNivel.DataSource = DivisionLogica.Consultar("Select numNivel from Nivel");
            DDLidNivel.DataTextField = "numNivel";
            DDLidNivel.DataValueField = "numNivel";
            DDLidNivel.DataBind();
            DDLidNivel.Items.Insert(0, new ListItem("[Seleccionar identificación Nivel]", "0"));

            //Datos Pasillo
            DDLpasillo.DataSource = DivisionLogica.Consultar("Select numPasillo from Pasillo");
            DDLpasillo.DataTextField = "numPasillo";
            DDLpasillo.DataValueField = "numPasillo";
            DDLpasillo.DataBind();
            DDLpasillo.Items.Insert(0, new ListItem("[Seleccionar identificación Estante]", "0"));
            //Datos Estante
            DDLestante.DataSource = DivisionLogica.Consultar("Select identificacion from Estante");
            DDLestante.DataTextField = "identificacion";
            DDLestante.DataValueField = "identificacion";
            DDLestante.DataBind();
            DDLestante.Items.Insert(0, new ListItem("[Seleccionar identificación Estante]", "0"));
            // Datos Nivel
            DDLbodega.DataSource = DivisionLogica.Consultar("Select codigoBodega from Bodega");
            DDLbodega.DataTextField = "codigoBodega";
            DDLbodega.DataValueField = "codigoBodega";
            DDLbodega.DataBind();
            DDLbodega.Items.Insert(0, new ListItem("[Seleccionar identificación Bodega]", "0"));
        }


//------------------------------------------PASILLO-----------------------------------------------------
        protected void btnAgregarP_Click(object sender, EventArgs e)
        {
            try
            {
                Pasillo Objeto = new Pasillo();
                Objeto.NumPasillo=Convert.ToInt32( txtIdentificacionPasillo.Text);
                Objeto.LargoPasillo = Convert.ToInt32(txtLargoPasillo.Text);
                Objeto.AnchoPasillo1 = Convert.ToInt32(txtAnchoPasillo.Text);
                Objeto.IdBodega = Convert.ToByte(DDLbodega.Text);


                if (txtIdentificacionPasillo.Text != null && txtLargoPasillo.Text != null && txtAnchoPasillo.Text != null && DDLbodega.SelectedIndex !=0)
                {
                    bool agregado = DivisionLogica.agregarPasillo(Objeto);
                    if (agregado)
                    {
                        lblMensajeP.Text += "Pasillo Agregado Exitosamente";
                        limpiarP();
                        ListarP();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensajeP.Text += DivisionLogica.error;
                    }
                }
                else
                {
                    lblMensajeP.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensajeP.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnEditarP_Click(object sender, EventArgs e)
        {
            if (DDLidPasillo.SelectedIndex == 0)
            {
                lblMensajeP.Text += "Favor consulte el Pasillo a Editar";
            }
            else
            {
                try
                {
                    int identificacion = Convert.ToInt32(DDLidPasillo.Text);
                    int Largo = Convert.ToInt32(txtLargoPasillo.Text);
                    int Ancho = Convert.ToInt32(txtAnchoPasillo.Text);
                    byte Bodega = Convert.ToByte(DDLbodega.Text);
                    DivisionLogica.editarPasillo(identificacion, Largo, Ancho,Bodega);
                    ListarP();
                    IniciarLLenadoDropDownList();
                    limpiarP();
                }
                catch (Exception ex) { lblMensajeP.Text += " " + ex; }
            }
        }

        protected void btnEliminarP_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidPasillo.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidPasillo.Text);


                    DivisionLogica.eliminarPasillo(identificacion);
                    lblMensajeP.Text = "Pasillo Eliminado exitosamente";
                    ListarP();
                    IniciarLLenadoDropDownList();
                    limpiarP();
                }
                else
                {
                    lblMensajeP.Text += "Favor ingresar identificación del Pasillo a eliminar";
                }

            }
            catch (Exception) { lblMensajeP.Text += "Favor ingresar identificación del Pasillo a eliminar"; }
        }

        protected void btnListarP_Click(object sender, EventArgs e)
        {
            ListarP();
        }
        
        protected void btnConsultarP_Click(object sender, EventArgs e)
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidPasillo.Text);

                Pasillo objeto = DivisionLogica.consultarPasillo(identificacion);
                if (objeto != null)
                {
                    txtIdentificacionPasillo.Text = Convert.ToString(objeto.NumPasillo);
                    txtLargoPasillo.Text = Convert.ToString(objeto.LargoPasillo);
                    txtAnchoPasillo.Text = Convert.ToString(objeto.AnchoPasillo1);
                    DDLbodega.Text = Convert.ToString(objeto.IdBodega);
                    lblMensajeP.Text = "Pasillo consultado";
                }
                else
                {
                    lblMensajeP.Text = "No hay Pasillos agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensajeP.Text += "Favor seleccionar la identificación del Pasillo a buscar"; }
        }

        //Metodo para listaClientes
        public void ListarP()
        {
            List<Pasillo> Lista = DivisionLogica.ListarPasillo();
            if (Lista.Count == 0)
            {
                lblMensajeP.Text += "No hay Pasillos agregados en la base de datos";
            }
            else
            {
                gvListar.DataSource = Lista;
                gvListar.DataBind();
            }
        }

        //Método para limpiar
        private void limpiarP()
        {
            txtIdentificacionPasillo.Text = "";
            txtLargoPasillo.Text = "";
            txtAnchoPasillo.Text = "";
            lblMensajeP.Text = "RESULTADO: ";
        }


        //---------------------------------------ESTANTE----------------------------------------------------------

        protected void btnAgregarE_Click(object sender, EventArgs e)
        {
            try
            {
                Estante Objeto = new Estante();
                Objeto.Identificacion = txtIdentificaciónE.Text;
                Objeto.Largo1 = Convert.ToInt32(txtLargoE.Text);
                Objeto.Ancho1 = Convert.ToInt32(txtAnchoE.Text);
                Objeto.Altura1 = Convert.ToInt32(txtAlturaE.Text);
                Objeto.IdPasillo = Convert.ToInt32(DDLpasillo.Text);


                if (txtIdentificaciónE.Text != null && txtLargoE.Text != null && txtAnchoE.Text != null && txtAlturaE.Text != null && DDLpasillo.SelectedIndex != 0)
                {
                    bool agregado = DivisionLogica.agregarEstante(Objeto);
                    if (agregado)
                    {
                        lblMensajeP.Text += "Estante Agregado Exitosamente";
                        limpiarE();
                        ListarE();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensajeE.Text += DivisionLogica.error;
                    }
                }
                else
                {
                    lblMensajeE.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensajeE.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnEditarE_Click(object sender, EventArgs e)
        {
            if (DDLidEstante.SelectedIndex == 0)
            {
                lblMensajeE.Text += "Favor consulte el Estante a Editar";
            }
            else
            {
                try
                {
                    string identificacion = DDLidEstante.Text;
                    int Largo = Convert.ToInt32(txtLargoE.Text);
                    int Ancho = Convert.ToInt32(txtAnchoE.Text);
                    int Alto = Convert.ToInt32(txtAlturaE.Text);
                    int Pasillo = Convert.ToByte(DDLpasillo.Text);
                    DivisionLogica.editarEstante(identificacion,Largo, Ancho, Alto, Pasillo);
                    ListarE();
                    IniciarLLenadoDropDownList();
                    limpiarE();
                }
                catch (Exception ex) { lblMensajeE.Text += " " + ex; }
            }
        }

        protected void btnEliminarE_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidEstante.SelectedIndex != 0)
                {
                    string identificacion = DDLidEstante.Text;


                    DivisionLogica.eliminarEstante(identificacion);
                    lblMensajeP.Text = "Estante Eliminado exitosamente";
                    ListarE();
                    IniciarLLenadoDropDownList();
                    limpiarE();
                }
                else
                {
                    lblMensajeE.Text += "Favor ingresar identificación del Estante a eliminar";
                }

            }
            catch (Exception) { lblMensajeE.Text += "Favor ingresar identificación del Estante a eliminar"; }
        }

        protected void btnConsultarE_Click(object sender, EventArgs e)
        {
            try
            {
                String identificacion = DDLidEstante.Text;

                Estante objeto = DivisionLogica.consultarEstante(identificacion);
                if (objeto != null)
                {
                    txtIdentificaciónE.Text = objeto.Identificacion;
                    txtLargoE.Text = Convert.ToString(objeto.Largo1);
                    txtAnchoE.Text= Convert.ToString(objeto.Ancho1);
                    txtAlturaE.Text= Convert.ToString(objeto.Altura1);
                    DDLpasillo.Text= Convert.ToString(objeto.IdPasillo);
                    lblMensajeE.Text = "Estante consultado";
                }
                else
                {
                    lblMensajeE.Text = "No hay Estantes agregados a la base de datos";
                }
            }
            catch (Exception) { lblMensajeE.Text += "Favor seleccionar la identificación del Estante a buscar"; }
        }

        //Metodo para listaClientes
        public void ListarE()
        {
            List<Estante> Lista = DivisionLogica.ListarEstante();
            if (Lista.Count == 0)
            {
                lblMensajeP.Text += "No hay Estantes agregados en la base de datos";
            }
            else
            {
                gvListar.DataSource = Lista;
                gvListar.DataBind();
            }
        }

        //Método para limpiar
        private void limpiarE()
        {
            txtIdentificaciónE.Text = "";
            txtLargoE.Text = "";
            txtAnchoE.Text = "";
            txtAlturaE.Text = "";
            lblMensajeE.Text = "RESULTADO: ";
        }

//-----------------------------------------------NIVEL------------------------------------------------------------
        protected void btnAgregarN_Click(object sender, EventArgs e)
        {
            try
            {
                Nivel Objeto = new Nivel();
                Objeto.NumNivel= Convert.ToInt32(txtIdentificacionN.Text);
                Objeto.Altura1 = Convert.ToInt32(txtAlturaN.Text);
                Objeto.IdEstante = DDLestante.Text;
                Objeto.Largo1= Convert.ToInt32(txtLargoN.Text);
                Objeto.Ancho1= Convert.ToInt32(txtAnchoN.Text);
                
                if (txtIdentificacionN.Text != null && txtLargoN.Text != null && txtAnchoN.Text != null && txtAlturaN.Text != null && DDLestante.SelectedIndex != 0)
                {
                    bool agregado = DivisionLogica.agregarNivel(Objeto);
                    if (agregado)
                    {
                        lblMensajeN.Text += "Nivel Agregado Exitosamente";
                        limpiarN();
                        ListarN();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensajeN.Text += DivisionLogica.error;
                    }
                }
                else
                {
                    lblMensajeN.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensajeN.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnEditarN_Click(object sender, EventArgs e)
        {
            if (DDLidNivel.SelectedIndex == 0)
            {
                lblMensajeN.Text += "Favor consulte el Nivel a Editar";
            }
            else
            {
                try
                {
                    int identificacion =Convert.ToInt32( DDLidNivel.Text);
                    int Alto = Convert.ToInt32(txtAlturaN.Text);
                    string Estante = DDLestante.Text;
                    int Largo = Convert.ToInt32(txtLargoN.Text);
                    int Ancho= Convert.ToInt32(txtAnchoN.Text);                    
                    DivisionLogica.editarNivel(identificacion, Alto, Largo,Ancho, Estante);
                    ListarN();
                    IniciarLLenadoDropDownList();
                    limpiarN();
                }
                catch (Exception ex) { lblMensajeN.Text += " " + ex; }
            }
        }

        protected void btnEliminarN_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidNivel.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidNivel.Text);


                    DivisionLogica.eliminarNivel(identificacion);
                    lblMensajeP.Text = "Nivel Eliminado exitosamente";
                    ListarN();
                    IniciarLLenadoDropDownList();
                    limpiarN();
                }
                else
                {
                    lblMensajeE.Text += "Favor ingresar identificación del Nivel a eliminar";
                }

            }
            catch (Exception) { lblMensajeE.Text += "Favor ingresar identificación del Nivel a eliminar"; }
        }

        //Metodo para listaClientes
        public void ListarN()
        {
            List<Nivel> Lista = DivisionLogica.ListarNivel();
            if (Lista.Count == 0)
            {
                lblMensajeN.Text += "No hay Niveles agregados en la base de datos";
            }
            else
            {
                gvListar.DataSource = Lista;
                gvListar.DataBind();
            }
        }

        //Método para limpiar
        private void limpiarN()
        {
            txtIdentificacionN.Text = "";
            txtAlturaN.Text = "";
            txtLargoN.Text = "";
            txtAnchoN.Text = "";
            lblMensajeN.Text = "RESULTADO: ";
        }

        protected void btnListarE_Click(object sender, EventArgs e)
        {
            ListarE();
        }

        protected void btnListarN_Click(object sender, EventArgs e)
        {
            ListarN();
        }

        protected void btnConsultarN_Click(object sender, EventArgs e)
        {
            try
            {
                int identificacion =Convert.ToInt32(DDLidNivel.Text);

                Nivel objeto = DivisionLogica.consultarNivel(identificacion);
                if (objeto != null)
                {
                    txtIdentificacionN.Text =Convert.ToString(objeto.NumNivel);
                    txtAlturaN.Text = Convert.ToString(objeto.Largo1);
                    txtLargoN.Text = Convert.ToString(objeto.Ancho1);
                    txtAnchoN.Text = Convert.ToString(objeto.Altura1);
                    DDLestante.Text = objeto.IdEstante;
                    lblMensajeN.Text = "Nivel consultado";
                }
                else
                {
                    lblMensajeN.Text = "No hay Niveles agregados a la base de datos";
                }
            }
            catch (Exception) { lblMensajeN.Text += "Favor seleccionar la identificación del Nivel a buscar"; }
        }
    }
}