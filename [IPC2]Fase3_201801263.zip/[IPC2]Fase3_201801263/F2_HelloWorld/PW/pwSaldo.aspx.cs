﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class pwSaldo : System.Web.UI.Page
    {
        GD_Saldo Saldo = new GD_Saldo();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Saldo Objeto = new Saldo();
                Objeto.SaldoN1= txtNombre.Text;
                Objeto.Costo1 = Convert.ToInt32(txtCostoPromedio.Text);

                if (txtNombre.Text != null && txtCostoPromedio.Text != null)
                {
                    bool agregado = Saldo.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Saldo Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Saldo.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte el Saldo a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string SaldoN = txtNombre.Text;
                    int CostoProm= Convert.ToInt32(txtCostoPromedio.Text);

                    Saldo.editar(identificacion, SaldoN, CostoProm);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Saldo.eliminar(identificacion);
                    lblMensaje.Text = "Saldo Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación del Saldo a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación del Saldo a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Saldo> Lista = Saldo.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Saldos agregados en la base de datos";
            }
            else
            {
                gvSaldo.DataSource = Lista;
                gvSaldo.DataBind();
            }
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Saldo objeto = Saldo.consultar(identificacion);
                if (objeto != null)
                {
                    txtNombre.Text = objeto.SaldoN1;
                    txtCostoPromedio.Text = Convert.ToString(objeto.Costo1);
                    lblMensaje.Text = "Saldo consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Saldos agregados a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación del Saldo a buscar"; }
        }


        //Método para limpiar
        private void limpiar()
        {
            txtNombre.Text = "";
            txtCostoPromedio.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idSaldo
            DDLidentificacion.DataSource = Saldo.Consultar("Select idSaldo from Saldo");
            DDLidentificacion.DataTextField = "idSaldo";
            DDLidentificacion.DataValueField = "idSaldo";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación Lote]", "0"));
            
        }
    }
}