﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;

namespace F2_HelloWorld
{
    public partial class pwInformeInventarioPorBodegas : System.Web.UI.Page
    {
        GD_InformeInventarioBodega InformeInventarioBodega = new GD_InformeInventarioBodega();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
            }
        }

        protected void DDLbodega_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                byte identificacion = Convert.ToByte(DDLbodega.Text);
                ListarTodo(identificacion);

            }
            catch (Exception ex) { Console.WriteLine(ex.Message);  }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            
        }

        public void ListarProducto(byte idBodega)
        {
            List<InventarioPorProducto> Lista = InformeInventarioBodega.ListarPorProducto(idBodega);
            if (Lista.Count == 0)
            {

            }
            else
            {
                gvInventarioProducto.DataSource = Lista;
                gvInventarioProducto.DataBind();
            }
        }

        public void ListarTodo(byte idBodega)
        {
            List<InformeInventarioBodega> Lista = InformeInventarioBodega.Listar(idBodega);
            if (Lista.Count == 0)
            {
               
            }
            else
            {
                gvTodo.DataSource = Lista;
                gvTodo.DataBind();
            }
        }

        

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos Presentación Producto
            DDLbodega.DataSource = InformeInventarioBodega.Consultar("Select codigoBodega from Bodega");
            DDLbodega.DataTextField = "codigoBodega";
            DDLbodega.DataValueField = "codigoBodega";
            DDLbodega.DataBind();

            //Datos Presentación Producto
            DDLProducto.DataSource = InformeInventarioBodega.Consultar("Select codigoProducto, Nombre from ProductoEmpresa");
            DDLProducto.DataTextField = "Nombre";
            DDLProducto.DataValueField = "codigoProducto";
            DDLProducto.DataBind();

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            PdfPTable pdfTable = new PdfPTable(gvTodo.HeaderRow.Cells.Count);
            foreach (GridViewRow gridViewRow in gvTodo.Rows) {
                foreach (TableCell tableCell in gridViewRow.Cells) {
                    PdfPCell pdfPCell = new PdfPCell(new Phrase(tableCell.Text));
                    pdfTable.AddCell(pdfPCell);
                }
            }

            Document pdfDocument = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
            PdfWriter.GetInstance(pdfDocument, Response.OutputStream);

            pdfDocument.Open();
            pdfDocument.Add(pdfTable);
            pdfDocument.Close();

            Response.ContentType = "application/pdf";
            Response.AppendHeader("content-disposition", "attachment;filename=InformePorBodega.pdf");
            Response.Write(pdfDocument);
            Response.Flush();
            Response.End();
        }

        protected void btnInventarioProducto_Click(object sender, EventArgs e)
        {
            PdfPTable pdfTable = new PdfPTable(gvInventarioProducto.HeaderRow.Cells.Count);
            foreach (GridViewRow gridViewRow in gvInventarioProducto.Rows)
            {
                foreach (TableCell tableCell in gridViewRow.Cells)
                {
                    PdfPCell pdfPCell = new PdfPCell(new Phrase(tableCell.Text));
                    pdfTable.AddCell(pdfPCell);
                }
            }

            Document pdfDocument = new Document(PageSize.A4, 10f, 10f, 10f, 10f);
            PdfWriter.GetInstance(pdfDocument, Response.OutputStream);

            pdfDocument.Open();
            pdfDocument.Add(pdfTable);
            pdfDocument.Close();

            Response.ContentType = "application/pdf";
            Response.AppendHeader("content-disposition", "attachment;filename=InformePorProducto.pdf");
            Response.Write(pdfDocument);
            Response.Flush();
            Response.End();
        }

        protected void DDLProducto_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                byte identificacion = Convert.ToByte(DDLProducto.Text);
                ListarProducto(identificacion);

            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
        }
    }
}