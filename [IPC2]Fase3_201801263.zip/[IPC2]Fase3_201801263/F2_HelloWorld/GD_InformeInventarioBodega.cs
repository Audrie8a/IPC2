﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_InformeInventarioBodega
    {
        public SqlConnection conexion;
        public string error;

        public GD_InformeInventarioBodega()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para consultar Todo
        public void InformeInventarioBodegaConsultar(byte ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "ObtenerDatosInventarioPorBodega";
            comando.CommandType=CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@idBodega", ID);
            try
            {
                comando.ExecuteNonQuery();
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
        }
        
        //Listar Todo
        public List<InformeInventarioBodega> Listar(byte idBodega)
        {
            List<InformeInventarioBodega> Lista = new List<InformeInventarioBodega>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "ListarInformeInventario";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@idBodega", idBodega);
            comando.ExecuteNonQuery();
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                InformeInventarioBodega Objeto = new InformeInventarioBodega();
                Objeto.IdUbicacion = registro.GetByte(0);
                Objeto.TipoGestion = registro.GetString(1);
                Objeto.IdGestion = registro.GetByte(2);
                Objeto.CodigoProducto = registro.GetByte(3);
                Objeto.Ubicacion = registro.GetString(4);
                Objeto.Cantidad1 = registro.GetInt32(5);
                Objeto.Precio1 = registro.GetInt32(6);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        public List<InventarioPorProducto> ListarPorProducto(byte codigoProducto)
        {
            List<InventarioPorProducto> Lista = new List<InventarioPorProducto>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "ListarInformeProducto";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@codigoProducto", codigoProducto);
            comando.ExecuteNonQuery();
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                InventarioPorProducto Objeto = new InventarioPorProducto();
                Objeto.CodigoProducto = registro.GetByte(0);
                Objeto.CodigoBarra = registro.GetString(1);
                Objeto.Nombre1 = registro.GetString(2);
                Objeto.Descripción1= registro.GetString(3);
                Objeto.IdPresentacionProducto = registro.GetByte(4);
                Objeto.IdClasificacionProducto= registro.GetByte(5);
                Objeto.IdEstadoProducto= registro.GetByte(6);
                Objeto.TipoGestionLetra = registro.GetString(7);
                Objeto.TipoGestionNúmero1 = registro.GetByte(8);
                Objeto.Precio1 = registro.GetInt32(9);
                Objeto.CantidadDisponible1= registro.GetInt32(10);
                Objeto.Ubicacion = registro.GetString(11);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}