﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Solicitante
    {
        public SqlConnection conexion;
        public string error;

        public GD_Solicitante()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Solicitante Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Solicitante values (@Nombre, @Descripcion);";
            comando.Parameters.AddWithValue("@Nombre", Dato.Nombre1);
            comando.Parameters.AddWithValue("@Descripcion", Dato.Descripcion1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Solicitante consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Solicitante where idSolicitante=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Solicitante Dato = new Solicitante();
                Dato.Idsolicitante = registro.GetByte(0);
                Dato.Nombre1 = registro.GetString(1);
                Dato.Descripcion1 = registro.GetString(2);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Solicitante where idSolicitante=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Solicitante> Listar()
        {
            List<Solicitante> Lista = new List<Solicitante>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Solicitante";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Solicitante Objeto = new Solicitante();
                Objeto.Idsolicitante = registro.GetByte(0);
                Objeto.Nombre1 = registro.GetString(1);
                Objeto.Descripcion1 = registro.GetString(2);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idSolicitante, string Nombre, string Descripcion)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Solicitante set Nombre=@Nombre, Descipcion=@Descripcion where idSolicitante=@idSolicitante";
            comando.Parameters.AddWithValue("@idSolicitante", idSolicitante);
            comando.Parameters.AddWithValue("@Nombre", Nombre);
            comando.Parameters.AddWithValue("@Descripcion", Descripcion);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}