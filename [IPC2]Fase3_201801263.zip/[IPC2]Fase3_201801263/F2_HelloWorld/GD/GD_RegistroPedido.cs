﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_RegistroPedido
    {
        public SqlConnection conexion;
        public string error;

        public GD_RegistroPedido() {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(RegistroPedido Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "AgregarRegistroPedido2";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@idPedido  ", Dato.IdPedido);
            comando.Parameters.AddWithValue("@codigoProducto  ", Dato.CodigoProducto);
            comando.Parameters.AddWithValue("@MontoTotal  ", Dato.MontoTotal1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public RegistroPedido consultar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Select * from RegistroPedido where idRegistroPedido=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                RegistroPedido Dato = new RegistroPedido();
                Dato.IdRegistroPedido = registro.GetByte(0);
                Dato.IdPedido = registro.GetByte(1);
                Dato.CodigoProducto = registro.GetByte(2);
                Dato.MontoTotal1 = registro.GetInt32(3);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from RegistroPedido where idRegistroPedido=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<RegistroPedido> Listar()
        {
            List<RegistroPedido> Lista = new List<RegistroPedido>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select P.idPedido,P.FechaPedido,P.FechaRecibido,P.idProveedor,R.codigoProcutoEmpresa,P.cantidad,R.MontoTotal from Pedido as P, RegistroPedido as R where R.idPedido=P.idPedido";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                RegistroPedido Objeto = new RegistroPedido();
                Objeto.IdPedido = registro.GetByte(0);
                Objeto.FechaPedido1 = registro.GetDateTime(1);
                Objeto.FechaRecibido1 = registro.GetDateTime(2);
                Objeto.IdProveedor = registro.GetByte(3);
                Objeto.CodigoProducto = registro.GetByte(4);
                Objeto.Cantidad = registro.GetInt32(5);
                Objeto.MontoTotal1 = registro.GetInt32(6);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte idRegistroPedido, byte idPedido, byte codigoProducto, int MontoTotal)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "EditarRegistroPedido3";
            comando.Parameters.AddWithValue("@idRegistroPedido", idRegistroPedido);
            comando.Parameters.AddWithValue("@idPedido", idPedido);
            comando.Parameters.AddWithValue("@codigoProducto", codigoProducto);
            comando.Parameters.AddWithValue("@MontoTotal", MontoTotal);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}