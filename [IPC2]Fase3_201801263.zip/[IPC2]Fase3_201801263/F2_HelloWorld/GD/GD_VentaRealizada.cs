﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_VentaRealizada
    {
        public SqlConnection conexion;
        public string error;

        public GD_VentaRealizada() {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(VentaRealizada Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "CalculoDatosVentaRealizada2";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@ImporteTotalVenta ", Dato.ImporteTotalVenta);
            comando.Parameters.AddWithValue("@Impuesto", Dato.Impuesto1);
            comando.Parameters.AddWithValue("@Fecha", Dato.Fecha);
            comando.Parameters.AddWithValue("@DatoImpuesto", Dato.ImpuestosDato1);
            comando.Parameters.AddWithValue("@idFacturacion", Dato.IdFacturacion);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear(); 
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public VentaRealizada consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from VentaRealizada where idVentaRealizada=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                VentaRealizada Dato = new VentaRealizada();
                Dato.IdVentaRealizada = registro.GetByte(0);
                Dato.ImporteTotalVenta = registro.GetInt32(1);
                Dato.Impuesto1 = registro.GetInt32(2);
                Dato.Fecha = registro.GetDateTime(3);
                Dato.ImpuestosDato1 = registro.GetInt32(4);
                Dato.IdFacturacion = registro.GetByte(5);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from VentaRealizada where idVentaRealizada=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<VentaRealizada> Listar()
        {
            List<VentaRealizada> Lista = new List<VentaRealizada>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select V.idVentaRealizada,V.ImpuestoDato,V.importeTotalVenta,V.Impuestos,V.Fecha,F.idFacturacion,F.idClienteE,F.idVendedor from VentaRealizada as V, Facturacion as F where V.idFacturacion=F.idFacturacion";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                VentaRealizada Objeto = new VentaRealizada();
                Objeto.IdVentaRealizada = registro.GetByte(0);
                Objeto.ImpuestosDato1 = registro.GetInt32(1);
                Objeto.ImporteTotalVenta = registro.GetInt32(2);
                Objeto.Impuesto1 = registro.GetInt32(3);
                Objeto.Fecha = registro.GetDateTime(4);
                Objeto.IdFacturacion = registro.GetByte(5);
                Objeto.IdCliente = registro.GetByte(6);
                Objeto.IdVendedor = registro.GetByte(7);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idVentaRealizada, int ImporteTotalVenta, int Impuesto, DateTime Fecha, int ImpuestoDato, byte idFacturacion)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "EditarVentaRealizada3";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@idVentaRealizada", idVentaRealizada);
            comando.Parameters.AddWithValue("@Fecha", Fecha);
            comando.Parameters.AddWithValue("@ImporteTotalVenta", ImporteTotalVenta);
            comando.Parameters.AddWithValue("@Impuesto", Impuesto);
            comando.Parameters.AddWithValue("@DatoImpuesto", ImpuestoDato);
            comando.Parameters.AddWithValue("@IdFacturacion", idFacturacion);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }

        
    }
}