﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    
    public class GD_ProductoEmpresa
    {
        public SqlConnection conexion;
        public string error;

        public GD_ProductoEmpresa() {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(ProductoEmpresa Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "AgregarProducto";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@codigoBarra", Dato.CodigoBarra);
            comando.Parameters.AddWithValue("@Nombre", Dato.Nombre1);
            comando.Parameters.AddWithValue("@Descripcion", Dato.Descripcion1);
            comando.Parameters.AddWithValue("@idPresentacionProducto", Dato.IdPresentacionproducto);
            comando.Parameters.AddWithValue("@idClasificacionProducto", Dato.IdclasificacionProducto);
            comando.Parameters.AddWithValue("@idEstadoProducto", Dato.IdeEstadoProducto);
            comando.Parameters.AddWithValue("@Precio", Dato.Precio1);
            comando.Parameters.AddWithValue("@idTipoGestion", Dato.IdTipoGestion);
            comando.Parameters.AddWithValue("@TipoGestion", Dato.TipoGestion1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public ProductoEmpresa consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from ProductoEmpresa where codigoProducto=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                ProductoEmpresa Dato = new ProductoEmpresa();
                Dato.CodigoProducto = registro.GetByte(0);
                Dato.CodigoBarra = registro.GetString(1);
                Dato.Nombre1 = registro.GetString(2);
                Dato.Descripcion1= registro.GetString(3);
                Dato.IdPresentacionproducto = registro.GetByte(4);
                Dato.IdclasificacionProducto = registro.GetByte(5);
                Dato.IdeEstadoProducto = registro.GetByte(6);
                Dato.Precio1 = registro.GetInt32(7);
                Dato.IdTipoGestion = registro.GetByte(8);
                Dato.TipoGestion1= registro.GetByte(9);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }            
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from ProductoEmpresa where codigoProducto=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();

        }

        //Método para mostrar 
        public List<ProductoEmpresa> Listar()
        {
            List<ProductoEmpresa> Lista = new List<ProductoEmpresa>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from ProductoEmpresa";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                ProductoEmpresa Objeto = new ProductoEmpresa();
                Objeto.CodigoProducto = registro.GetByte(0);
                Objeto.CodigoBarra = registro.GetString(1);
                Objeto.Nombre1 = registro.GetString(2);
                Objeto.Descripcion1 = registro.GetString(3);
                Objeto.IdPresentacionproducto= registro.GetByte(4);
                Objeto.IdclasificacionProducto = registro.GetByte(5);
                Objeto.IdeEstadoProducto = registro.GetByte(6);
                Objeto.Precio1 = registro.GetInt32(7);
                Objeto.IdTipoGestion = registro.GetByte(8);
                Objeto.TipoGestion1= registro.GetByte(9);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int codigoProducto, string codigoBarra, string Nombre, string Descripcion,
            byte idPresentacionP, byte idclasificacionP, byte ideEstadoProducto, int Precio, byte idTipoGestion, byte TipoGestion)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update ProductoEmpresa set codigoBarra=@codigoBarra,Nombre=@Nombre,Descripcion=@Descripcion,idPresentacionProducto=@idPresentacionP, idClasificacionProducto= @idClasificacionP, idEstadoProducto=@idEstadoP, Precio=@Precio, idTipoGestion=@idTipoGestion, TipoGestion=@TipoGestion where codigoProducto=@codigoProducto";
            comando.Parameters.AddWithValue("@codigoProducto", codigoProducto);
            comando.Parameters.AddWithValue("@codigoBarra",codigoBarra);
            comando.Parameters.AddWithValue("@Nombre", Nombre);
            comando.Parameters.AddWithValue("@Descripcion", Descripcion);
            comando.Parameters.AddWithValue("@idPresentacionP", idPresentacionP);
            comando.Parameters.AddWithValue("@idClasificacionP", idclasificacionP);
            comando.Parameters.AddWithValue("@idEstadoP", ideEstadoProducto);
            comando.Parameters.AddWithValue("@Precio", Precio);
            comando.Parameters.AddWithValue("@idTipoGestion", idTipoGestion);
            comando.Parameters.AddWithValue("@TipoGestion", TipoGestion);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}