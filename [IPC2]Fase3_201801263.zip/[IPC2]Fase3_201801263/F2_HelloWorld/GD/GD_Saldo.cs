﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Saldo
    {
        public SqlConnection conexion;
        public string error;

        public GD_Saldo()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Saldo Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Saldo values (@Saldo, @Costo);";
            comando.Parameters.AddWithValue("@Saldo", Dato.SaldoN1);
            comando.Parameters.AddWithValue("@Costo", Dato.Costo1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Saldo consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Saldo where idSaldo=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Saldo Dato = new Saldo();
                Dato.IdSaldo = registro.GetByte(0);
                Dato.SaldoN1 = registro.GetString(1);
                Dato.Costo1 = registro.GetInt32(2);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Saldo where idSaldo=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Saldo> Listar()
        {
            List<Saldo> Lista = new List<Saldo>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Saldo";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Saldo Objeto = new Saldo();
                Objeto.IdSaldo = registro.GetByte(0);
                Objeto.SaldoN1 = registro.GetString(1);
                Objeto.Costo1 = registro.GetInt32(2);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idSaldo, string Saldo, int Costo)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Saldo set Saldo=@Saldo where idSaldo=@idSaldo";
            comando.Parameters.AddWithValue("@idSaldo", idSaldo);
            comando.Parameters.AddWithValue("@Saldo", Saldo);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }

    }
}
    