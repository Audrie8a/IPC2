﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Contacto
    {
        public SqlConnection conexion;
        public string error;

        public GD_Contacto()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Contacto Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Contacto values (@DPI, @Nombre, @Celular, @telefono, @ext, @email, @direccionO,  @idCliente, @idTipoC);";
            comando.Parameters.AddWithValue("@DPI", Dato.DPI1);
            comando.Parameters.AddWithValue("@Nombre", Dato.Nombre1);
            comando.Parameters.AddWithValue("@Celular", Dato.Celular1);
            comando.Parameters.AddWithValue("@telefono", Dato.Telefono1);
            comando.Parameters.AddWithValue("@ext", Dato.Extension1);
            comando.Parameters.AddWithValue("@email", Dato.Email1);
            comando.Parameters.AddWithValue("@direccionO", Dato.DireccionOff1);
            comando.Parameters.AddWithValue("@idCliente", Dato.IdCliente);
            comando.Parameters.AddWithValue("@idTipoC", Dato.IdTipoContacto);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Contacto consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Contacto where idContacto=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Contacto Dato = new Contacto();
                Dato.IdContacto = registro.GetByte(0);
                Dato.DPI1 = registro.GetInt32(1);
                Dato.Nombre1 = registro.GetString(2);
                Dato.Celular1 = registro.GetString(3);
                Dato.Telefono1 = registro.GetString(4);
                Dato.Extension1 = registro.GetString(5);
                Dato.Email1 = registro.GetString(6);
                Dato.DireccionOff1 = registro.GetString(7);
                Dato.IdCliente = registro.GetByte(8);
                Dato.IdTipoContacto = registro.GetByte(9);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Contacto where idContacto=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Contacto> Listar()
        {
            List<Contacto> Lista = new List<Contacto>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Contacto";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Contacto Dato = new Contacto();
                Dato.IdContacto = registro.GetByte(0);
                Dato.DPI1 = registro.GetInt32(1);
                Dato.Nombre1 = registro.GetString(2);
                Dato.Celular1 = registro.GetString(3);
                Dato.Telefono1 = registro.GetString(4);
                Dato.Extension1 = registro.GetString(5);
                Dato.Email1 = registro.GetString(6);
                Dato.DireccionOff1 = registro.GetString(7);
                Dato.IdCliente = registro.GetByte(8);
                Dato.IdTipoContacto = registro.GetByte(9);
                Lista.Add(Dato);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte idContacto, int DPI, string nombre, string celular, string telefono, string extension, string email, string direccionO, byte idCliente, byte idTipoC )
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Contacto set DPI=@dpi , Nombre=@nombre, Celular=@celular , Telefono=@telefono , Extencion=@ext , Email=@email , DireccionOficina=@DO , idCliente=@idCliente , idTipoContacto=@idTC  where idCliente=@idCliente";
            comando.Parameters.AddWithValue("@idContacto", idContacto);
            comando.Parameters.AddWithValue("@dpi", DPI);
            comando.Parameters.AddWithValue("@nombre", nombre);
            comando.Parameters.AddWithValue("@celular", celular);
            comando.Parameters.AddWithValue("@telefono", telefono);
            comando.Parameters.AddWithValue("@ext", extension);
            comando.Parameters.AddWithValue("@email", email);
            comando.Parameters.AddWithValue("@DO", direccionO);
            comando.Parameters.AddWithValue("@idCliente", idCliente);
            comando.Parameters.AddWithValue("@idTC", idTipoC);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}