﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Transaccion
    {
        public SqlConnection conexion;
        public string error;

        public GD_Transaccion()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregarEntrada(Transaccion Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "AgregarTransaccion";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@Fecha", Dato.Fecha1);
            comando.Parameters.AddWithValue("@Hora", Dato.Hora1);
            comando.Parameters.AddWithValue("@idTipoTrans", Dato.IdTipoTransaccion);
            comando.Parameters.AddWithValue("@codigoProducto", Dato.CodigoProducto);
            comando.Parameters.AddWithValue("@idProveedor", Dato.Proveedor1);
            comando.Parameters.AddWithValue("@Cantidad", Dato.Cantidad1);
            comando.Parameters.AddWithValue("@Costo", Dato.CostoProducto1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        public bool agregarSalida(Transaccion Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "AgregarTransaccionSalida";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@Fecha", Dato.Fecha1);
            comando.Parameters.AddWithValue("@Hora", Dato.Hora1);
            comando.Parameters.AddWithValue("@idTipoTrans", Dato.IdTipoTransaccion);
            comando.Parameters.AddWithValue("@codigoProducto", Dato.CodigoProducto);
            comando.Parameters.AddWithValue("@idCliente", Dato.Cliente1);
            comando.Parameters.AddWithValue("@Cantidad", Dato.Cantidad1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Transaccion consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Transaccion where idTransaccion=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {

                Transaccion Dato = new Transaccion();
                Dato.IdTipoTransaccion= registro.GetByte(0);
                Dato.Fecha1 = registro.GetDateTime(1);
                Dato.Hora1 = registro.GetString(2);
                Dato.IdTipoTransaccion= registro.GetByte(3);
                Dato.CodigoProducto = registro.GetByte(4);
                Dato.Producto1 = registro.GetString(5);
                Dato.Cliente1 = registro.GetByte(6);
                Dato.Proveedor1 = registro.GetByte(7);
                Dato.Cantidad1 = registro.GetInt32(8);
                Dato.CostoProducto1 = registro.GetInt32(9);
                Dato.CostoTotal1 = registro.GetInt32(10);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        

        //Método para mostrar 
        public List<Transaccion> Listar()
        {
            List<Transaccion> Lista = new List<Transaccion>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Transaccion";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Transaccion Dato = new Transaccion();
                Dato.IdTipoTransaccion = registro.GetByte(0);
                Dato.Fecha1 = registro.GetDateTime(1);
                Dato.Hora1 = registro.GetString(2);
                Dato.IdTipoTransaccion = registro.GetByte(3);
                Dato.CodigoProducto = registro.GetByte(4);
                Dato.Producto1 = registro.GetString(5);
                Dato.Cliente1 = registro.GetByte(6);
                Dato.Proveedor1 = registro.GetByte(7);
                Dato.Cantidad1 = registro.GetInt32(8);
                Dato.CostoProducto1 = registro.GetInt32(9);
                Dato.CostoTotal1 = registro.GetInt32(10);
                Lista.Add(Dato);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}