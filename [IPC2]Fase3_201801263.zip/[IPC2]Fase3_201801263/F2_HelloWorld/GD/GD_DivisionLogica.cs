﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_DivisionLogica
    {
        public SqlConnection conexion;
        public string error;

        public GD_DivisionLogica()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

//---------------------------------PASILLO--------------------------------------------------------------------------------------------------

        //Método para Agregar a la base de datos
        public bool agregarPasillo(Pasillo Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Pasillo values (@numPasillo, @Largo, @Ancho, @idBodega);";
            comando.Parameters.AddWithValue("@numPasillo", Dato.NumPasillo);
            comando.Parameters.AddWithValue("@Largo", Dato.LargoPasillo);
            comando.Parameters.AddWithValue("@Ancho", Dato.AnchoPasillo1);
            comando.Parameters.AddWithValue("@idBodega", Dato.IdBodega);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Pasillo consultarPasillo(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Pasillo where numPasillo=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Pasillo Dato = new Pasillo();
                Dato.NumPasillo = registro.GetInt32(0);
                Dato.LargoPasillo = registro.GetInt32(1);
                Dato.AnchoPasillo1 = registro.GetInt32(2);
                Dato.IdBodega = registro.GetByte(3);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminarPasillo(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Pasillo where numPasillo=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Pasillo> ListarPasillo()
        {
            List<Pasillo> Lista = new List<Pasillo>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Pasillo";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Pasillo Objeto = new Pasillo();
                Objeto.NumPasillo = registro.GetInt32(0);
                Objeto.LargoPasillo = registro.GetInt32(1);
                Objeto.AnchoPasillo1 = registro.GetInt32(2);
                Objeto.IdBodega = registro.GetByte(3);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editarPasillo(int numPasillo, int Largo, int Ancho, byte Bodega)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Pasillo set numPasillo=@numPasillo, Largo=@Largo, Ancho=@Ancho, idBodega=@idBodega where numPasillo=@numPasillo";
            comando.Parameters.AddWithValue("@numPasillo", numPasillo);
            comando.Parameters.AddWithValue("@Largo", Largo);
            comando.Parameters.AddWithValue("@Ancho", Ancho);
            comando.Parameters.AddWithValue("@idBodega", Bodega);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }


        //-------------------------------------ESTANTE-----------------------------------------------------------------------------------------------
        //Método para Agregar a la base de datos
        public bool agregarEstante(Estante Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Estante values (@identificacion, @Largo, @Ancho, @Altura, @idPasillo);";
            comando.Parameters.AddWithValue("@identificacion", Dato.Identificacion);
            comando.Parameters.AddWithValue("@Largo", Dato.Largo1);
            comando.Parameters.AddWithValue("@Ancho", Dato.Ancho1);
            comando.Parameters.AddWithValue("@Altura", Dato.Altura1);
            comando.Parameters.AddWithValue("@idPasillo", Dato.IdPasillo);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Estante consultarEstante(string ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Estante where identificacion=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Estante Dato = new Estante();
                Dato.Identificacion = registro.GetString(0);
                Dato.Largo1 = registro.GetInt32(1);
                Dato.Ancho1 = registro.GetInt32(2);
                Dato.Altura1 = registro.GetInt32(3);
                Dato.IdPasillo = registro.GetInt32(4);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminarEstante(string ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Estante where identificacion=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Estante> ListarEstante()
        {
            List<Estante> Lista = new List<Estante>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Estante";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Estante Objeto = new Estante();
                Objeto.Identificacion = registro.GetString(0);
                Objeto.Largo1 = registro.GetInt32(1);
                Objeto.Ancho1 = registro.GetInt32(2);
                Objeto.Altura1 = registro.GetInt32(3);
                Objeto.IdPasillo = registro.GetInt32(4);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editarEstante(string identificacion, int Largo, int Ancho, int Altura, int idPasillo)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Estante set identificacion=@identificacion, Largo= @Largo, Ancho= @Ancho, Altura=@Altura, idPasillo =@idPasillo where identificacion=@identificacion";
            comando.Parameters.AddWithValue("@identificacion", identificacion);
            comando.Parameters.AddWithValue("@Largo", Largo);
            comando.Parameters.AddWithValue("@Ancho", Ancho);
            comando.Parameters.AddWithValue("@Altura", Altura);
            comando.Parameters.AddWithValue("@idPasillo", idPasillo);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }


        //---------------------------------------------NIVEL-----------------------------------------------------------------------------------------------

        //Método para Agregar a la base de datos
        public bool agregarNivel(Nivel Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Nivel values(@numNivel, @Altura, @Largo, @Ancho, @idEstante);";
            comando.Parameters.AddWithValue("@numNivel", Dato.NumNivel);
            comando.Parameters.AddWithValue("@Altura", Dato.Altura1);
            comando.Parameters.AddWithValue("@Largo", Dato.Largo1);
            comando.Parameters.AddWithValue("@Ancho", Dato.Ancho1);
            comando.Parameters.AddWithValue("@idEstante", Dato.IdEstante);

            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Nivel consultarNivel(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Nivel where numNivel=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Nivel Dato = new Nivel();
                Dato.NumNivel = registro.GetInt32(0);
                Dato.Altura1 = registro.GetInt32(1);
                Dato.Largo1 = registro.GetInt32(2);
                Dato.Ancho1 = registro.GetInt32(3);
                Dato.IdEstante = registro.GetString(4);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminarNivel(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Nivel where numNivel=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Nivel> ListarNivel()
        {
            List<Nivel> Lista = new List<Nivel>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Nivel";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Nivel Objeto = new Nivel();
                Objeto.NumNivel = registro.GetInt32(0);
                Objeto.Altura1 = registro.GetInt32(1);
                Objeto.Largo1 = registro.GetInt32(2);
                Objeto.Ancho1 = registro.GetInt32(3);
                Objeto.IdEstante = registro.GetString(4);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editarNivel(int numNivel,int Altura, int Largo, int Ancho, string idEstante)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "update Nivel set numNivel=@numNivel, Altura=@Altura, Largo=@Largo, Ancho=@Ancho, idEstante=@idEstante";
            comando.Parameters.AddWithValue("@numNivel", numNivel);
            comando.Parameters.AddWithValue("@Altura", Altura);
            comando.Parameters.AddWithValue("@Largo", Largo);
            comando.Parameters.AddWithValue("@Ancho", Ancho);
            comando.Parameters.AddWithValue("@idEstante", idEstante);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //-------------------------------------------------------------------------------------------------------------------------------------------------

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}