﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_ProveedorEmpresa
    {
        public SqlConnection conexion;
        public string error;
        public GD_ProveedorEmpresa()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(ProveedorEmpresa Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into ProveedorEmpresa values (@NIT,@Nombre, @Direccion, @Telefono, @idContactoEncargado,@LimiteCredito,@Correo,@idEstadoProveedor);";
            comando.Parameters.AddWithValue("@NIT", Dato.NIT1);
            comando.Parameters.AddWithValue("@Nombre", Dato.Nombre1);
            comando.Parameters.AddWithValue("@Direccion", Dato.Direccion1);
            comando.Parameters.AddWithValue("@Telefono", Dato.Telefono1);
            comando.Parameters.AddWithValue("@idContactoEncargado", Dato.ContactoEncargado1);
            comando.Parameters.AddWithValue("@Correo", Dato.Correo1);
            comando.Parameters.AddWithValue("@LimiteCredito", Dato.LimiteCredito1);
            comando.Parameters.AddWithValue("@idEstadoProveedor", Dato.IdestadoProveedor);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public ProveedorEmpresa consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from ProveedorEmpresa where idProveedor=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                ProveedorEmpresa Dato = new ProveedorEmpresa();
                Dato.IdProveedor = registro.GetByte(0);
                Dato.NIT1 = registro.GetString(1);
                Dato.Nombre1 = registro.GetString(2);
                Dato.Direccion1 = registro.GetString(3);
                Dato.Telefono1 = registro.GetString(4);
                Dato.ContactoEncargado1 = registro.GetString(5);
                Dato.LimiteCredito1 = registro.GetInt32(6);
                Dato.Correo1 = registro.GetString(7);
                Dato.IdestadoProveedor = registro.GetByte(8);                
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
            //comando.Parameters.Clear();
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from ProveedorEmpresa where idProveedor=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();

        }

        //Método para mostrar 
        public List<ProveedorEmpresa> Listar()
        {
            List<ProveedorEmpresa> Lista = new List<ProveedorEmpresa>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from ProveedorEmpresa";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                ProveedorEmpresa Objeto = new ProveedorEmpresa();
                Objeto.IdProveedor= registro.GetByte(0);
                Objeto.NIT1 = registro.GetString(1);
                Objeto.Nombre1 = registro.GetString(2);
                Objeto.Direccion1= registro.GetString(3);
                Objeto.Telefono1= registro.GetString(4);
                Objeto.ContactoEncargado1 = registro.GetString(5);
                Objeto.LimiteCredito1= registro.GetInt32(6);
                Objeto.Correo1 = registro.GetString(7);
                Objeto.IdestadoProveedor = registro.GetByte(8);                
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idProveedor, string NIT, string Nombre, string Direccion,
            string Telefono, string ContactoEncargado, int LimiteCredito, string Correo, byte idEstadoProveedor)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update ProveedorEmpresa set NIT=@Nit, Nombre=@nombre,Direccion=@Direccion, Telefono=@Telefono, ContactoEncargado=@idContactoEncargado,LimiteCredito=@LimiteCredito, Correo=@Correo ,idEstadoProveedor=@idEstadoProveedor where idProveedor=@idProveedor";
            comando.Parameters.AddWithValue("@idProveedor", idProveedor);
            comando.Parameters.AddWithValue("@Nit", NIT);
            comando.Parameters.AddWithValue("@Nombre", Nombre);
            comando.Parameters.AddWithValue("@Direccion", Direccion);
            comando.Parameters.AddWithValue("@Telefono", Telefono);
            comando.Parameters.AddWithValue("@idContactoEncargado", ContactoEncargado);
            comando.Parameters.AddWithValue("@LimiteCredito", LimiteCredito);
            comando.Parameters.AddWithValue("@Correo", Correo);            
            comando.Parameters.AddWithValue("@idEstadoProveedor", idEstadoProveedor);            
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}