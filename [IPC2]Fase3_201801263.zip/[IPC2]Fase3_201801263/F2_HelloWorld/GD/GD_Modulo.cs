﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Modulo
    {
        public SqlConnection conexion;
        public string error;

        public GD_Modulo()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Modulo Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Modulo values (@Nombre, @Abreviatura, @Descrip, @idTipoM, @idEstadoM);";
            comando.Parameters.AddWithValue("@Nombre", Dato.Nombre1);
            comando.Parameters.AddWithValue("@Abreviatura", Dato.Abreviatura1);
            comando.Parameters.AddWithValue("@Descrip", Dato.Descripcion1);
            comando.Parameters.AddWithValue("@idTipoM", Dato.IdTipoModulo);
            comando.Parameters.AddWithValue("@idEstadoM", Dato.IdEstadoModulo);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Modulo consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Modulo where codigoModulo=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Modulo Dato = new Modulo();
                Dato.CodigoModulo = registro.GetByte(0);
                Dato.Nombre1 = registro.GetString(1);
                Dato.Abreviatura1 = registro.GetString(2);
                Dato.Descripcion1 = registro.GetString(3);
                Dato.IdTipoModulo = registro.GetByte(4);
                Dato.IdEstadoModulo = registro.GetByte(5);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Modulo where codigoModulo=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Modulo> Listar()
        {
            List<Modulo> Lista = new List<Modulo>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Modulo";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Modulo Objeto = new Modulo();
                Objeto.CodigoModulo = registro.GetByte(0);
                Objeto.Nombre1 = registro.GetString(1);
                Objeto.Abreviatura1 = registro.GetString(2);
                Objeto.Descripcion1 = registro.GetString(3);
                Objeto.IdTipoModulo = registro.GetByte(4);
                Objeto.IdEstadoModulo = registro.GetByte(5);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte codMod, string Name, string Abre, string descrip, byte idTipMo, byte idEstaMo)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Modulo set Nombre=@Name, Abreviatura=@Abrev, Descripcion=@Descrip, idTipoModulo=@idTipMo, idEstadoModulo=@idEM where codigoModulo=@codigoMod";
            comando.Parameters.AddWithValue("@codigoMod", codMod);
            comando.Parameters.AddWithValue("@Name", Name);
            comando.Parameters.AddWithValue("@Abrev", Abre);
            comando.Parameters.AddWithValue("@Descrip", descrip);
            comando.Parameters.AddWithValue("@idTipMo", idTipMo);
            comando.Parameters.AddWithValue("@idEM", idEstaMo);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}