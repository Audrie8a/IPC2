﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_TipoEmpresa
    {
        public SqlConnection conexion;
        public string error;

        public GD_TipoEmpresa()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(TipoEmpresa Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into TipoEmpresa values (@TipoEmpresa);";
            comando.Parameters.AddWithValue("@TipoEmpresa", Dato.TipoE1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public TipoEmpresa consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from TipoEmpresa where id_Tipoempresa =@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                TipoEmpresa Dato = new TipoEmpresa();
                Dato.IdTipoEmpresa = registro.GetByte(0);
                Dato.TipoE1= registro.GetString(1);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from TipoEmpresa where id_Tipoempresa =@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<TipoEmpresa> Listar()
        {
            List<TipoEmpresa> Lista = new List<TipoEmpresa>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from TipoEmpresa";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                TipoEmpresa Objeto = new TipoEmpresa();
                Objeto.IdTipoEmpresa = registro.GetByte(0);
                Objeto.TipoE1= registro.GetString(1);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idTipoEmpresa, string TipoEmpresa)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update TipoEmpresa set TipoEmpresa=@TipoEmpresa where id_Tipoempresa =@idTipoEmpresa";
            comando.Parameters.AddWithValue("@idTipoEmpresa", idTipoEmpresa);
            comando.Parameters.AddWithValue("@TipoEmpresa", TipoEmpresa);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}