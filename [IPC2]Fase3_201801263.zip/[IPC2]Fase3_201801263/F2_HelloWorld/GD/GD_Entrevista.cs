﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Entrevista
    {
        public SqlConnection conexion;
        public string error;

        public GD_Entrevista()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Entrevista Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Entrevista values (@Fecha, @idSolicitante, @idEstadoEntrevista);";
            comando.Parameters.AddWithValue("@Fecha", Dato.Fecha1);
            comando.Parameters.AddWithValue("@idSolicitante", Dato.IdSolicitante);
            comando.Parameters.AddWithValue("@idEstadoEntrevista", Dato.IdEstadoEntrevista);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Entrevista consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Entrevista where idEntrevista=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Entrevista Dato = new Entrevista();
                Dato.IdEntrevista = registro.GetByte(0);
                Dato.Fecha1 = registro.GetDateTime(1); ;
                Dato.IdSolicitante = registro.GetByte(2);
                Dato.IdEstadoEntrevista = registro.GetByte(3);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Entrevista where idEntrevista=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Entrevista> Listar()
        {
            List<Entrevista> Lista = new List<Entrevista>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Entrevista";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Entrevista Objeto = new Entrevista();
                Objeto.IdEntrevista = registro.GetByte(0);
                Objeto.Fecha1 = registro.GetDateTime(1);
                Objeto.IdSolicitante = registro.GetByte(2);
                Objeto.IdEstadoEntrevista = registro.GetByte(3);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte idEntrevista, DateTime fecha, byte idSolicitante, byte idEstadoEntrevista)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Entrevista set Fecha=@Fecha, idSolicitate=@idSolicitante, idEstadoEntrevista=@idEstadoEntrevista where idEntrevista=@idEntrevista";
            comando.Parameters.AddWithValue("@idEntrevista", idEntrevista);
            comando.Parameters.AddWithValue("@Fecha", fecha);
            comando.Parameters.AddWithValue("@idSolicitante", idSolicitante);
            comando.Parameters.AddWithValue("@idEstadoEntrevista", idEstadoEntrevista);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}