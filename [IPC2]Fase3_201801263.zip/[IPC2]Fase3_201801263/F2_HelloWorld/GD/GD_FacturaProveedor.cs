﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_FacturaProveedor
    {
        public SqlConnection conexion;
        public string error;

        public GD_FacturaProveedor()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(FacturaProveedor Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "AgregarFacturaProveedor";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@fechaEmision", Dato.FechaEmision);
            comando.Parameters.AddWithValue("@idProveedor", Dato.IdProveedorEmpresa);
            comando.Parameters.AddWithValue("@serie", Dato.Serie1);
            comando.Parameters.AddWithValue("@valor", Dato.Valor1);
            comando.Parameters.AddWithValue("@impuesto", Dato.Impuestos);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public FacturaProveedor consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from FacturaProveedor where numFacturaProveedor=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                FacturaProveedor Dato = new FacturaProveedor();
                Dato.NumfacturaProveedor = registro.GetByte(0);
                Dato.FechaEmision = registro.GetDateTime(1);
                Dato.IdProveedorEmpresa = registro.GetByte(2);
                Dato.Serie1 = registro.GetString(3);
                Dato.Valor1 = registro.GetInt32(4);
                Dato.Impuestos = registro.GetInt32(5);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from FacturaProveedor where numFacturaProveedor=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<FacturaProveedor> Listar()
        {
            List<FacturaProveedor> Lista = new List<FacturaProveedor>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from FacturaProveedor";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                FacturaProveedor Objeto = new FacturaProveedor();
                Objeto.NumfacturaProveedor = registro.GetByte(0);
                Objeto.FechaEmision = registro.GetDateTime(1);
                Objeto.IdProveedorEmpresa = registro.GetByte(2);
                Objeto.Serie1 = registro.GetString(3);
                Objeto.Valor1 = registro.GetInt32(4);
                Objeto.Impuestos = registro.GetInt32(5);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int numFactura,DateTime fechaEmision, byte idProveedor, string serie, int valor, int impuesto)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "EditarFacturaProveedor";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@numFactura", numFactura);
            comando.Parameters.AddWithValue("@fechaEmision", fechaEmision);
            comando.Parameters.AddWithValue("@idProveedor", idProveedor);
            comando.Parameters.AddWithValue("@serie", serie);
            comando.Parameters.AddWithValue("@valor", valor);
            comando.Parameters.AddWithValue("@impuesto", impuesto);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}