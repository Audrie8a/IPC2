﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Lote
    {
        public SqlConnection conexion;
        public string error;

        public GD_Lote() {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Lote Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Lote values (@Lote,@Precio, @idTipoLogica);";
            comando.Parameters.AddWithValue("@Lote", Dato.LoteN1);
            comando.Parameters.AddWithValue("@idTipoLogica", Dato.IdTipoLogica);
            comando.Parameters.AddWithValue("@Precio", Dato.Precio1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Lote consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Lote where idLote=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Lote Dato = new Lote();
                Dato.IdLote= registro.GetByte(0);
                Dato.LoteN1 = registro.GetString(1);
                Dato.Precio1 = registro.GetInt32(2);
                Dato.IdTipoLogica = registro.GetByte(3);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Lote where idLote=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Lote> Listar()
        {
            List<Lote> Lista = new List<Lote>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Lote";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Lote Objeto = new Lote();
                Objeto.IdLote= registro.GetByte(0);
                Objeto.LoteN1 = registro.GetString(1);
                Objeto.Precio1 = registro.GetInt32(2);
                Objeto.IdTipoLogica = registro.GetByte(3);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idLote, string Lote, byte idTipoLogica)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Lote set Lote=@Lote, idTipoLogica=@idTipoLogica where idLote=@idLote";
            comando.Parameters.AddWithValue("@idLote", idLote);
            comando.Parameters.AddWithValue("@Lote", Lote);
            comando.Parameters.AddWithValue("@idTipoLogica", idTipoLogica);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }

    }
}