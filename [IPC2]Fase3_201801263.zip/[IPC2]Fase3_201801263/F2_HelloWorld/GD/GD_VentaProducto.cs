﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_VentaProducto
    {
        public SqlConnection conexion;
        public string error;

        public GD_VentaProducto() {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(VentaProducto Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into VentaProducto values (@idFacturacion, @codigoProducto, @cantidad, @pago);";
            comando.Parameters.AddWithValue("@idFacturacion", Dato.IdFacturacion);
            comando.Parameters.AddWithValue("@codigoProducto", Dato.CodigoProducto);
            comando.Parameters.AddWithValue("@cantidad", Dato.Cantidad);
            comando.Parameters.AddWithValue("@pago", Dato.Pago1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public VentaProducto consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from VentaProducto where idVentaProducto=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                VentaProducto Dato = new VentaProducto();
                Dato.IdVentaProducto= registro.GetByte(0);
                Dato.IdFacturacion = registro.GetByte(1);
                Dato.CodigoProducto = registro.GetByte(2);
                Dato.Cantidad = registro.GetInt32(3);
                Dato.Pago1 = registro.GetInt32(4);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from VentaProducto where idVentaProducto=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<VentaProducto> Listar()
        {
            List<VentaProducto> Lista = new List<VentaProducto>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from VentaProducto ";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                VentaProducto Objeto = new VentaProducto();
                Objeto.IdVentaProducto = registro.GetByte(0);
                Objeto.IdFacturacion= registro.GetByte(1);
                Objeto.CodigoProducto= registro.GetByte(2);
                Objeto.Cantidad = registro.GetInt32(3);
                Objeto.Pago1 = registro.GetInt32(4);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idVentaProducto, byte idFacturacion, byte codigoProducto, int cantidad, int Pago)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update VentaProducto set idFacturacion=@idFacturacion, codigoProducto=@codigoProducto, cantidad=@cantidad, Pago=@pago where idVentaProducto=@idVentaProducto";
            comando.Parameters.AddWithValue("@idVentaProducto", idVentaProducto);
            comando.Parameters.AddWithValue("@idFacturacion", idFacturacion);
            comando.Parameters.AddWithValue("@codigoProducto", codigoProducto);
            comando.Parameters.AddWithValue("@cantidad", cantidad);
            comando.Parameters.AddWithValue("@Pago", Pago);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}