﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_CategoriaCliente
    {
        public SqlConnection conexion;
        public string error;

        public GD_CategoriaCliente()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar nuevas Categorías a la base de datos
        public bool agregarCategoriaCliente(CategoriaCliente CC)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into CategoriaCliente values(@Abreviatura, @Descripcion)";
            comando.Parameters.AddWithValue("@Abreviatura", CC.Abreviatura1);
            comando.Parameters.AddWithValue("@Descripcion", CC.Descripcion1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Métodos para Eliminar un Cliente de la Empresa
        public void eliminarCategoriaCliente(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from CategoriaCliente where codigoCategoria=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();

        }

        //Método para Editar
        public void editarCategoriaCliente(byte codigoCategoria, string Abreviatura, string Descripcion)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "update CategoriaCliente set Abreviatura=@Abreiviatura, Descripcion=@Descripcion where codigoCategoria=@Id";
            comando.Parameters.AddWithValue("@Id", codigoCategoria);
            comando.Parameters.AddWithValue("@Abreiviatura", Abreviatura);
            comando.Parameters.AddWithValue("@Descripcion", Descripcion);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método Listar Categorias
        public List<CategoriaCliente> lstCategoriaClientes()
        {
            List<CategoriaCliente> LClientesEmpresa = new List<CategoriaCliente>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from CategoriaCliente";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                CategoriaCliente Cliente = new CategoriaCliente();
                Cliente.CodigoCategoria = registro.GetByte(0);
                Cliente.Abreviatura1 = registro.GetString(1);
                Cliente.Descripcion1 = registro.GetString(2);                
                LClientesEmpresa.Add(Cliente);
                comando.Parameters.Clear();
            }
            registro.Close();
            return LClientesEmpresa;
        }

        //Método para hacer consultas para los DDL
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }

        //Método para consultar Categoria Cliente
        public CategoriaCliente consultarCategoriaCliente(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from CategoriaCliente where codigoCategoria=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                CategoriaCliente Cliente = new CategoriaCliente();
                Cliente.CodigoCategoria = registro.GetByte(0);
                Cliente.Abreviatura1 = registro.GetString(1);
                Cliente.Descripcion1 = registro.GetString(2);                
                registro.Close();
                return Cliente;

            }
            else
            {
                registro.Close();
                return null;
            }
            
        }
    }
}