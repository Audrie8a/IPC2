﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Pedido
    {
        public SqlConnection conexion;
        public string error;

        public GD_Pedido() {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Pedido Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Pedido values (@FechaPedido, @FechaRecibido, @Cantidad, @Precio,@idProveedor);";
            comando.Parameters.AddWithValue("@FechaPedido", Dato.FechaPedido1);
            comando.Parameters.AddWithValue("@FechaRecibido", Dato.FechaRecibido1);
            comando.Parameters.AddWithValue("@Cantidad", Dato.Cantidad);
            comando.Parameters.AddWithValue("@Precio", Dato.Precio);
            comando.Parameters.AddWithValue("@idProveedor", Dato.IdProveedor);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Pedido consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Pedido where idPedido=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Pedido Dato = new Pedido();
                Dato.IdPedido = registro.GetByte(0);
                Dato.FechaPedido1 = registro.GetDateTime(1);
                Dato.FechaRecibido1 = registro.GetDateTime(2);
                Dato.Cantidad = registro.GetInt32(3);
                Dato.Precio = registro.GetInt32(4);
                Dato.IdProveedor = registro.GetByte(5);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Pedido where idPedido=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Pedido> Listar()
        {
            List<Pedido> Lista = new List<Pedido>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Pedido";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Pedido Objeto = new Pedido();
                Objeto.IdPedido = registro.GetByte(0);
                Objeto.FechaPedido1 = registro.GetDateTime(1);
                Objeto.FechaRecibido1 = registro.GetDateTime(2);
                Objeto.Cantidad = registro.GetInt32(3);
                Objeto.Precio = registro.GetInt32(4);
                Objeto.IdProveedor = registro.GetByte(5);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idPedido, DateTime fechaPedido, DateTime fechaRecibido, int cantidad, int precio, byte idProveedor)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Pedido set FechaPedido=@FechaPedido, FechaRecibido=@FechaRecibido,cantidad=@cantidad, precio=@precio,idProveedor=@idProveedor where idPedido=@idPedido";
            comando.Parameters.AddWithValue("@idPedido", idPedido);
            comando.Parameters.AddWithValue("@FechaPedido", fechaPedido);
            comando.Parameters.AddWithValue("@FechaRecibido", fechaRecibido);
            comando.Parameters.AddWithValue("@cantidad", cantidad);
            comando.Parameters.AddWithValue("@precio", precio);
            comando.Parameters.AddWithValue("@idProveedor", idProveedor);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}