﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_AccesoUsuario
    {
        public SqlConnection conexion;
        public string error;

        public GD_AccesoUsuario()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(AccesoUsuario Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into AccesoUsuario values (@idPerimisoU, @idUsuario,@codigoMod);";
            comando.Parameters.AddWithValue("@idPerimisoU", Dato.IdPermisoUsuario);
            comando.Parameters.AddWithValue("@idUsuario", Dato.IdUsuario);
            comando.Parameters.AddWithValue("@codigoMod", Dato.CodigoModulo);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public AccesoUsuario consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from AccesoUsuario where idAccesoUsuario=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                AccesoUsuario Dato = new AccesoUsuario();
                Dato.IdAccesoUsuario = registro.GetByte(0);
                Dato.IdPermisoUsuario = registro.GetByte(1);
                Dato.IdUsuario = registro.GetByte(2);
                Dato.CodigoModulo = registro.GetByte(3);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from AccesoUsuario where idAccesoUsuario=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<AccesoUsuario> Listar()
        {
            List<AccesoUsuario> Lista = new List<AccesoUsuario>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from AccesoUsuario";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                AccesoUsuario Objeto = new AccesoUsuario();
                Objeto.IdAccesoUsuario = registro.GetByte(0);
                Objeto.IdPermisoUsuario = registro.GetByte(1);
                Objeto.IdUsuario = registro.GetByte(2);
                Objeto.CodigoModulo = registro.GetByte(3);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte idAccesoUsuario, byte idPermisoUsuario, byte idUsaurio, byte codigoModulo)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update AccesoUsuario set idPermisoUsuario=@idPermisoUsuario, idUsurio=@idUsuario, codigoModulo=@codigoMod where idAccesoUsuario=@idAccessoUsuario";
            comando.Parameters.AddWithValue("@idPermisoUsuario", idPermisoUsuario);
            comando.Parameters.AddWithValue("@idUsuario", idUsaurio);
            comando.Parameters.AddWithValue("@codigoMod", codigoModulo);
            comando.Parameters.AddWithValue("@idAccessoUsuario", idAccesoUsuario);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}