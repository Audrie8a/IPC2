﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Usuario
    {
        public SqlConnection conexion;
        public string error;

        public GD_Usuario()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Usuario Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Usuario values (@Password, @idContacto,@Nombre, @Correo,@Celular,@Puesto,@idTipoUsuario);";
            comando.Parameters.AddWithValue("@Password", Dato.Password);
            comando.Parameters.AddWithValue("@idContacto", Dato.IdContacto);
            comando.Parameters.AddWithValue("@Nombre", Dato.Nombre1);
            comando.Parameters.AddWithValue("@Correo", Dato.Correo1);
            comando.Parameters.AddWithValue("@Celular", Dato.Celular1);
            comando.Parameters.AddWithValue("@Puesto", Dato.Puesto1);
            comando.Parameters.AddWithValue("@idTipoUsuario", Dato.IdTipoUsuario);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Usuario consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Usuario where idUsuario=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Usuario Dato = new Usuario();
                Dato.IdUsuario = registro.GetByte(0);
                Dato.Password = registro.GetString(1);
                Dato.IdContacto = registro.GetByte(2);
                Dato.Nombre1 = registro.GetString(3);
                Dato.Correo1 = registro.GetString(4);
                Dato.Celular1 = registro.GetString(5);
                Dato.Puesto1 = registro.GetString(6);
                Dato.IdTipoUsuario = registro.GetByte(7);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Usuario where idUsuario=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Usuario> Listar()
        {
            List<Usuario> Lista = new List<Usuario>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Usuario";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Usuario Dato = new Usuario();
                Dato.IdUsuario = registro.GetByte(0);
                Dato.Password = registro.GetString(1);
                Dato.IdContacto = registro.GetByte(2);
                Dato.Nombre1 = registro.GetString(3);
                Dato.Correo1 = registro.GetString(4);
                Dato.Celular1 = registro.GetString(5);
                Dato.Puesto1 = registro.GetString(6);
                Dato.IdTipoUsuario = registro.GetByte(7);
                Lista.Add(Dato);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte idUsuario,string Password, byte IdContacto, string Nombre1, string Correo1, string Celular1, string Puesto1, byte IdTipoUsuario)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Usuario set Password=@Password ,idContacto=@idContacto ,Nombre=@Nombre ,Correo=@Correo ,Celular=@Celular , Puesto=@Puesto ,idTipoUsuario=@idTipoUsuario where idUsuario=@idUsuario";
            comando.Parameters.AddWithValue("@idUsuario", idUsuario);
            comando.Parameters.AddWithValue("@Password", Password);
            comando.Parameters.AddWithValue("@idContacto", IdContacto);
            comando.Parameters.AddWithValue("@Nombre", Nombre1);
            comando.Parameters.AddWithValue("@Correo", Correo1);
            comando.Parameters.AddWithValue("@Celular", Celular1);
            comando.Parameters.AddWithValue("@Puesto", Puesto1);
            comando.Parameters.AddWithValue("@idTipoUsuario", IdTipoUsuario);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}