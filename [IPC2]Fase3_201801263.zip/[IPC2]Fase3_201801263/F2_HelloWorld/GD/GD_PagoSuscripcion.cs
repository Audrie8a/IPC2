﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_PagoSuscripcion
    {
        public SqlConnection conexion;
        public string error;

        public GD_PagoSuscripcion()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(PagoSuscripcion Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into PagoSuscripcion values (@idTipoSus, @PrecioMod, @idRangoU, @codigoMod, @idListaP);";
            comando.Parameters.AddWithValue("@idTipoSus", Dato.IdTipoSuscripcion);
            comando.Parameters.AddWithValue("@PrecioMod", Dato.PrecioModulo1);
            comando.Parameters.AddWithValue("@idRangoU", Dato.IdRangoUsuario);
            comando.Parameters.AddWithValue("@codigoMod", Dato.CodigoModulo);
            comando.Parameters.AddWithValue("@idListaP", Dato.IdListaPrecio);

            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public PagoSuscripcion consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from PagoSuscripcion where idPagoSuscripcion=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                PagoSuscripcion Dato = new PagoSuscripcion();
                Dato.IdPagoSuscripcion = registro.GetByte(0);
                Dato.IdTipoSuscripcion = registro.GetByte(1);
                Dato.PrecioModulo1 = registro.GetInt32(2);
                Dato.IdRangoUsuario = registro.GetByte(3);
                Dato.CodigoModulo = registro.GetByte(4);
                Dato.IdListaPrecio = registro.GetByte(5);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from PagoSuscripcion where idPagoSuscripcion=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<PagoSuscripcion> Listar()
        {
            List<PagoSuscripcion> Lista = new List<PagoSuscripcion>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from PagoSuscripcion";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                PagoSuscripcion Objeto = new PagoSuscripcion();
                Objeto.IdPagoSuscripcion = registro.GetByte(0);
                Objeto.IdTipoSuscripcion = registro.GetByte(1);
                Objeto.PrecioModulo1 = registro.GetInt32(2);
                Objeto.IdRangoUsuario = registro.GetByte(3);
                Objeto.CodigoModulo = registro.GetByte(4);
                Objeto.IdListaPrecio = registro.GetByte(5);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idPagoSuscripcion, byte idTipoSus, int PrecioMod, byte idRangoU, byte codigoMod, byte idListaP)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update PagoSuscripcion set idTipoSuscripcion=@idTipoSus,PrecioModulo=@PrecioMod, idRangoUsuario=@idRangoU, codigoMOdulo=@codigoMod, idListaPrecio=@idListaP where idPagoSuscripcion=@idPagoSuscripcion";
            comando.Parameters.AddWithValue("@idPagoSuscripcion", idPagoSuscripcion);
            comando.Parameters.AddWithValue("@idTipoSus", idTipoSus);
            comando.Parameters.AddWithValue("@PrecioMod", PrecioMod);
            comando.Parameters.AddWithValue("@idRangoU", idRangoU);
            comando.Parameters.AddWithValue("@codigoMod", codigoMod);
            comando.Parameters.AddWithValue("@idListaP", idListaP);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}