﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_UbicacionProductoGestion
    {
        public SqlConnection conexion;
        public string error;

        public GD_UbicacionProductoGestion()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(UbicacionProductoGestion Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "AgregarUbicacion";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@codigoProducto", Dato.CodigoProducto);
            comando.Parameters.AddWithValue("@ubicacion", Dato.Ubicacion1);
            comando.Parameters.AddWithValue("@Cantidad", Dato.Cantidad1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public UbicacionProductoGestion consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from UbicacionProductoSaldo where idUbicacion=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                UbicacionProductoGestion Dato = new UbicacionProductoGestion();
                Dato.IdUbicacion= registro.GetByte(0);
                Dato.TipoGestio = registro.GetString(1);
                Dato.IdGestion = registro.GetByte(2);
                Dato.CodigoProducto = registro.GetByte(3);
                Dato.Ubicacion1= registro.GetString(4);
                Dato.Cantidad1= registro.GetInt32(5);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from UbicacionProductoSaldo where idUbicacion=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();

        }

        //Método para mostrar 
        public List<UbicacionProductoGestion> Listar()
        {
            List<UbicacionProductoGestion> Lista = new List<UbicacionProductoGestion>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from UbicacionProductoSaldo";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                UbicacionProductoGestion Objeto = new UbicacionProductoGestion();
                Objeto.IdUbicacion = registro.GetByte(0);
                Objeto.TipoGestio= registro.GetString(1);
                Objeto.IdGestion = registro.GetByte(2);
                Objeto.CodigoProducto = registro.GetByte(3);
                Objeto.Ubicacion1= registro.GetString(4);
                Objeto.Cantidad1= registro.GetInt32(5);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte codigoProducto, string ubicacion, int Cantidad, byte idUbicacion)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "EditarUbicacion";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@codigoProducto", codigoProducto);
            comando.Parameters.AddWithValue("@ubicacion", ubicacion);
            comando.Parameters.AddWithValue("@Cantidad", Cantidad);
            comando.Parameters.AddWithValue("@idUbicacion", idUbicacion);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }

        public DataSet ConsultarPasillo(string Consulta, byte idBodega)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta + "idBodega= @idBodega";
            comando.Parameters.AddWithValue("@idBodega", idBodega);
            comando.ExecuteNonQuery();
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);

            //comando.Connection.Close();
            return ds;
        }

        public DataSet ConsultarEstante(string Consulta, int Pasillo)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta + "idPasillo= @idPasillo";
            comando.Parameters.AddWithValue("@idPasillo", Pasillo);
            comando.ExecuteNonQuery();
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);

            //comando.Connection.Close();
            return ds;
        }

        public DataSet ConsultarNivel(string Consulta, string Estante)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta + "idEstante= @idEstante";
            comando.Parameters.AddWithValue("@idEstante", Estante);
            comando.ExecuteNonQuery();
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);

            //comando.Connection.Close();
            return ds;
        }
    }
}
