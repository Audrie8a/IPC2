create database LaMascara
use LaMascara
create table Tienda(
idTienda tinyint identity primary key,
Ubicacion varchar (1000) not null,
Departamento varchar(1000) not null,
Municipio varchar (1000) not null, 
Telefono varchar(1000) not null,
Encargado varchar(1000) not null
);
Go

create table Producto(
idProducto tinyint identity primary key,
Categoria varchar(1000)  not null,
Cantidad int not null,
Marca varchar(1000) not null,
Precio float not null,
FechaVencimiento date null,
Tamano int not null, 
idTienda tinyint not null
);
Go

Create table Empleado(
CUI int primary key,
Nombre varchar (1000) not null,
Apellido varchar (1000) not null,
Telefono varchar (1000) not null,
Puesto varchar (1000) not null,
FechaIniLabores date not null,
FechaFinLabores date not null,
HoraIni time not null,
HoraFin time not null,
idTiendaReferente tinyint not null,
NombreJefe varchar (1000)null,
Contrasena varchar(1000)
);

Go
Alter table Producto add constraint fk_TiendaProducto foreign key (idTienda) references Tienda(idTienda);
Alter table Empleado add constraint fk_TiendaEmpleado foreign key (idTiendaReferente) references Tienda(idTienda);
