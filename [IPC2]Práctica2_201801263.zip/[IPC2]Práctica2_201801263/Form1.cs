﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _IPC2_Práctica2_201801263
{
    public partial class Form1 : Form
    {
        GD_Login login = new GD_Login();
        public Form1()
        {
            
            InitializeComponent();
        }

        private void BtnIngresar_Click(object sender, EventArgs e)
        {
            
        }
        //Método para comporbar conexion 
        public void ComprobarConexion() {
            Conexion conexion = new Conexion();
            if (conexion.GetConection())
            {
                MessageBox.Show("YES");
            }
            else
            {
                MessageBox.Show("AJJJJJJJ");
            }
        }
        

        private void Button1_Click(object sender, EventArgs e)
        {
            wfTiendas tienda = new wfTiendas();
            tienda.Show();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            wfProducto producto = new wfProducto();
            producto.Show();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            wfEmpleado Empleado = new wfEmpleado();
            Empleado.Show();
        }

        private void BtnIngresar_Click_1(object sender, EventArgs e)
        {
            bool id = false;
            try {
                id = login.validar_usuario(txtUsuario.Text, txtPassword.Text);
            } catch (Exception ex) {
                MessageBox.Show("Error al ingresar Usuario, favor ingresar los datos numéricos correspondientes al CUI");
            }
            

            if (id == false)
            {
                MessageBox.Show("Favor revise los datos ingresado, no se ha encontrado Usuario.");
            }
            else if (id == true)
            {
                wfPagPrincipal pag = new wfPagPrincipal();
                pag.Show();
                this.Hide();

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
