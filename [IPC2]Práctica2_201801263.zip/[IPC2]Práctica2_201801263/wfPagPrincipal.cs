﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _IPC2_Práctica2_201801263
{
    public partial class wfPagPrincipal : Form
    {
        public wfPagPrincipal()
        {
            InitializeComponent();
        }

        private void BtnTienda_Click(object sender, EventArgs e)
        {
            wfTiendas tiendas = new wfTiendas();
            tiendas.Show();
            this.Hide();

        }

        private void BtnProducto_Click(object sender, EventArgs e)
        {
            wfProducto producto = new wfProducto();
            producto.Show();
            this.Hide();
        }

        private void BtnEmpleado_Click(object sender, EventArgs e)
        {
            wfEmpleado empleado = new wfEmpleado();
            empleado.Show();
            this.Hide();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea Salir?", "Salir", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
                Form1 login = new Form1();
                login.Close();
            }
        }
    }
}
