﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace _IPC2_Práctica2_201801263
{
    class GD_Tienda
    {
        public SqlConnection conexion;
        public string error;

        public GD_Tienda()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Tienda Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Tienda values (@Ubicacion, @Departamento, @Municipio, @Telefono, @Encargado);";
            comando.Parameters.AddWithValue("@Ubicacion", Dato.Ubicacion1);
            comando.Parameters.AddWithValue("@Departamento", Dato.Departamento1);
            comando.Parameters.AddWithValue("@Municipio", Dato.Municipio1);
            comando.Parameters.AddWithValue("@Telefono", Dato.Telefono1);
            comando.Parameters.AddWithValue("@Encargado", Dato.Encargado1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Tienda consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Tienda where idTienda=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Tienda Dato = new Tienda();
                Dato.IdTienda = registro.GetByte(0);
                Dato.Ubicacion1 = registro.GetString(1);
                Dato.Departamento1 = registro.GetString(2);
                Dato.Municipio1 = registro.GetString(3);
                Dato.Telefono1 = registro.GetString(4);
                Dato.Encargado1 = registro.GetString(5);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Tienda where idTienda=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Tienda> Listar(string Consulta, string Dato)
        {
            List<Tienda> Lista = new List<Tienda>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            comando.Parameters.AddWithValue("@Dato", Dato);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                Tienda Objeto = new Tienda();
                Objeto.IdTienda= registro.GetByte(0);
                Objeto.Ubicacion1 = registro.GetString(1);
                Objeto.Departamento1 = registro.GetString(2);
                Objeto.Municipio1 = registro.GetString(3);
                Objeto.Telefono1 = registro.GetString(4);
                Objeto.Encargado1 = registro.GetString(5);
                Lista.Add(Objeto);
            }
            registro.Close();
            return Lista;
        }

        public List<Tienda> Listar2()
        {
            List<Tienda> Lista = new List<Tienda>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Tienda";
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                Tienda Objeto = new Tienda();
                Objeto.IdTienda = registro.GetByte(0);
                Objeto.Ubicacion1 = registro.GetString(1);
                Objeto.Departamento1 = registro.GetString(2);
                Objeto.Municipio1 = registro.GetString(3);
                Objeto.Telefono1 = registro.GetString(4);
                Objeto.Encargado1 = registro.GetString(5);
                Lista.Add(Objeto);
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte idTienda, string Ubicacion, string Depa, string Muni, string Tel, string Encargado)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Tienda set Ubicacion=@Ubicacion, Departamento=@Depa, Municipio=@Muni, Telefono=@Tel, Encargado=@Encargado where idTienda=@idTienda";
            comando.Parameters.AddWithValue("@idTienda", idTienda);
            comando.Parameters.AddWithValue("@Ubicacion", Ubicacion);
            comando.Parameters.AddWithValue("@Depa", Depa);
            comando.Parameters.AddWithValue("@Muni", Muni);
            comando.Parameters.AddWithValue("@Tel", Tel);
            comando.Parameters.AddWithValue("@Encargado", Encargado);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        
    }
}
