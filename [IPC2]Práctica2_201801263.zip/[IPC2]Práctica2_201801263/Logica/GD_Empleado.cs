﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace _IPC2_Práctica2_201801263
{
    class GD_Empleado
    {
        public SqlConnection conexion;
        public string error;

        public GD_Empleado()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Empleado Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Empleado values (@CUI, @Nombre, @Apellido, @Telefono, @Puesto, @FechaIniLab, @FechaFinLab, @HoraIni, @HoraFin, @idTiendaRef, @NombreJefe, @Contrasena);";
            comando.Parameters.AddWithValue("@CUI", Dato.Cui1);
            comando.Parameters.AddWithValue("@Nombre", Dato.Nombre1);
            comando.Parameters.AddWithValue("@Apellido", Dato.Apellido1);
            comando.Parameters.AddWithValue("@Telefono", Dato.Telefono1);
            comando.Parameters.AddWithValue("@Puesto", Dato.Puesto1);
            comando.Parameters.AddWithValue("@FechaIniLab", Dato.FechaIniLab);
            comando.Parameters.AddWithValue("@FechaFinLab", Dato.FechaFinLab);
            comando.Parameters.AddWithValue("@HoraIni", Dato.HoraIni1);
            comando.Parameters.AddWithValue("@HoraFin", Dato.HoraFin1);
            comando.Parameters.AddWithValue("@idTiendaRef", Dato.IdTiendaRef);
            comando.Parameters.AddWithValue("@NombreJefe", Dato.NombreJefe1);
            comando.Parameters.AddWithValue("@Contrasena", Dato.Contrasena1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Empleado consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Empleado where CUI=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Empleado Dato = new Empleado();
                Dato.Cui1 = registro.GetInt32(0);
                Dato.Nombre1= registro.GetString(1);
                Dato.Apellido1 = registro.GetString(2);
                Dato.Telefono1 = registro.GetString(3);
                Dato.Puesto1 = registro.GetString(4);
                Dato.FechaIniLab = registro.GetDateTime(5);
                Dato.FechaFinLab = registro.GetDateTime(6);
                Dato.HoraIni1 = registro.GetString(7);
                Dato.HoraFin1 = registro.GetString(8);
                Dato.IdTiendaRef = registro.GetByte(9);
                Dato.NombreJefe1= registro.GetString(10);
                Dato.Contrasena1 = registro.GetString(11);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Empleado where CUI=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Empleado> Listar(string Consulta, string Dato)
        {
            List<Empleado> Lista = new List<Empleado>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            comando.Parameters.AddWithValue("@Dato", Dato);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                Empleado Dato1 = new Empleado();
                Dato1.Cui1 = registro.GetInt32(0);
                Dato1.Nombre1 = registro.GetString(1);
                Dato1.Apellido1 = registro.GetString(2);
                Dato1.Telefono1 = registro.GetString(3);
                Dato1.Puesto1 = registro.GetString(4);
                Dato1.FechaIniLab = registro.GetDateTime(5);
                Dato1.FechaFinLab = registro.GetDateTime(6);
                Dato1.HoraIni1 = registro.GetString(7);
                Dato1.HoraFin1 = registro.GetString(8);
                Dato1.IdTiendaRef = registro.GetByte(9);
                Dato1.NombreJefe1 = registro.GetString(10);
                Dato1.Contrasena1 = registro.GetString(11);
                Lista.Add(Dato1);
            }
            registro.Close();
            return Lista;
        }
        public List<Empleado> Listar3(string Consulta, byte Dato)
        {
            List<Empleado> Lista = new List<Empleado>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            comando.Parameters.AddWithValue("@Dato", Dato);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                Empleado Dato1 = new Empleado();
                Dato1.Cui1 = registro.GetInt32(0);
                Dato1.Nombre1 = registro.GetString(1);
                Dato1.Apellido1 = registro.GetString(2);
                Dato1.Telefono1 = registro.GetString(3);
                Dato1.Puesto1 = registro.GetString(4);
                Dato1.FechaIniLab = registro.GetDateTime(5);
                Dato1.FechaFinLab = registro.GetDateTime(6);
                Dato1.HoraIni1 = registro.GetString(7);
                Dato1.HoraFin1 = registro.GetString(8);
                Dato1.IdTiendaRef = registro.GetByte(9);
                Dato1.NombreJefe1 = registro.GetString(10);
                Dato1.Contrasena1 = registro.GetString(11);                
                Lista.Add(Dato1);
            }
            registro.Close();
            return Lista;
        }

        public List<Empleado> Listar2()
        {
            List<Empleado> Lista = new List<Empleado>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Empleado";
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                Empleado Dato = new Empleado();
                Dato.Cui1 = registro.GetInt32(0);
                Dato.Nombre1 = registro.GetString(1);
                Dato.Apellido1 = registro.GetString(2);
                Dato.Telefono1 = registro.GetString(3);
                Dato.Puesto1 = registro.GetString(4);
                Dato.FechaIniLab = registro.GetDateTime(5);
                Dato.FechaFinLab = registro.GetDateTime(6);
                Dato.HoraIni1 = registro.GetString(7);
                Dato.HoraFin1 = registro.GetString(8);
                Dato.IdTiendaRef = registro.GetByte(9);
                Dato.NombreJefe1 = registro.GetString(10);
                Dato.Contrasena1 = registro.GetString(11);
                Lista.Add(Dato);
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int identificacion, int cui, string NOmbre, string Apellido, string Telefono, string puesto, DateTime fechaIniLab, DateTime fechaFinLab, string HoraIni, string horaFin, byte idTiendaRef, string nombreJefe, string contrasena)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Empleado set CUI=@cui, Nombre=@Nombre, Apellido=@Apellido, Telefono=@Telefono, Puesto=@Puesto, FechaIniLabores=@FechaIniLab, FechaFinLabores=@FechaFinLab, HoraIni=@HoraIni, HoraFin=@HoraFin, idTiendaReferente=@idTiendaRef, NombreJefe=@NombreJefe, Contrasena=@Contrasena where CUI=@identificacion";
            comando.Parameters.AddWithValue("@cui", cui);
            comando.Parameters.AddWithValue("@Nombre", NOmbre);
            comando.Parameters.AddWithValue("@Apellido", Apellido);
            comando.Parameters.AddWithValue("@Telefono", Telefono);
            comando.Parameters.AddWithValue("@Puesto", puesto);
            comando.Parameters.AddWithValue("@FechaIniLab", fechaIniLab);
            comando.Parameters.AddWithValue("@FechaFinLab", fechaFinLab);
            comando.Parameters.AddWithValue("@HoraIni", HoraIni);
            comando.Parameters.AddWithValue("@HoraFin", horaFin);
            comando.Parameters.AddWithValue("@idTiendaRef", idTiendaRef);
            comando.Parameters.AddWithValue("@NombreJefe", nombreJefe);
            comando.Parameters.AddWithValue("@Contrasena", contrasena);
            comando.Parameters.AddWithValue("@identificacion", identificacion);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }
    }
}
