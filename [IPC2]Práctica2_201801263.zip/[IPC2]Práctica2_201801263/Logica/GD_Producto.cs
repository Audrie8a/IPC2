﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace _IPC2_Práctica2_201801263
{
    class GD_Producto
    {
        public SqlConnection conexion;
        public string error;

        public GD_Producto()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Producto Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Producto values (@Cat, @Cantindad, @Marca, @Precio, @FechaVec, @Tamano,@idTienda);";
            comando.Parameters.AddWithValue("@Cat", Dato.Categoria1);
            comando.Parameters.AddWithValue("@Cantindad", Dato.Cantidad1);
            comando.Parameters.AddWithValue("@Marca", Dato.Marca1);
            comando.Parameters.AddWithValue("@Precio", Dato.Precio1);
            comando.Parameters.AddWithValue("@FechaVec", Dato.FechaVencimiento1);
            comando.Parameters.AddWithValue("@Tamano", Dato.Tamano1);
            comando.Parameters.AddWithValue("@idTienda", Dato.IdTienda);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Producto consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Producto where idProducto=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Producto Dato = new Producto();
                Dato.IdProducto = registro.GetByte(0);
                Dato.Categoria1 = registro.GetString(1);
                Dato.Cantidad1 = registro.GetInt32(2);
                Dato.Marca1 = registro.GetString(3);
                //Dato.Precio1 = Convert.ToSingle(registro.GetFloat(4));
                Dato.FechaVencimiento1 = registro.GetDateTime(5);
                Dato.Tamano1 = registro.GetInt32(6);
                Dato.IdTienda = registro.GetByte(7);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Producto where idProducto=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Producto> Listar(string Consulta, string Dato)
        {
            List<Producto> Lista = new List<Producto>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            comando.Parameters.AddWithValue("@Dato", Dato);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                Producto Dato1 = new Producto();
                Dato1.IdProducto = registro.GetByte(0);
                Dato1.Categoria1 = registro.GetString(1);
                Dato1.Cantidad1 = registro.GetInt32(2);
                Dato1.Marca1 = registro.GetString(3);
               // Dato1.Precio1 = Convert.ToSingle(registro.GetFloat(4));
                Dato1.FechaVencimiento1 = registro.GetDateTime(5);
                Dato1.Tamano1 = registro.GetInt32(6);
                Dato1.IdTienda = registro.GetByte(7);
                Lista.Add(Dato1);
            }
            registro.Close();
            return Lista;
        }
        public List<Producto> Listar3(string Consulta, byte Dato)
        {
            List<Producto> Lista = new List<Producto>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            comando.Parameters.AddWithValue("@Dato", Dato);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                Producto Dato1 = new Producto();
                Dato1.IdProducto = registro.GetByte(0);
                Dato1.Categoria1 = registro.GetString(1);
                Dato1.Cantidad1 = registro.GetInt32(2);
                Dato1.Marca1 = registro.GetString(3);
                //Dato1.Precio1 =registro.GetFloat(4);
                Dato1.FechaVencimiento1 = registro.GetDateTime(5);
                Dato1.Tamano1 = registro.GetInt32(6);
                Dato1.IdTienda = registro.GetByte(7);
                Lista.Add(Dato1);
            }
            registro.Close();
            return Lista;
        }

        public List<Producto> Listar2()
        {
            List<Producto> Lista = new List<Producto>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Producto";
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                Producto Dato = new Producto();
                Dato.IdProducto = registro.GetByte(0);
                Dato.Categoria1 = registro.GetString(1);
                Dato.Cantidad1 = registro.GetInt32(2);
                Dato.Marca1 = registro.GetString(3);
               // Dato.Precio1 = Convert.ToSingle(registro.GetFloat(4));
                Dato.FechaVencimiento1 = registro.GetDateTime(5);
                Dato.Tamano1 = registro.GetInt32(6);
                Dato.IdTienda = registro.GetByte(7);
                Lista.Add(Dato);
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int identificacion, string Cat, int Cantidad, string Marca, float Precio, DateTime FechaVec, int Tamano, byte idTienda)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Producto set Categoria=@Cat, Cantidad=@Cant, Marca=@Marca, Precio=@Precio, FechaVencimiento=@FechaVec, Tamano=@Tama, idTienda=@idTienda where idProducto=@identificacion";
            comando.Parameters.AddWithValue("@Cat", Cat);
            comando.Parameters.AddWithValue("@Cant", Cantidad);
            comando.Parameters.AddWithValue("@Marca", Marca);
            comando.Parameters.AddWithValue("@Precio", Precio);
            comando.Parameters.AddWithValue("@FechaVec", FechaVec);
            comando.Parameters.AddWithValue("@Tama", Tamano);
            comando.Parameters.AddWithValue("@idTienda", idTienda);
            comando.Parameters.AddWithValue("@identificacion", identificacion);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }
    }
}
