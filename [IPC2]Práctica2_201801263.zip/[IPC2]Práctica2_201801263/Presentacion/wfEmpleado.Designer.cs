﻿namespace _IPC2_Práctica2_201801263
{
    partial class wfEmpleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DDLJefe = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.DDLidentificacion = new System.Windows.Forms.ComboBox();
            this.txtPuesto = new System.Windows.Forms.TextBox();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.txtApellido = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.DDLdepa = new System.Windows.Forms.ComboBox();
            this.DDLidMuni = new System.Windows.Forms.ComboBox();
            this.btnListar = new System.Windows.Forms.Button();
            this.btnEditar = new System.Windows.Forms.Button();
            this.gvEmpleado = new System.Windows.Forms.DataGridView();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.DDLtienda = new System.Windows.Forms.ComboBox();
            this.txtContrasena = new System.Windows.Forms.TextBox();
            this.txtCUI = new System.Windows.Forms.TextBox();
            this.DTPfechaIni = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.DTPfechaFin = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.DTPhoraIni = new System.Windows.Forms.DateTimePicker();
            this.DTPhoraFin = new System.Windows.Forms.DateTimePicker();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.DDLtiendaRef = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnAgregar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gvEmpleado)).BeginInit();
            this.SuspendLayout();
            // 
            // DDLJefe
            // 
            this.DDLJefe.FormattingEnabled = true;
            this.DDLJefe.Location = new System.Drawing.Point(113, 349);
            this.DDLJefe.Name = "DDLJefe";
            this.DDLJefe.Size = new System.Drawing.Size(121, 21);
            this.DDLJefe.TabIndex = 44;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 202);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 13);
            this.label9.TabIndex = 43;
            this.label9.Text = "Fecha Inicio:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 175);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 13);
            this.label8.TabIndex = 42;
            this.label8.Text = "Puesto:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 144);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 41;
            this.label7.Text = "Telefono:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 40;
            this.label6.Text = "Apellido:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 94);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 39;
            this.label5.Text = "Nombre:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 64);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(28, 13);
            this.label4.TabIndex = 38;
            this.label4.Text = "CUI:";
            this.label4.Click += new System.EventHandler(this.Label4_Click);
            // 
            // DDLidentificacion
            // 
            this.DDLidentificacion.FormattingEnabled = true;
            this.DDLidentificacion.Location = new System.Drawing.Point(129, 493);
            this.DDLidentificacion.Name = "DDLidentificacion";
            this.DDLidentificacion.Size = new System.Drawing.Size(121, 21);
            this.DDLidentificacion.TabIndex = 37;
            // 
            // txtPuesto
            // 
            this.txtPuesto.Location = new System.Drawing.Point(113, 169);
            this.txtPuesto.Name = "txtPuesto";
            this.txtPuesto.Size = new System.Drawing.Size(121, 20);
            this.txtPuesto.TabIndex = 36;
            // 
            // txtTelefono
            // 
            this.txtTelefono.Location = new System.Drawing.Point(113, 142);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(121, 20);
            this.txtTelefono.TabIndex = 35;
            // 
            // txtApellido
            // 
            this.txtApellido.Location = new System.Drawing.Point(113, 115);
            this.txtApellido.Name = "txtApellido";
            this.txtApellido.Size = new System.Drawing.Size(121, 20);
            this.txtApellido.TabIndex = 34;
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(113, 88);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(121, 20);
            this.txtNombre.TabIndex = 33;
            this.txtNombre.TextChanged += new System.EventHandler(this.TxtUbicacion_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(634, 344);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 32;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(421, 434);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 31;
            this.label2.Text = "Departamento";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(423, 393);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "Municipio";
            // 
            // DDLdepa
            // 
            this.DDLdepa.FormattingEnabled = true;
            this.DDLdepa.Location = new System.Drawing.Point(517, 427);
            this.DDLdepa.Name = "DDLdepa";
            this.DDLdepa.Size = new System.Drawing.Size(121, 21);
            this.DDLdepa.TabIndex = 29;
            // 
            // DDLidMuni
            // 
            this.DDLidMuni.FormattingEnabled = true;
            this.DDLidMuni.Location = new System.Drawing.Point(517, 390);
            this.DDLidMuni.Name = "DDLidMuni";
            this.DDLidMuni.Size = new System.Drawing.Size(121, 21);
            this.DDLidMuni.TabIndex = 28;
            // 
            // btnListar
            // 
            this.btnListar.Location = new System.Drawing.Point(707, 365);
            this.btnListar.Name = "btnListar";
            this.btnListar.Size = new System.Drawing.Size(74, 59);
            this.btnListar.TabIndex = 27;
            this.btnListar.Text = "Listar";
            this.btnListar.UseVisualStyleBackColor = true;
            this.btnListar.Click += new System.EventHandler(this.BtnListar_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.Location = new System.Drawing.Point(176, 437);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(75, 23);
            this.btnEditar.TabIndex = 26;
            this.btnEditar.Text = "Editar";
            this.btnEditar.UseVisualStyleBackColor = true;
            this.btnEditar.Click += new System.EventHandler(this.BtnEditar_Click);
            // 
            // gvEmpleado
            // 
            this.gvEmpleado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvEmpleado.Location = new System.Drawing.Point(408, 96);
            this.gvEmpleado.Name = "gvEmpleado";
            this.gvEmpleado.Size = new System.Drawing.Size(489, 213);
            this.gvEmpleado.TabIndex = 25;
            // 
            // btnConsultar
            // 
            this.btnConsultar.Location = new System.Drawing.Point(95, 437);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(75, 23);
            this.btnConsultar.TabIndex = 24;
            this.btnConsultar.Text = "Consultar";
            this.btnConsultar.UseVisualStyleBackColor = true;
            this.btnConsultar.Click += new System.EventHandler(this.BtnConsultar_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(425, 359);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 13);
            this.label10.TabIndex = 46;
            this.label10.Text = "Tienda";
            // 
            // DDLtienda
            // 
            this.DDLtienda.FormattingEnabled = true;
            this.DDLtienda.Location = new System.Drawing.Point(516, 352);
            this.DDLtienda.Name = "DDLtienda";
            this.DDLtienda.Size = new System.Drawing.Size(121, 21);
            this.DDLtienda.TabIndex = 45;
            // 
            // txtContrasena
            // 
            this.txtContrasena.Location = new System.Drawing.Point(113, 382);
            this.txtContrasena.Name = "txtContrasena";
            this.txtContrasena.Size = new System.Drawing.Size(121, 20);
            this.txtContrasena.TabIndex = 47;
            // 
            // txtCUI
            // 
            this.txtCUI.Location = new System.Drawing.Point(113, 57);
            this.txtCUI.Name = "txtCUI";
            this.txtCUI.Size = new System.Drawing.Size(121, 20);
            this.txtCUI.TabIndex = 48;
            // 
            // DTPfechaIni
            // 
            this.DTPfechaIni.Location = new System.Drawing.Point(113, 202);
            this.DTPfechaIni.Name = "DTPfechaIni";
            this.DTPfechaIni.Size = new System.Drawing.Size(200, 20);
            this.DTPfechaIni.TabIndex = 50;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 356);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(30, 13);
            this.label11.TabIndex = 55;
            this.label11.Text = "Jefe:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 325);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 13);
            this.label12.TabIndex = 54;
            this.label12.Text = "Tienda:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 294);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(50, 13);
            this.label13.TabIndex = 53;
            this.label13.Text = "Hora Fin:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 267);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 13);
            this.label14.TabIndex = 52;
            this.label14.Text = "Hora Inicio:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(13, 240);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 13);
            this.label15.TabIndex = 51;
            this.label15.Text = "Fecha Fin:";
            // 
            // DTPfechaFin
            // 
            this.DTPfechaFin.Location = new System.Drawing.Point(113, 238);
            this.DTPfechaFin.Name = "DTPfechaFin";
            this.DTPfechaFin.Size = new System.Drawing.Size(200, 20);
            this.DTPfechaFin.TabIndex = 56;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(14, 385);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(64, 13);
            this.label16.TabIndex = 57;
            this.label16.Text = "Contraseña:";
            // 
            // DTPhoraIni
            // 
            this.DTPhoraIni.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.DTPhoraIni.Location = new System.Drawing.Point(113, 264);
            this.DTPhoraIni.Name = "DTPhoraIni";
            this.DTPhoraIni.Size = new System.Drawing.Size(200, 20);
            this.DTPhoraIni.TabIndex = 59;
            // 
            // DTPhoraFin
            // 
            this.DTPhoraFin.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.DTPhoraFin.Location = new System.Drawing.Point(113, 292);
            this.DTPhoraFin.Name = "DTPhoraFin";
            this.DTPhoraFin.Size = new System.Drawing.Size(200, 20);
            this.DTPhoraFin.TabIndex = 60;
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(257, 437);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(75, 23);
            this.btnEliminar.TabIndex = 61;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);
            // 
            // DDLtiendaRef
            // 
            this.DDLtiendaRef.FormattingEnabled = true;
            this.DDLtiendaRef.Location = new System.Drawing.Point(114, 321);
            this.DDLtiendaRef.Name = "DDLtiendaRef";
            this.DDLtiendaRef.Size = new System.Drawing.Size(121, 21);
            this.DDLtiendaRef.TabIndex = 62;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(20, 496);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(86, 13);
            this.label17.TabIndex = 63;
            this.label17.Text = "CUI consultado: ";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(573, 37);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(324, 40);
            this.button1.TabIndex = 64;
            this.button1.Text = "Regresar a Página Principal";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(141, 26);
            this.button2.TabIndex = 146;
            this.button2.Text = "Subir Archivo";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(12, 437);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 147;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.BtnAgregar_Click);
            // 
            // wfEmpleado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 591);
            this.ControlBox = false;
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.DDLtiendaRef);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.DTPhoraFin);
            this.Controls.Add(this.DTPhoraIni);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.DTPfechaFin);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.DTPfechaIni);
            this.Controls.Add(this.txtCUI);
            this.Controls.Add(this.txtContrasena);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.DDLtienda);
            this.Controls.Add(this.DDLJefe);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.DDLidentificacion);
            this.Controls.Add(this.txtPuesto);
            this.Controls.Add(this.txtTelefono);
            this.Controls.Add(this.txtApellido);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DDLdepa);
            this.Controls.Add(this.DDLidMuni);
            this.Controls.Add(this.btnListar);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.gvEmpleado);
            this.Controls.Add(this.btnConsultar);
            this.Name = "wfEmpleado";
            this.Text = "wfEmpleado";
            this.Load += new System.EventHandler(this.WfEmpleado_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gvEmpleado)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox DDLJefe;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox DDLidentificacion;
        private System.Windows.Forms.TextBox txtPuesto;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.TextBox txtApellido;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox DDLdepa;
        private System.Windows.Forms.ComboBox DDLidMuni;
        private System.Windows.Forms.Button btnListar;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.DataGridView gvEmpleado;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox DDLtienda;
        private System.Windows.Forms.TextBox txtContrasena;
        private System.Windows.Forms.TextBox txtCUI;
        private System.Windows.Forms.DateTimePicker DTPfechaIni;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker DTPfechaFin;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker DTPhoraIni;
        private System.Windows.Forms.DateTimePicker DTPhoraFin;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.ComboBox DDLtiendaRef;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnAgregar;
    }
}