﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Xml.Linq;

namespace _IPC2_Práctica2_201801263
{
    public partial class wfProducto : Form
    {
        GD_Producto Producto = new GD_Producto();
        public SqlConnection conexion;
        public string error;
        OpenFileDialog OFD;
        String Ruta = "";
        String Texto = "";
        SaveFileDialog save;
        public wfProducto()
        {
            InitializeComponent();
            btnEditar.Enabled = false;
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
            IniciarLLenadoDropDownList();
            OFD = new OpenFileDialog();
            OFD.RestoreDirectory = true;
            OFD.InitialDirectory = "E:\\";
            OFD.FilterIndex = 1;
            OFD.Filter = "xml files(*.xml)|*.xml";
        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Producto Objeto = new Producto();
                Objeto.Categoria1 = txtCategoria.Text;
                Objeto.Cantidad1 = Convert.ToInt32(txtCantidad.Text);
                Objeto.Marca1 = txtMarca.Text;
                Objeto.Precio1= Convert.ToSingle(txtPrecio.Text);
                Objeto.FechaVencimiento1= Convert.ToDateTime(DTPfechaIVec.Value);
                Objeto.Tamano1 = Convert.ToInt32(txtTama.Text);
                Objeto.IdTienda= Convert.ToByte(DDLtiendaP.Text);

                if (txtCantidad.Text != null && txtCategoria.Text != null && txtMarca.Text != null && txtPrecio.Text != null && txtTama.Text != null)
                {
                    bool agregado = Producto.agregar(Objeto);
                    if (agregado)
                    {
                        MessageBox.Show("Producto Agregado Exitosamente");
                        limpiar();
                        Listar2();
                        IniciarLLenadoDropDownList();

                    }
                    else
                    {
                        MessageBox.Show(Producto.error);
                    }
                }
                else
                {
                    MessageBox.Show("Favor Llenar todos los datos");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex +"Favor Llenar todos los datos");
            }
        }

        private void BtnConsultar_Click(object sender, EventArgs e)
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Producto objeto = Producto.consultar(identificacion);
                if (objeto != null)
                {
                    DDLidentificacion.Text = Convert.ToString(objeto.IdProducto);
                    txtCategoria.Text = objeto.Categoria1;
                    txtCantidad.Text =Convert.ToString(objeto.Cantidad1);
                    txtMarca.Text = objeto.Marca1;
                    txtPrecio.Text = Convert.ToString(objeto.Precio1);
                    DTPfechaIVec.Value = objeto.FechaVencimiento1;                    
                    txtTama.Text = Convert.ToString(objeto.Tamano1);
                    DDLtiendaP.Text = Convert.ToString(objeto.IdTienda);
                    MessageBox.Show("Empleado consultada");
                    btnEditar.Enabled = true;
                    Listar2();
                }
                else
                {
                    MessageBox.Show("No hay Productos agregados a la base de datos");
                }
            }
            catch (Exception ex) { MessageBox.Show(ex +"Favor seleccionar la identificación del Prodcuto a buscar"); };
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                MessageBox.Show("Favor consulte el Producto a Editar");
            }
            else
            {
                try
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);
                    string Categoria = txtCategoria.Text;
                    int Cantidad = Convert.ToInt32(txtCantidad.Text);
                    string Marca = txtMarca.Text;
                    float Precio = Convert.ToSingle(txtPrecio.Text);
                    DateTime fechaVec = DTPfechaIVec.Value;
                    int  tamano = Convert.ToInt32(txtTama.Text);
                    byte idTienda = Convert.ToByte(DDLtiendaP.Text);

                    Producto.editar(identificacion,Categoria, Cantidad, Marca, Precio, fechaVec, tamano, idTienda);
                    Listar2();
                    IniciarLLenadoDropDownList();
                    limpiar();
                    MessageBox.Show("El Producto " + identificacion + " ha sido Editado");
                }
                catch (Exception ex) { MessageBox.Show(" " + ex); }
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Producto.eliminar(identificacion);
                    MessageBox.Show("Producto Eliminado exitosamente");
                    Listar2();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    MessageBox.Show("Favor ingresar identificación del Producto a eliminar");
                }

            }
            catch (Exception) { MessageBox.Show("Favor ingresar identificación del Producto a eliminar"); }
        }

        //Metodo para listaClientes
        public void Listar(string Consulta, string Dato)
        {
            List<Producto> Lista = Producto.Listar(Consulta, Dato);
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Productos agregadas en la base de datos en: " + Dato);
            }
            else
            {
                gvProducto.DataSource = Lista;

            }
        }

        public void Listar2()
        {
            List<Producto> Lista = Producto.Listar2();
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Producto agregadas en la base de datos");
            }
            else
            {
                gvProducto.DataSource = Lista;

            }
        }

        public void Listar3(String Consulta, byte Dato)
        {
            List<Producto> Lista = Producto.Listar3(Consulta, Dato);
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Producto agregadas en la base de datos En esta tienda: " + Dato);
            }
            else
            {
                gvProducto.DataSource = Lista;

            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtCategoria.Text = "";
            txtCantidad.Text = "";
            txtMarca.Text = "";
            txtPrecio.Text = "";
            txtTama.Text = "";           
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            LimpiarComboBox();
            LlenarDDLidentificacion();
            LlenarDDLMuni();
            LlenarDDLDepa();
            LlenarDDLTienda();
        }

        public void LimpiarComboBox()
        {
            DDLidentificacion.DataSource = null;
            DDLidentificacion.Items.Clear();

            DDLtiendaP.DataSource = null;
            DDLtiendaP.Items.Clear();

            DDLdepa.DataSource = null;
            DDLdepa.Items.Clear();

            DDLidMuni.DataSource = null;
            DDLidMuni.Items.Clear();

            DDLtienda.DataSource = null;
            DDLtienda.Items.Clear();
        }
        public void LlenarDDLidentificacion()
        {
            DDLidentificacion.Items.Insert(0, "[Seleccionar Producto]");
            SqlCommand SC = new SqlCommand("select idProducto from Producto");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLidentificacion.Items.Add(dr[0]);
            }
            dr.Close();
        }
        public void LlenarDDLTienda()
        {
            DDLtienda.Items.Insert(0, "[Seleccionar Tienda]");
            DDLtiendaP.Items.Insert(0, "[Seleccionar Tienda]");
            SqlCommand SC = new SqlCommand("select idTienda from Tienda");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLtiendaP.Items.Add(dr[0]);
                DDLtienda.Items.Add(dr[0]);
            }
            dr.Close();
        }
        public void LlenarDDLMuni()
        {
            DDLidMuni.Items.Insert(0, "[Seleccionar Municipio]");
            SqlCommand SC = new SqlCommand("select Municipio from Tienda");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLidMuni.Items.Add(dr[0]);
            }
            dr.Close();
        }

        public void LlenarDDLDepa()
        {
            DDLdepa.Items.Insert(0, "[Seleccionar Departamento]");
            SqlCommand SC = new SqlCommand("select Departamento from Tienda");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLdepa.Items.Add(dr[0]);
            }
            dr.Close();
        }

        private void BtnListar_Click(object sender, EventArgs e)
        {
            if ((DDLdepa.SelectedIndex == -1 || DDLdepa.SelectedIndex == 0) && (DDLtienda.SelectedIndex == -1 || DDLtienda.SelectedIndex == 0) && (DDLidMuni.SelectedIndex != 0 && DDLidMuni.SelectedIndex != -1))
            {
                Listar("select P.idProducto, P.Categoria, P.Cantidad, P.Marca, P.Precio, P.FechaVencimiento, P.Tamano, P.idTienda  from Producto as P, Tienda as T where P.idTienda=T.idTienda and T.Municipio=@Dato", DDLidMuni.Text);
                MessageBox.Show("Se ha listado por Municipio");
                IniciarLLenadoDropDownList();
            }
            else if ((DDLdepa.SelectedIndex != 0 && DDLdepa.SelectedIndex != -1) && (DDLidMuni.SelectedIndex == -1 || DDLidMuni.SelectedIndex == 0) && (DDLtienda.SelectedIndex == -1 || DDLtienda.SelectedIndex == 0))
            {
                Listar("select P.idProducto, P.Categoria, P.Cantidad, P.Marca, P.Precio, P.FechaVencimiento, P.Tamano, P.idTienda  from Producto as P, Tienda as T where P.idTienda=T.idTienda and T.Departamento=@Dato", DDLdepa.Text);
                MessageBox.Show("Se ha listado por Departamento");
                IniciarLLenadoDropDownList();
            }
            else if ((DDLtienda.SelectedIndex != 0 && DDLtienda.SelectedIndex != -1) && (DDLidMuni.SelectedIndex == -1 || DDLidMuni.SelectedIndex == 0) && (DDLdepa.SelectedIndex == -1 || DDLdepa.SelectedIndex == 0))
            {
                Listar3("select* from Producto where idTienda=@Dato", Convert.ToByte(DDLtienda.Text));
                MessageBox.Show("Se ha listado por Tienda");
                IniciarLLenadoDropDownList();
            }
            else if ((DDLdepa.SelectedIndex == 0 && DDLidMuni.SelectedIndex == 0 && DDLtienda.SelectedIndex == 0) || (DDLdepa.SelectedIndex == -1 && DDLidMuni.SelectedIndex == -1 && DDLtienda.SelectedIndex == -1) ||
                (DDLdepa.SelectedIndex == 0 && DDLidMuni.SelectedIndex == 0 && DDLtienda.SelectedIndex == -1) || (DDLdepa.SelectedIndex == 0 && DDLidMuni.SelectedIndex == -1 && DDLtienda.SelectedIndex == 0)
                || (DDLdepa.SelectedIndex == 0 && DDLidMuni.SelectedIndex == -1 && DDLtienda.SelectedIndex == -1) || (DDLdepa.SelectedIndex == -1 && DDLidMuni.SelectedIndex == -1 && DDLtienda.SelectedIndex == 0)
                || (DDLdepa.SelectedIndex == -1 && DDLidMuni.SelectedIndex == 0 && DDLtienda.SelectedIndex == -1) || (DDLdepa.SelectedIndex == -1 && DDLidMuni.SelectedIndex == 0 && DDLtienda.SelectedIndex == 0))
            {
                MessageBox.Show("Favor seleccionar el tipo de búsqueda por Departamento o Municipio");
                IniciarLLenadoDropDownList();
            }
            else if ((DDLdepa.SelectedIndex != 0 && DDLidMuni.SelectedIndex != 0 && DDLtienda.SelectedIndex != 0) || (DDLdepa.SelectedIndex != -1 && DDLidMuni.SelectedIndex != -1 && DDLtienda.SelectedIndex != -1))
            {
                MessageBox.Show("Favor seleccionar un tipo de búsqueda a la vez. Elija un Departamento o un Municipio, no los dos al mismo tiempo");
                IniciarLLenadoDropDownList();
            }

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            wfPagPrincipal pag = new wfPagPrincipal();
            pag.Show();
            this.Hide();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Ruta = "";
            String rutaObtenida = ObtenerRuta();
            CargarArchivo(rutaObtenida);
        }

        public String ObtenerRuta()
        {
            if (OFD.ShowDialog() == DialogResult.OK)
            {
                Ruta = OFD.FileName;

            }
            return Ruta;
        }

        public void CargarArchivo(String rutaArchivo)
        {
            XDocument documento = XDocument.Load(rutaArchivo);
            Console.WriteLine(documento.ToString());
            var Tiendas = from usu in documento.Descendants("productos") select usu;
            int contador = 0;
            foreach (XElement u in Tiendas.Elements("producto"))
            {
                contador++;
                try
                {
                    if (u.Element("id").Value != "" && u.Element("tienda").Value != "" && u.Element("vencimiento").Value != ""  && u.Element("categoria").Value != "" && u.Element("existencias").Value != "" && u.Element("marca").Value != "" && u.Element("precio").Value != "" && u.Element("tamanio").Value != "")
                    {
                        Console.WriteLine(u.Element("id").Value); 
                        Console.WriteLine(u.Element("categoria").Value);
                        Console.WriteLine(u.Element("existencias").Value);
                        Console.WriteLine(u.Element("marca").Value);
                        Console.WriteLine(u.Element("precio").Value);
                        Console.WriteLine(u.Element("tamanio").Value);
                        Console.WriteLine(u.Element("vencimiento").Value);
                        Console.WriteLine(u.Element("tienda").Value);
                        SqlCommand comando = new SqlCommand();
                        comando.Connection = conexion;
                        comando.CommandText = "insert into Producto values (@Cat, @Cantindad, @Marca, @Precio, @FechaVec, @Tamano,@idTienda);";
                        comando.Parameters.AddWithValue("@Cat", u.Element("categoria").Value);
                        comando.Parameters.AddWithValue("@Cantindad", Convert.ToInt32(u.Element("existencias").Value));
                        comando.Parameters.AddWithValue("@Marca", u.Element("marca").Value);
                        comando.Parameters.AddWithValue("@Precio",Convert.ToSingle( u.Element("precio").Value));
                        comando.Parameters.AddWithValue("@FechaVec", Convert.ToDateTime(u.Element("vencimiento").Value));
                        comando.Parameters.AddWithValue("@Tamano",Convert.ToInt32( u.Element("tamanio").Value));
                        comando.Parameters.AddWithValue("@idTienda", Convert.ToByte(u.Element("tienda").Value));
                        Console.ReadLine();
                        try
                        {
                            comando.ExecuteNonQuery();
                            comando.Parameters.Clear();
                            IniciarLLenadoDropDownList();
                            Listar2();
                            MessageBox.Show("Se ha subido con éxito a la base de Datos");
                        }
                        catch (SqlException ex)
                        {
                            this.error = ex.Message;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Se omitirá el elemento; " + contador + " de la lista debido a que no se cumplen con todos los atributos del Producto");
                        return;
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Revise que todos los datos para Producto esten ingresados en el archivo xml");
                }
            }

            
        }
    }
}
