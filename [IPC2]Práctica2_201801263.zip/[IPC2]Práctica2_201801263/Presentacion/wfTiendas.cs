﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Xml.Linq;

namespace _IPC2_Práctica2_201801263
{
    public partial class wfTiendas : Form
    {
        OpenFileDialog OFD;
        String Ruta = "";
        String Texto = "";
        SaveFileDialog save;
        GD_Tienda Tienda = new GD_Tienda();
        public SqlConnection conexion;
        public string error;
        public wfTiendas()
        {
            InitializeComponent();
            btnEditar.Enabled = false;
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
            IniciarLLenadoDropDownList();
            OFD = new OpenFileDialog();
            OFD.RestoreDirectory = true;
            OFD.InitialDirectory = "E:\\";
            OFD.FilterIndex = 1;
            OFD.Filter = "xml files(*.xml)|*.xml";
        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Tienda objeto = Tienda.consultar(identificacion);
                if (objeto != null)
                {
                    txtUbicacion.Text = objeto.Ubicacion1;
                    txtDepa.Text = objeto.Departamento1;
                    txtMuni.Text = objeto.Municipio1;
                    txtTel.Text = objeto.Telefono1;
                    DDLencargado.Text = objeto.Encargado1;
                    MessageBox.Show("Tienda consultada");
                    btnEditar.Enabled = true;
                }
                else
                {
                    MessageBox.Show("No hay Tiendas agregadas a la base de datos");
                }
            }
            catch (Exception) { MessageBox.Show("Favor seleccionar la identificación de la Tienda a buscar"); }
        }

        //Metodo para listaClientes
        public void Listar(string Consulta, string Dato)
        {
            List<Tienda> Lista = Tienda.Listar(Consulta, Dato);
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Tiendas agregadas en la base de datos con este Dato: " + Dato);
            }
            else
            {
                gvTienda.DataSource = Lista;

            }
        }

        public void Listar2()
        {
            List<Tienda> Lista = Tienda.Listar2();
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Tiendas agregadas en la base de datos");
            }
            else
            {
                gvTienda.DataSource = Lista;

            }
        }
        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnListar_Click(object sender, EventArgs e)
        {
            if ((DDLdepa.SelectedIndex == -1 || DDLdepa.SelectedIndex == 0) && (DDLidMuni.SelectedIndex != 0 && DDLidMuni.SelectedIndex != -1))
            {
                Listar("select* from Tienda where Municipio=@Dato", DDLidMuni.Text);
                MessageBox.Show("Se ha listado por Municipio");
            }
            else if ((DDLdepa.SelectedIndex != 0 && DDLdepa.SelectedIndex != -1) && (DDLidMuni.SelectedIndex == -1 || DDLidMuni.SelectedIndex == 0))
            {
                Listar("select* from Tienda where Departamento=@Dato", DDLdepa.Text);
                MessageBox.Show("Se ha listado por Departamento");
            }
            else if ((DDLdepa.SelectedIndex == 0 && DDLidMuni.SelectedIndex == 0) || (DDLdepa.SelectedIndex == -1 && DDLidMuni.SelectedIndex == -1) || (DDLdepa.SelectedIndex == 0 && DDLidMuni.SelectedIndex == -1) || (DDLdepa.SelectedIndex == -1 && DDLidMuni.SelectedIndex == 0))
            {
                MessageBox.Show("Favor seleccionar el tipo de búsqueda por Departamento o Municipio");
            }
            else if ((DDLdepa.SelectedIndex != 0 && DDLidMuni.SelectedIndex != 0) || (DDLdepa.SelectedIndex != -1 && DDLidMuni.SelectedIndex != -1)) {
                MessageBox.Show("Favor seleccionar un tipo de búsqueda a la vez. Elija un Departamento o un Municipio, no los dos al mismo tiempo");
            }
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                MessageBox.Show("Favor consulte la Tienda a Editar");
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string Ubicacion = txtUbicacion.Text;
                    string Depa = txtDepa.Text;
                    string Muni = txtMuni.Text;
                    string Tel = txtTel.Text;
                    string Encargado = DDLencargado.Text;

                    Tienda.editar(identificacion, Ubicacion, Depa, Muni, Tel, Encargado);
                    Listar2();
                    IniciarLLenadoDropDownList();
                    limpiar();
                    MessageBox.Show("La Tienda "+ identificacion+ " ha sido Editada");
                }
                catch (Exception ex) { MessageBox.Show(" " + ex); }
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtUbicacion.Text = "";
            txtTel.Text = "";
            txtMuni.Text = "";
            txtDepa.Text = "";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            LimpiarComboBox();
            LlenarDDLidentificacion();
            LlenarDDLMuni();
            LlenarDDLDepa();
            LlenarEncargado();
        }

        public void LimpiarComboBox() {
            DDLidentificacion.DataSource = null;
            DDLidentificacion.Items.Clear();

            DDLencargado.DataSource = null;
            DDLencargado.Items.Clear();

            DDLdepa.DataSource = null;
            DDLdepa.Items.Clear();

            DDLidMuni.DataSource = null;
            DDLidMuni.Items.Clear();
        }
        public void LlenarDDLidentificacion() {
            DDLidentificacion.Items.Insert(0, "[Seleccionar identificación]");
            SqlCommand SC = new SqlCommand("select idTienda from Tienda");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read()) {
                DDLidentificacion.Items.Add(dr[0]);
            }
            dr.Close();
        }
        public void LlenarDDLMuni()
        {
            DDLidMuni.Items.Insert(0,"[Seleccionar Municipio]");
            SqlCommand SC = new SqlCommand("select Municipio from Tienda");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLidMuni.Items.Add(dr[0]);
            }
            dr.Close();
        }

        public void LlenarDDLDepa()
        {
            DDLdepa.Items.Insert(0, "[Seleccionar Departamento]");
            SqlCommand SC = new SqlCommand("select Departamento from Tienda");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLdepa.Items.Add(dr[0]);
            }
            dr.Close();
        }
        public void LlenarEncargado()
        {
            DDLencargado.Items.Insert(0, "[Seleccionar Empleado]");
            SqlCommand SC = new SqlCommand("select Nombre from Empleado");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLencargado.Items.Add(dr[0]);
            }
            dr.Close();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            wfPagPrincipal pag = new wfPagPrincipal();
            pag.Show();
            this.Hide();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Ruta = "";
            String rutaObtenida = ObtenerRuta();
            CargarArchivo(rutaObtenida);
        }
        public String ObtenerRuta()
        {
            if (OFD.ShowDialog() == DialogResult.OK)
            {
                Ruta = OFD.FileName;

            }
            return Ruta;
        }

        public void CargarArchivo(String rutaArchivo) {
            XDocument documento = XDocument.Load(rutaArchivo);
            Console.WriteLine(documento.ToString());
            var Tiendas = from usu in documento.Descendants("tiendas") select usu;
            int contador = 0;
            foreach (XElement u in Tiendas.Elements("tienda")) {
                contador++;
                try
                {
                    if (u.Element("id").Value != "" && u.Element("municipio").Value != "" && u.Element("departamento").Value != "" && u.Element("ubicacion").Value != "" && u.Element("encargado").Value != "" && u.Element("telefono").Value != "")
                    {
                        Console.WriteLine(u.Element("id").Value);
                        Console.WriteLine(u.Element("municipio").Value);
                        Console.WriteLine(u.Element("departamento").Value);
                        Console.WriteLine(u.Element("ubicacion").Value);
                        Console.WriteLine(u.Element("encargado").Value);
                        Console.WriteLine(u.Element("telefono").Value);
                        SqlCommand comando = new SqlCommand();
                        comando.Connection = conexion;
                        comando.CommandText = "insert into Tienda values (@Ubicacion, @Departamento, @Municipio, @Telefono, @Encargado);";
                        comando.Parameters.AddWithValue("@Ubicacion", u.Element("ubicacion").Value);
                        comando.Parameters.AddWithValue("@Departamento", u.Element("departamento").Value);
                        comando.Parameters.AddWithValue("@Municipio", u.Element("municipio").Value);
                        comando.Parameters.AddWithValue("@Telefono", u.Element("telefono").Value);
                        comando.Parameters.AddWithValue("@Encargado", u.Element("encargado").Value);
                        try
                        {
                            comando.ExecuteNonQuery();
                            comando.Parameters.Clear();
                            IniciarLLenadoDropDownList();
                            Listar2();
                            MessageBox.Show("Se ha subido con éxito a la base de Datos");
                        }
                        catch (SqlException ex)
                        {
                            this.error = ex.Message;
                        }                    
                    }
                    else {
                        MessageBox.Show("Se omitirá el elemento; "+contador+" de la lista debido a que no se cumplen con todos los atributos de Tienda");
                        return;
                    }
                    
                }
                catch(Exception ex){
                    MessageBox.Show("Revise que todos los datos para Tienda esten ingresados en el archivo xml");
                }
            }

            Console.ReadLine();
        }

        private void WfTiendas_Load(object sender, EventArgs e)
        {

        }

        private void BtnAgregar_Click_1(object sender, EventArgs e)
        {
            try
            {
                Tienda Objeto = new Tienda();
                Objeto.Ubicacion1 = txtUbicacion.Text;
                Objeto.Municipio1 = txtMuni.Text;
                Objeto.Departamento1 = txtDepa.Text;
                Objeto.Telefono1 = txtTel.Text;
                Objeto.Encargado1 = DDLencargado.Text;

                if (txtUbicacion.Text != null && txtTel.Text != null && txtMuni.Text != null && txtDepa.Text != null && DDLencargado.SelectedIndex!=0)
                {
                    bool agregado = Tienda.agregar(Objeto);
                    if (agregado)
                    {
                        MessageBox.Show("Tienda agregada Exitosamente");
                        limpiar();
                        Listar2();
                        IniciarLLenadoDropDownList();

                    }
                    else
                    {
                        MessageBox.Show(Tienda.error);
                    }
                }
                else
                {
                    MessageBox.Show("Favor Llenar todos los datos");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "Favor Llenar todos los datos");
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Tienda.eliminar(identificacion);
                    MessageBox.Show("Tienda Eliminado exitosamente");
                    Listar2();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    MessageBox.Show("Favor ingresar identificación de la Tienda a eliminar");
                }

            }
            catch (Exception) { MessageBox.Show("Favor ingresar identificación de la Tienda a eliminar"); }
        }
    }
}