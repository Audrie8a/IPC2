﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Xml.Linq;

namespace _IPC2_Práctica2_201801263
{
    public partial class wfEmpleado : Form
    {
        GD_Empleado Empleado= new GD_Empleado();
        public SqlConnection conexion;
        public string error;
        OpenFileDialog OFD;
        String Ruta = "";
        String Texto = "";
        SaveFileDialog save;
        public wfEmpleado()
        {
            InitializeComponent();
            btnEditar.Enabled = false;
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
            IniciarLLenadoDropDownList();
            OFD = new OpenFileDialog();
            OFD.RestoreDirectory = true;
            OFD.InitialDirectory = "E:\\";
            OFD.FilterIndex = 1;
            OFD.Filter = "xml files(*.xml)|*.xml";
        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void TxtUbicacion_TextChanged(object sender, EventArgs e)
        {

        }

        private void WfEmpleado_Load(object sender, EventArgs e)
        {

        }

        private void BtnConsultar_Click(object sender, EventArgs e)
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Empleado objeto = Empleado.consultar(identificacion);
                if (objeto != null)
                {
                    txtCUI.Text = Convert.ToString(objeto.Cui1);
                    txtNombre.Text = objeto.Nombre1;
                    txtApellido.Text = objeto.Apellido1;
                    txtTelefono.Text = objeto.Telefono1;
                    txtPuesto.Text = objeto.Puesto1;
                    DTPfechaIni.Value= objeto.FechaIniLab;
                    DTPfechaFin.Value = objeto.FechaFinLab;
                    DTPhoraIni.Value = Convert.ToDateTime(objeto.HoraIni1);
                    DTPhoraFin.Value = Convert.ToDateTime(objeto.HoraFin1);
                    DDLtiendaRef.Text = Convert.ToString(objeto.IdTiendaRef);
                    DDLJefe.Text = objeto.NombreJefe1;
                    txtContrasena.Text = objeto.Contrasena1;
                    MessageBox.Show("Empleado consultada");
                    btnEditar.Enabled = true;
                }
                else
                {
                    MessageBox.Show("No hay Empleados agregados a la base de datos");
                }
            }
            catch (Exception) { MessageBox.Show("Favor seleccionar la identificación del Empleado a buscar"); }
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                MessageBox.Show("Favor consulte el Empleado a Editar");
            }
            else
            {
                try
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);
                    int CUI = Convert.ToInt32(txtCUI.Text);
                    string Nombre = txtNombre.Text;
                    string Apellido = txtApellido.Text;
                    string Tel = txtTelefono.Text;
                    string Puesto = txtPuesto.Text;
                    DateTime fechaIni = DTPfechaIni.Value.Date;
                    DateTime fechaFin = DTPfechaFin.Value.Date;
                    string horaIni = Convert.ToString(DTPhoraIni.Value);
                    string horaFin = Convert.ToString(DTPhoraFin.Value);
                    byte idTiendaRefe = Convert.ToByte(DDLtiendaRef.Text);
                    string Jefe = DDLJefe.Text;
                    string Contrasena = txtContrasena.Text;
                                       
                    Empleado.editar(identificacion, CUI, Nombre, Apellido, Tel, Puesto, fechaIni, fechaFin, horaIni, horaFin, idTiendaRefe, Jefe, Contrasena);
                    Listar2();
                    IniciarLLenadoDropDownList();
                    limpiar();
                    MessageBox.Show("El Empleado " + identificacion + " ha sido Editado");
                }
                catch (Exception ex) { MessageBox.Show(" " + ex); }
            }
        }

        //Metodo para listaClientes
        public void Listar(string Consulta, string Dato)
        {
            List<Empleado> Lista = Empleado.Listar(Consulta, Dato);
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Tiendas agregadas en la base de datos en: " + Dato);
            }
            else
            {
                gvEmpleado.DataSource = Lista;

            }
        }

        public void Listar2()
        {
            List<Empleado> Lista = Empleado.Listar2();
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Empleados agregadas en la base de datos");
            }
            else
            {
                gvEmpleado.DataSource = Lista;

            }
        }

        public void Listar3(String Consulta, byte Dato)
        {
            List<Empleado> Lista = Empleado.Listar3(Consulta, Dato);
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Empleados agregadas en la base de datos En esta tienda: " + Dato);
            }
            else
            {
                gvEmpleado.DataSource = Lista;

            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtCUI.Text = "";
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtContrasena.Text = "";
            txtPuesto.Text = "";
            txtTelefono.Text = "";
            
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            LimpiarComboBox();
            LlenarDDLidentificacion();
            LlenarDDLMuni();
            LlenarDDLDepa();
            LlenarEncargado();
            LlenarDDLTienda();
        }

        public void LimpiarComboBox()
        {
            DDLidentificacion.DataSource = null;
            DDLidentificacion.Items.Clear();

            DDLtienda.DataSource = null;
            DDLtienda.Items.Clear();

            DDLdepa.DataSource = null;
            DDLdepa.Items.Clear();

            DDLidMuni.DataSource = null;
            DDLidMuni.Items.Clear();

            DDLtiendaRef.DataSource = null;
            DDLtiendaRef.Items.Clear();

            DDLJefe.DataSource = null;
            DDLJefe.Items.Clear();
        }
        public void LlenarDDLidentificacion() {
            DDLidentificacion.Items.Insert(0, "[Seleccionar Empleado]");
            SqlCommand SC = new SqlCommand("select CUI from Empleado");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLidentificacion.Items.Add(dr[0]);
            }
            dr.Close();
        }
        public void LlenarDDLTienda()
        {
            DDLtienda.Items.Insert(0, "[Seleccionar Tienda]");
            DDLtiendaRef.Items.Insert(0, "[Seleccionar Tienda]");
            SqlCommand SC = new SqlCommand("select idTienda from Tienda");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLtienda.Items.Add(dr[0]);
                DDLtiendaRef.Items.Add(dr[0]);
            }
            dr.Close();
        }
        public void LlenarDDLMuni()
        {
            DDLidMuni.Items.Insert(0, "[Seleccionar Municipio]");
            SqlCommand SC = new SqlCommand("select Municipio from Tienda");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLidMuni.Items.Add(dr[0]);
            }
            dr.Close();
        }

        public void LlenarDDLDepa()
        {
            DDLdepa.Items.Insert(0, "[Seleccionar Departamento]");
            SqlCommand SC = new SqlCommand("select Departamento from Tienda");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLdepa.Items.Add(dr[0]);
            }
            dr.Close();
        }
        public void LlenarEncargado()
        {
            DDLJefe.Items.Insert(0, "[Seleccionar Empleado]");
            SqlCommand SC = new SqlCommand("select Nombre from Empleado");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLJefe.Items.Add(dr[0]);
            }
            dr.Close();
        }

        private void BtnListar_Click(object sender, EventArgs e)
        {
            if ((DDLdepa.SelectedIndex == -1 || DDLdepa.SelectedIndex == 0) && (DDLtienda.SelectedIndex == -1 || DDLtienda.SelectedIndex == 0) && (DDLidMuni.SelectedIndex != 0 && DDLidMuni.SelectedIndex != -1))
            {
                Listar("select E.CUI, E.Nombre, E.Apellido, E.Telefono, E.Puesto, E.FechaIniLabores, E.FechaFinLabores, E.HoraIni, E.HoraFin, E.idTiendaReferente, E.NombreJefe, E.Contrasena from Empleado as E, Tienda as T where E.idTiendaReferente=T.idTienda and T.Municipio=@Dato", DDLidMuni.Text);
                MessageBox.Show("Se ha listado por Municipio");
                IniciarLLenadoDropDownList();
            }
            else if ((DDLdepa.SelectedIndex != 0 && DDLdepa.SelectedIndex != -1) && (DDLidMuni.SelectedIndex == -1 || DDLidMuni.SelectedIndex == 0) && (DDLtienda.SelectedIndex == -1 || DDLtienda.SelectedIndex == 0))
            {
                Listar("select E.CUI, E.Nombre, E.Apellido, E.Telefono, E.Puesto, E.FechaIniLabores, E.FechaFinLabores, E.HoraIni, E.HoraFin, E.idTiendaReferente, E.NombreJefe, E.Contrasena from Empleado as E, Tienda as T where E.idTiendaReferente=T.idTienda and  T.Departamento=@Dato", DDLdepa.Text);
                MessageBox.Show("Se ha listado por Departamento");
                IniciarLLenadoDropDownList();
            }
            else if ((DDLtienda.SelectedIndex != 0 && DDLtienda.SelectedIndex != -1) && (DDLidMuni.SelectedIndex == -1 || DDLidMuni.SelectedIndex == 0) && (DDLdepa.SelectedIndex == -1 || DDLdepa.SelectedIndex == 0))
            {
                Listar3("select* from Empleado where idTiendaReferente=@Dato", Convert.ToByte(DDLtienda.Text));
                MessageBox.Show("Se ha listado por Tienda");
                IniciarLLenadoDropDownList();
            }
            else if ((DDLdepa.SelectedIndex == 0 && DDLidMuni.SelectedIndex == 0 && DDLtienda.SelectedIndex==0) || (DDLdepa.SelectedIndex == -1 && DDLidMuni.SelectedIndex == -1 && DDLtienda.SelectedIndex==-1) ||
                (DDLdepa.SelectedIndex == 0 && DDLidMuni.SelectedIndex == 0 && DDLtienda.SelectedIndex == -1) || (DDLdepa.SelectedIndex == 0 && DDLidMuni.SelectedIndex == -1 && DDLtienda.SelectedIndex == 0)
                || (DDLdepa.SelectedIndex == 0 && DDLidMuni.SelectedIndex == -1 && DDLtienda.SelectedIndex==-1) || (DDLdepa.SelectedIndex == -1 && DDLidMuni.SelectedIndex == -1 && DDLtienda.SelectedIndex == 0)
                || (DDLdepa.SelectedIndex == -1 && DDLidMuni.SelectedIndex == 0 && DDLtienda.SelectedIndex == -1) || (DDLdepa.SelectedIndex == -1 && DDLidMuni.SelectedIndex == 0 && DDLtienda.SelectedIndex == 0) )
            {
                MessageBox.Show("Favor seleccionar el tipo de búsqueda por Departamento o Municipio");
                IniciarLLenadoDropDownList();
            }
            else if ((DDLdepa.SelectedIndex != 0 && DDLidMuni.SelectedIndex != 0 && DDLtienda.SelectedIndex!=0) || (DDLdepa.SelectedIndex != -1 && DDLidMuni.SelectedIndex != -1 && DDLtienda.SelectedIndex !=-1))
            {
                MessageBox.Show("Favor seleccionar un tipo de búsqueda a la vez. Elija un Departamento o un Municipio, no los dos al mismo tiempo");
                IniciarLLenadoDropDownList();
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Empleado.eliminar(identificacion);
                    MessageBox.Show("Empleado Eliminado exitosamente");
                    Listar2();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    MessageBox.Show("Favor ingresar identificación del Empleado a eliminar");
                }

            }
            catch (Exception) { MessageBox.Show("Favor ingresar identificación del Empleado a eliminar"); }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            wfPagPrincipal pag = new wfPagPrincipal();
            pag.Show();
            this.Hide();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Ruta = "";
            String rutaObtenida = ObtenerRuta();
            CargarArchivo(rutaObtenida);
        }

        public String ObtenerRuta()
        {
            if (OFD.ShowDialog() == DialogResult.OK)
            {
                Ruta = OFD.FileName;

            }
            return Ruta;
        }

        public void CargarArchivo(String rutaArchivo)
        {
            XDocument documento = XDocument.Load(rutaArchivo);
            Console.WriteLine(documento.ToString());
            var Tiendas = from usu in documento.Descendants("empleados") select usu;
            int contador = 0;
            foreach (XElement u in Tiendas.Elements("empleado"))
            {
                contador++;
                try
                {
                    if (u.Element("CUI").Value != "" && u.Element("nombre").Value != "" && u.Element("apellido").Value != "" && u.Element("telefono").Value != "" && u.Element("puesto").Value != "" && u.Element("fechainicio").Value != "" && u.Element("fechafin").Value != "" && u.Element("HoraInicio").Value != "" && u.Element("HoraInicio").Value != "" && u.Element("password").Value != "" && u.Element("jefe").Value != "" && u.Element("tienda").Value != "" && u.Element("HoraFin").Value != "")
                    {
                        
                        SqlCommand comando = new SqlCommand();
                        comando.Connection = conexion;
                        comando.CommandText = "insert into Empleado values (@CUI, @Nombre, @Apellido, @Telefono, @Puesto, @FechaIniLab, @FechaFinLab, @HoraIni, @HoraFin, @idTiendaRef, @NombreJefe, @Contrasena);";
                        comando.Parameters.AddWithValue("@CUI", u.Element("CUI").Value);
                        comando.Parameters.AddWithValue("@Nombre", u.Element("nombre").Value);
                        comando.Parameters.AddWithValue("@Apellido", u.Element("apellido").Value);
                        comando.Parameters.AddWithValue("@Telefono", u.Element("telefono").Value);
                        comando.Parameters.AddWithValue("@Puesto", u.Element("puesto").Value);
                        comando.Parameters.AddWithValue("@FechaIniLab",Convert.ToDateTime( u.Element("fechainicio").Value));
                        comando.Parameters.AddWithValue("@FechaFinLab", Convert.ToDateTime(u.Element("fechafin").Value));
                        comando.Parameters.AddWithValue("@HoraIni", u.Element("HoraInicio").Value);
                        comando.Parameters.AddWithValue("@HoraFin", u.Element("HoraFin").Value);
                        comando.Parameters.AddWithValue("@idTiendaRef",Convert.ToByte( u.Element("tienda").Value));
                        comando.Parameters.AddWithValue("@NombreJefe", u.Element("jefe").Value);
                        comando.Parameters.AddWithValue("@Contrasena", u.Element("password").Value);
                        Console.ReadLine();
                        try
                        {
                            comando.ExecuteNonQuery();
                            comando.Parameters.Clear();
                            IniciarLLenadoDropDownList();
                            Listar2();
                            MessageBox.Show("Se ha subido con éxito a la base de Datos");
                        }
                        catch (SqlException ex)
                        {
                            this.error = ex.Message;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Se omitirá el elemento; " + contador + " de la lista debido a que no se cumplen con todos los atributos del Producto");
                        
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Revise que todos los datos para Producto esten ingresados en el archivo xml");
                }
            }


        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Empleado Objeto = new Empleado();
                Objeto.Cui1 =Convert.ToInt32( txtCUI.Text);
                Objeto.Nombre1 = txtNombre.Text;
                Objeto.Apellido1 = txtApellido.Text;
                Objeto.Telefono1 = txtTelefono.Text;
                Objeto.Puesto1 = txtPuesto.Text;
                Objeto.FechaIniLab = Convert.ToDateTime(DTPfechaIni.Value);
                Objeto.FechaFinLab = Convert.ToDateTime(DTPhoraFin.Value);
                Objeto.HoraIni1 = Convert.ToString(DTPhoraIni.Value);
                Objeto.HoraFin1 = Convert.ToString(DTPhoraFin.Value);
                Objeto.IdTiendaRef = Convert.ToByte(DDLtiendaRef.Text);
                Objeto.NombreJefe1 = DDLJefe.Text;
                Objeto.Contrasena1 = txtContrasena.Text;

                if (txtCUI.Text != null && txtApellido.Text != null && txtContrasena.Text != null && txtNombre.Text != null && txtPuesto.Text != null && txtTelefono.Text != null && DDLJefe.SelectedIndex !=0 && DDLtiendaRef.SelectedIndex != 0)
                {
                    bool agregado = Empleado.agregar(Objeto);
                    if (agregado)
                    {
                        MessageBox.Show("Empleado Agregado Exitosamente");
                        limpiar();
                        Listar2();
                        IniciarLLenadoDropDownList();

                    }
                    else
                    {
                        MessageBox.Show(Empleado.error);
                    }
                }
                else
                {
                    MessageBox.Show("Favor Llenar todos los datos");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "Favor Llenar todos los datos");
            }
        }
    }
}
