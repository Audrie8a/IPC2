﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _IPC2_Práctica2_201801263
{
    class Tienda
    {
        private byte idTienda;
        private string Ubicacion;
        private string Departamento;
        private string Municipio;
        private string Telefono;
        private string Encargado;

        public Tienda()
        {
        }

        public Tienda(byte idTienda, string ubicacion, string departamento, string municipio, string telefono, string encargado)
        {
            this.idTienda = idTienda;
            Ubicacion = ubicacion;
            Departamento = departamento;
            Municipio = municipio;
            Telefono = telefono;
            Encargado = encargado;
        }

        public byte IdTienda { get => idTienda; set => idTienda = value; }
        public string Ubicacion1 { get => Ubicacion; set => Ubicacion = value; }
        public string Departamento1 { get => Departamento; set => Departamento = value; }
        public string Municipio1 { get => Municipio; set => Municipio = value; }
        public string Telefono1 { get => Telefono; set => Telefono = value; }
        public string Encargado1 { get => Encargado; set => Encargado = value; }
    }
}
