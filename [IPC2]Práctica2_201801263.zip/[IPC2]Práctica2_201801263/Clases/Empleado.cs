﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _IPC2_Práctica2_201801263
{
    class Empleado
    {
        private int Cui;
        private string Nombre;
        private string Apellido;
        private string Telefono;
        private string Puesto;
        private DateTime fechaIniLab;
        private DateTime fechaFinLab;
        private string HoraIni;
        private string HoraFin;
        private byte idTiendaRef;
        private string NombreJefe;
        private string Contrasena;

        public Empleado()
        {
        }

        public Empleado(int cui, string nombre, string apellido, string telefono, string puesto, DateTime fechaIniLab, DateTime fechaFinLab, string horaIni, string horaFin, byte idTiendaRef, string nombreJefe, string contrasena)
        {
            Cui = cui;
            Nombre = nombre;
            Apellido = apellido;
            Telefono = telefono;
            Puesto = puesto;
            this.fechaIniLab = fechaIniLab;
            this.fechaFinLab = fechaFinLab;
            HoraIni = horaIni;
            HoraFin = horaFin;
            this.idTiendaRef = idTiendaRef;
            NombreJefe = nombreJefe;
            Contrasena = contrasena;
        }

        public int Cui1 { get => Cui; set => Cui = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public string Apellido1 { get => Apellido; set => Apellido = value; }
        public string Telefono1 { get => Telefono; set => Telefono = value; }
        public string Puesto1 { get => Puesto; set => Puesto = value; }
        public DateTime FechaIniLab { get => fechaIniLab; set => fechaIniLab = value; }
        public DateTime FechaFinLab { get => fechaFinLab; set => fechaFinLab = value; }
        public string HoraIni1 { get => HoraIni; set => HoraIni = value; }
        public string HoraFin1 { get => HoraFin; set => HoraFin = value; }
        public byte IdTiendaRef { get => idTiendaRef; set => idTiendaRef = value; }
        public string NombreJefe1 { get => NombreJefe; set => NombreJefe = value; }
        public string Contrasena1 { get => Contrasena; set => Contrasena = value; }
    }
}
