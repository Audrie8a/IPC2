﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _IPC2_Práctica2_201801263
{
    class Producto
    {
        private byte idProducto;
        private string Categoria;
        private int Cantidad;
        private string Marca;
        private float Precio;
        private DateTime FechaVencimiento;
        private int Tamano;
        private byte idTienda;

        public Producto()
        {
        }

        public Producto(byte idProducto, string categoria, int cantidad, string marca, float precio, DateTime fechaVencimiento, int tamano, byte idTienda)
        {
            this.idProducto = idProducto;
            Categoria = categoria;
            Cantidad = cantidad;
            Marca = marca;
            Precio = precio;
            FechaVencimiento = fechaVencimiento;
            Tamano = tamano;
            this.idTienda = idTienda;
        }

        public byte IdProducto { get => idProducto; set => idProducto = value; }
        public string Categoria1 { get => Categoria; set => Categoria = value; }
        public int Cantidad1 { get => Cantidad; set => Cantidad = value; }
        public string Marca1 { get => Marca; set => Marca = value; }
        public float Precio1 { get => Precio; set => Precio = value;  }
        public DateTime FechaVencimiento1 { get => FechaVencimiento; set => FechaVencimiento = value;  }
        public int Tamano1 { get => Tamano; set => Tamano = value; }
        public byte IdTienda { get => idTienda; set => idTienda = value; }
    }
}
