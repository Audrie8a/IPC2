﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace _IPC2_Práctica2_201801263
{
    class GD_Login
    {
        public SqlConnection conexion;
        public string error;

        public GD_Login()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        public Boolean validar_usuario(string usuario, string contra)
        {

            bool id = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select CUI, Contrasena from Empleado";
            SqlDataReader registro = comando.ExecuteReader();



            while (registro.Read())
            {
                int CUI = registro.GetInt32(0);
                string Contrasena = registro.GetString(1);
                if (CUI == Convert.ToInt32(usuario) && Contrasena == contra)

                {

                    id = true;
                }
            }
            registro.Close();
            return id;

        }
    }
}
