--CREATE
--Creando Base de Datos
create database RestaurantePractica1
use RestaurantePractica1

--Creando tablas
create table Cliente(
CUI int identity primary key,
Nombre varchar(50) not null,
Apellido varchar(50) not null,
NIT varchar (50),
idTipoCliente tinyint)

create table tipoCliente(
idTipoCliente tinyint identity primary key,
 TipoCliente varchar(100) not null
)

create table Telefono(
idTelefono tinyint identity primary key,
 idTipo_Telefono tinyint not null,
 numero_Telefono varchar(100) not null
)

create table Telefono_Cliente(
idTelefono_Cliente  tinyint identity primary key,
CUI int,
idTelefono tinyint
)

create table Tipo_Reserva(
idTipo_Reserva  tinyint identity primary key,
 TipoReserva varchar(100) not null
)

create table EstadoReserva(
idEstadoReserva  tinyint identity primary key,
 EstadoReserva varchar(100) not null
)

Create table Reserva(
idReservacion  tinyint identity Primary key,
Hora time not null,
Fecha date not null,
idTipo_Reserva tinyint not null,
CUI int not null,
idUbicacion tinyint not null,
idEstadoReserva tinyint not null
)

Create table Mesa(
idMesa  tinyint identity primary key,
Cupo int not null,
idReservacion tinyint
)

Create table Proveedor(
idProveedor  tinyint identity primary key,
Nombre varchar(100) not null,
Telefono varchar (100) not null, 
Direccion varchar (100) not null,
EncargadoVenta varchar (100) not null,
idHistorial tinyint
)

create table Historial (
idHistorial  tinyint identity primary key
)

Create table EstadoOrden(
idEstadoOrden tinyint identity primary key,
EstadoOrden varchar(100) not null
)

create Table Orden (
idOrden  tinyint identity primary key,
Fecha date not null,
idChef_Encargado tinyint not null,
idEstadoOrden tinyint not null,
idHistorial tinyint not null
)

create table Ingrediente(
idIngrediente  tinyint identity primary key,
Nombre varchar(100) not null,
cantidad int not null,
idOrden tinyint not null,
idReceta tinyint not null
)

create table Receta(
idReceta  tinyint identity primary key,
Receta varchar(5000) not null
)

create table Empleado(
 idEmpleado  tinyint identity primary key,
 Nombre varchar(100) not null,
 Apellido varchar(100) not null,
 Telefono varchar(100) not null,
 Direccion varchar (500) not null,
 CUI varchar(100) not null,
 idPuesto tinyint not null,
 idAreaTrabajo tinyint not null
 )

 create table Puesto(
idPuesto  tinyint identity primary key,
Puesto varchar(50) not null
)

Create table AreaTrabajo(
idAreaTrabajo  tinyint identity primary key,
AreaTrabajo Varchar(50) not null
)

create table Platillo(
idPlatillo  tinyint identity primary key,
Nacionalidad varchar(50) not null,
Nombre varchar(50) not null,
idReceta tinyint not null,
idMenu tinyint not null
)

create table Menu(
idMenu  tinyint identity primary key,
idTipo_Menu tinyint not null
)

create table tipo_Menu(
idTipo_Menu  tinyint identity primary key,
Tipo_Menu varchar(50) not null
)

create table Empleado_Platillo(
idEmpleado_Platillo  tinyint identity primary key,
idPlatillo tinyint not null,
idEmpleado tinyint not null
)

create table Facturacion(
idFacturacion  tinyint identity primary key,
idReservacion tinyint not null,
idMenu tinyint not null,
CUI int not null
)

create table Adicional(
idAdicional  tinyint identity primary key,
DescripcionAdicion varchar (1000) not null,
idPlatillo tinyint
)

Create table Tipo_Telefono (
idTipo_Telefono tinyint identity primary key ,
TipoTelefono varchar(100) not null
)

Create table Ubicacion(
idUbicacion tinyint identity primary key,
Ubicacion varchar(50) not null
)

--ALTER
--Agregando foreign key

Alter table Cliente add constraint fk_TipoCliente Foreign key (idTipoCliente) references TipoCliente(idTipoCliente)

Alter Table Telefono add constraint fk_TipoTelefono foreign key (idTipo_Telefono) references Tipo_Telefono (idTipo_Telefono)

Alter table Telefono_Cliente add constraint fk_ClienteTelefono foreign key (CUI) references Cliente(CUI)
Alter table Telefono_Cliente add constraint fk_TelefonoCliente foreign key (idTelefono) references Telefono(idTelefono)

Alter table Reserva add constraint fk_UbicacionReserva foreign key (idUbicacion) references Ubicacion(idUbicacion)
Alter table Reserva add constraint fk_EstadoReserva foreign key (idEstadoReserva) references EstadoReserva(idEstadoReserva)
Alter table Reserva add constraint fk_TipoReserva foreign key (idTipo_Reserva) references Tipo_Reserva(idTipo_Reserva)
Alter table Reserva add constraint fk_ClienteReserva foreign key (CUI) references Cliente(CUI)

Alter table Mesa add constraint fk_Mesa foreign key (idReservacion) references Reserva(idReservacion)

Alter Table Proveedor add constraint fk_Historial foreign key (idHistorial) references Historial(idHistorial)

Alter Table Orden add constraint fk_HistorialOrden foreign key (idHistorial) references Historial(idHistorial)
Alter Table Orden add constraint fk_EstadoOrden foreign key (idEstadoOrden) references EstadoOrden(idEstadoOrden)
Alter Table Orden add constraint fk_EmpleadoOrden foreign key (idChef_Encargado) references Empleado(idEmpleado)

Alter table Ingrediente add constraint fk_OrdenIngrediente foreign key (idOrden) references Orden (idOrden)
Alter table Ingrediente add constraint fk_RecetaIngrediente foreign key (idReceta) references Receta(idReceta)

Alter table Empleado add constraint fk_Puesto foreign key (idPuesto) references Puesto(idPuesto)
Alter table Empleado add constraint fk_AreaTrabajo foreign key (idAreaTrabajo) references AreaTrabajo(idAreaTrabajo)

Alter table Platillo add constraint fk_RecetaPlatillo foreign key (idReceta) references Receta(idReceta)
Alter table Platillo add constraint fk_Menu foreign key (idMenu) references Menu(idMenu)

alter table Menu add constraint fk_TipoMenu foreign key (idTipo_Menu) references tipo_Menu(idTipo_Menu)

Alter table Empleado_Platillo add constraint fk_PlatilloEmpleado foreign key (idPlatillo) references Platillo (idPlatillo)
Alter table Empleado_Platillo add constraint fk_EmpleadoPlatillo foreign key (idEmpleado) references Empleado(idEmpleado)

Alter table Facturacion add constraint fk_ReservaMenu foreign key (idReservacion) references Reserva (idReservacion)
Alter table Facturacion add constraint fk_MenuFacturacion foreign key (idMenu) references Menu (idMenu)
Alter table Facturacion add constraint fk_ClienteFacturacion foreign key (CUI) references Cliente (CUI)

Alter table Adicional add constraint fk_PlatilloAdicional foreign key (idPlatillo) references Platillo(idPlatillo)