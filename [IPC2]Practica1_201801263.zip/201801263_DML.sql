	INSERT INTO AreaTrabajo values('Central de Mando');
INSERT INTO AreaTrabajo values('Cocina Artesanal');
INSERT INTO AreaTrabajo values('Cocina');
INSERT INTO AreaTrabajo values('Limpieza');
INSERT INTO Puesto values('Chef de Cuisine');
INSERT INTO Puesto values('Asistente Chef');
INSERT INTO Puesto values('Chef de Prtie');
INSERT INTO Puesto values('Primer Cocinero');
INSERT INTO Puesto values('Segundo Chef');
INSERT INTO Puesto values('Tercer Cher');
INSERT INTO Puesto values('Aisistente de Chef');
INSERT INTO tipo_Menu values('Especial');
INSERT INTO tipo_Menu values('Normal');
INSERT INTO Menu values (2);
INSERT INTO Menu values (1);
INSERT INTO Ubicacion values ('Salon 1');
INSERT INTO Ubicacion values ('Salon 2');
INSERT INTO Tipo_Reserva values ('Especial');
INSERT INTO Tipo_Reserva values ('Normal');
INSERT INTO EstadoOrden values ('Entregado');
INSERT INTO EstadoOrden values ('Pendiente');
INSERT INTO EstadoOrden values ('Atrasado');
INSERT INTO EstadoOrden values ('No entregado');
Insert into Historial values (1,2);
Insert into Historial values (1,3);
Insert into Historial values (1,4);
Insert into Historial values (2,5);
INSERT INTO EstadoReserva values ('Pendiente');
INSERT INTO EstadoReserva values ('Atendida');
INSERT INTO EstadoReserva values ('Cancelada');
INSERT INTO tipoCliente values ('Normal');
INSERT INTO tipoCliente values ('Frecuente');
INSERT INTO Tipo_Telefono values ('Celular');
INSERT INTO Tipo_Telefono values ('Domiciliar');
INSERT INTO Telefono values (2,'66290071');
INSERT INTO Telefono values (1,'34050345');
INSERT INTO Cliente values (3012, 'Audrie Annelisse','del Cid Ochoa','', 1);
INSERT INTO Cliente values (3013, 'Amelia Odeth','Mindr�p Saes','715372-4', 2);
INSERT INTO Cliente values (3014, 'Cristopher Alejandro','Arias Cabrera','82930-7', 1);
INSERT INTO Telefono_Cliente values (3012,1);
INSERT INTO Telefono_Cliente values (3013,2);
INSERT INTO Telefono_Cliente values (3014,1);
INSERT INTO Reserva values ('17:00','08-04-2020',1,3012,1,1);
INSERT INTO Reserva values ('19:00','09-03-2020',2,3013,2,3);
INSERT INTO Reserva values ('17:00','08-02-2020',1,3014,2,2);
INSERT INTO Mesa values (12,1);
INSERT INTO Mesa values (4,4);
INSERT INTO Mesa values (4,4);
INSERT INTO Mesa values (4,4);
INSERT INTO Mesa values (3,4);
INSERT INTO Mesa values (2,4);
INSERT INTO Mesa values (12,4);
INSERT INTO Receta values ('Aguacate ensalsado');
INSERT INTO Receta values ('Jocon');
INSERT INTO Platillo values ('guatemalteco', 'Colorado',1,1,15);
INSERT INTO Platillo values ('argentino', 'Rojo vivo',2,2,25);
INSERT INTO Platillo values ('holandes', 'Stamppot',2,2,50);
INSERT INTO Platillo values ('holandes', 'Erwtensoep',2,2,100);
INSERT INTO Adicional values ('Salsa de Queso',10,1);
INSERT INTO Empleado values ('Jos�','D�az','66290072','3ra Av "A" 3-65 zona 13', '8392',1,1);
INSERT INTO Empleado values ('Jonas','Delck','7283937','11va Av "D" 8-39 zona 18', '8262',7,4);
INSERT INTO Empleado values ('Jared','Driup','372982082','10ma Av "A" 9-79 zona 15', '8932',6,3);
INSERT INTO Empleado values ('Jared','Dieguez','37298462','7ma Av "D" 3-39 zona 2', '8382',5,3);
INSERT INTO Empleado values ('Julio','Dominguez','37290562','4ta Av "B" 9-35 zona 12', '9222',4,3);
INSERT INTO Empleado values ('Juan','De Le�n','64590562','3ra Av "C" 2-95 zona 1', '7822',3,2);
INSERT INTO Empleado values ('Jessy','Duran','66290562','5tra Av "B" 2-55 zona 11', '7322',2,2);
INSERT INTO Empleado values ('Jos�','D�az','66290072','3ra Av "A" 3-65 zona 13', '8392',1,1);
INSERT INTO Empleado_Platillo values (1,1);
INSERT INTO Empleado_Platillo values (1,2);
INSERT INTO Empleado_Platillo values (1,3);
INSERT INTO Empleado_Platillo values (1,4);
INSERT INTO Empleado_Platillo values (3,3);
INSERT INTO Empleado_Platillo values (3,2);
INSERT INTO Empleado_Platillo values (3,1);
INSERT INTO Empleado_Platillo values (2,3);
INSERT INTO Empleado_Platillo values (2,2);
INSERT INTO Empleado_Platillo values (2,1);
INSERT INTO Orden values ('07/03/2020', 1,1);
INSERT INTO Orden values ('08/04/2020', 1,2);
INSERT INTO Orden values ('08/03/2020', 1,3);
INSERT INTO Orden values ('08/03/2020', 1,4);
INSERT INTO Proveedor values ('David Jimenez','82839082', '4ta Av "B" 2-45 zona 21', 'Jos� D�az');
INSERT INTO Proveedor values ('Julio Devara','88273082', '6ta Av "D" 6-75 zona 2', 'Jos� D�az');
INSERT INTO Ingrediente values ('Aguacate',30, 2, 1);
INSERT INTO Ingrediente values ('Tomate',100, 3, 1);
INSERT INTO Ingrediente values ('Cebolla',100, 4, 1);
INSERT INTO Ingrediente values ('Ajo',50, 5, 1);
INSERT INTO Ingrediente values ('Cebolla',100, 4, 2);
INSERT INTO Ingrediente values ('Cebolla',100, 4, 2);
INSERT INTO Facturacion values (1,1,3014);
INSERT INTO Facturacion values (4,1,3013);
INSERT INTO Facturacion values (1,1,3012);
INSERT INTO Facturacion values (5,2,3014);
INSERT INTO Facturacion values (5,2,3014);

--CONSULTA 1------------------------
Select *from Cliente
where idTipoCliente=2
--CONSULTA 2-------------------------
--Tabla con el numero de veces que se ha pedido un platillo
select count(idPlatillo) as VecesPedidas, idPlatillo into #TempT_ConteoPlatillosPedidos
From Facturacion
Group by idPlatillo
order by count(idPlatillo)DESC;
--Creando el top Platillos m�s vendidos
SELECT TOP 3 * into #TempT_Top3Platillo
  FROM #TempT_ConteoPlatillosPedidos 
 ORDER BY VecesPedidas DESC
--Agregando el nombre del platillo con un join
select P.Nombre, T.VecesPedidas into #TempT_Top3PlatillosMasVendidos  
  from Platillo as P
  join #TempT_Top3Platillo as T
  on P.idPlatillo =T.idPlatillo;
  --CONSULTA 3--------------------------------------------
  --Creando Tabla Temporal con el top 10 de ingredientes comprados en el �ltimo mes
SELECT *into #TempT_Top10INgredientes
FROM Orden 
WHERE Fecha LIKE '%-%-03' and  idEstadoOrden=1
--Creando un Join para unir el top 10 de ingredientes comprados con ingredientes y obtener la cantidad 
select Top 10 I.idIngrediente, I.Nombre, I.cantidad into #TempT_Top10INgredientesMasComprados
from Ingrediente as I
  join #TempT_Top10INgredientes as T
  on I.idOrden=T.idOrden
  ORDER BY I.cantidad DESC

--CONSULTA 4----------------------------------------------
--Creando Tabla temporal que guarda el id de la orden y el id del Proveedor que tengan ordenes no entregadas
select idOrden,idProveedor into #TempT_OrdenProveedor from Orden where idEstadoOrden= 4
--Creando tabla temporal con el conteo de las ordenes no entregadas por proveedor
select count(idOrden) as NoEntregadas, idProveedor into #TempT_ConteoOrdenesNoEntregadas
From #TempT_OrdenProveedor
Group by idProveedor
order by count(idOrden)DESC;
--Guardando el id del proveedor con m�s ordenes no entregadas
Declare @ProveedroMenosOrdenesentregadas int;
select @ProveedroMenosOrdenesentregadas= max(NoEntregadas) from #TempT_ConteoOrdenesNoEntregadas;
--Buscando nombre del proveedor
Select Nombre from Proveedor
where idProveedor = @ProveedroMenosOrdenesentregadas

--CONSULTA 5-----------------------------------------------
--Tabla con el numero de veces que el cliente ha comprado
select count(idPlatillo) as VecesComprando, CUI into #TempT_ConteoPlatillosComprados 
From Facturacion
Group by CUI
order by count(idPlatillo)DESC;
--Se crea la tabla 
CREATE TABLE #TempT_ComensalFrecuente (CUI int, Nombre varchar(100), Compras int)
--Guardando el total de compras m�s grande
Declare @CompradorFrecuente int, @MaxCompras int;
select @MaxCompras = max(VecesComprando) from #TempT_ConteoPlatillosComprados;
--Guardando el id del Cliente con m�s Compras realizadas
select @CompradorFrecuente = CUI FROM #TempT_ConteoPlatillosComprados where @MaxCompras=VecesComprando
--Guardando el nombre del comprador frecuente
Declare @NombreCliente varchar(100), @ApellidoCliente varchar(100), @Cliente varchar(100);
select @NombreCliente = Nombre  from Cliente where @CompradorFrecuente=CUI
select @ApellidoCliente = Apellido  from Cliente where @CompradorFrecuente=CUI
set @Cliente=@NombreCliente+' '+@ApellidoCliente
--se insertan los datos
insert into #TempT_ComensalFrecuente values (@CompradorFrecuente,@Cliente ,@MaxCompras)
--se Mira la tabla con el comensal con m�s compras en el restaurante
select *from #TempT_ComensalFrecuente

--CONSULTA 6-------------------------
--Creando una tabla de valores temporales de las reservaciones especiales
select idReservacion into #TempT_IdReservacionesEspeciales from Reserva where idTipo_Reserva=1;
--Creando un Join entre las Reservaciones Especiales y la facturaci�n con el id de los Clientes que reservaron
select F.CUI into #TempT_Reservadores
  from Facturacion as F
  join #TempT_IdReservacionesEspeciales as T
  on F.idReservacion=T.idReservacion;
--Viendo quien es el Cliente que m�s reservas especiales tiene
select count(CUI) as ReservasEspeciales, CUI into #TempT_ConteoReservasEspeciales
From #TempT_Reservadores
Group by CUI
order by count(CUI)DESC;
--Guardando el id del cliente con m�s reservas especiales
Declare @ClienteReservasEspeciales int, @CUIcliente int;
select @ClienteReservasEspeciales= max(ReservasEspeciales) from #TempT_ConteoReservasEspeciales;
Select @CUIcliente =  CUI from #TempT_ConteoReservasEspeciales
where ReservasEspeciales= @ClienteReservasEspeciales
--Buscando nombre del Cliente
Select Nombre from Cliente
where CUI = @CUIcliente


--CONSULTA 7---------------
-- Creamos una Tabla Temporal "CupoMesa"
  CREATE TABLE #CupoMesa (Tama�o varchar(50), Cantidad int)
--Declaraci�n y Asignaci�n de Variables
Declare @C2 int, @C3 int, @C4 int,@C5 int,@C6 int,@C7 int,@C8 int,@C9 int,@C10 int,@C11 int,@C12 int;
Select @C2 = count(*) from Mesa where Cupo='2';
Select @C3 = count(*) from Mesa where Cupo='3';
Select @C4 = count(*) from Mesa where Cupo='4';
Select @C5 = count(*) from Mesa where Cupo='5';
Select @C6 = count(*) from Mesa where Cupo='6';
Select @C7 = count(*) from Mesa where Cupo='7';
Select @C8 = count(*) from Mesa where Cupo='8';
Select @C9 = count(*) from Mesa where Cupo='9';
Select @C10 = count(*) from Mesa where Cupo='10';
Select @C11 = count(*) from Mesa where Cupo='11';
Select @C12 = count(*) from Mesa where Cupo='12';

--Insertamos los valores
INSERT INTO #CupoMesa VALUES ('Mesa de 2',@C2);
INSERT INTO #CupoMesa VALUES ('Mesa de 3',@C3);
INSERT INTO #CupoMesa VALUES ('Mesa de 4',@C4);
INSERT INTO #CupoMesa VALUES ('Mesa de 5',@C5);
INSERT INTO #CupoMesa VALUES ('Mesa de 6',@C6);
INSERT INTO #CupoMesa VALUES ('Mesa de 7',@C7);
INSERT INTO #CupoMesa VALUES ('Mesa de 8',@C8);
INSERT INTO #CupoMesa VALUES ('Mesa de 9',@C9);
INSERT INTO #CupoMesa VALUES ('Mesa de 10',@C10);
INSERT INTO #CupoMesa VALUES ('Mesa de 11',@C11);
INSERT INTO #CupoMesa VALUES ('Mesa de 12',@C12);
--Seleccionando la mesa m�s reservada por tama�o
Declare @VecesReservada int;
select @VecesReservada= max(Cantidad) from #CupoMesa;
select * from #CupoMesa where Cantidad=@VecesReservada; 

select * from #CupoMesa

--CONSULTA 8-----------------

--Creando Tabla Temporal para ventas por mes
SELECT *into #TempT_VentasPorMes
FROM Reserva 
WHERE Fecha LIKE '%-%-03'
--Creamos un join para unir Reserva y facturacion
select F.idPlatillo into #TempT_Reservadores
  from Facturacion as F
  join #TempT_VentasPorMes as T
  on F.idReservacion=T.idReservacion;

