﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace _IPC2_Pracitca3_201801263.zip
{
    class GD_FacturacionPedido
    {

        public SqlConnection conexion;
        public string error;

        public GD_FacturacionPedido()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(FacturacionPedido Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into FacturacionPlatillo values (@idFac, @idPed, @Precio, @Cantidad);";
            comando.Parameters.AddWithValue("@idFac", Dato.IdFacturacion);
            comando.Parameters.AddWithValue("@idPed", Dato.IdPlatillo);
            comando.Parameters.AddWithValue("@Precio", Dato.Precio1);
            comando.Parameters.AddWithValue("@Cantidad", Dato.Cantidad1);

            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public FacturacionPedido consultar(byte ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from FacturacionPlatillo where idFacturacionPlatillo=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                FacturacionPedido Dato = new FacturacionPedido();
                Dato.IdFacPedido = registro.GetByte(0);
                Dato.IdFacturacion= registro.GetByte(1);
                Dato.IdPlatillo = registro.GetByte(2);
                Dato.Precio1 = registro.GetInt32(3);
                Dato.Cantidad1 = registro.GetInt32(4);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(byte ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from FacturacionPlatillo where idFacturacionPlatillo=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<FacturacionPedido> Listar()
        {
            List<FacturacionPedido> Lista = new List<FacturacionPedido>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from FacturacionPlatillo";
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                FacturacionPedido Dato1 = new FacturacionPedido();
                Dato1.IdFacPedido = registro.GetByte(0);
                Dato1.IdFacturacion = registro.GetByte(1);
                Dato1.IdPlatillo = registro.GetByte(2);
                Dato1.Precio1 = registro.GetInt32(3);
                Dato1.Cantidad1 = registro.GetInt32(4);
                Lista.Add(Dato1);
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte idFacPlatillo, byte numFactura, byte idPlatillo, int Precio, int Cantidad)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update FacturacionPlatillo set idFacturacion= @If, idPlatillo=@Ip, Precio=@P, Cantidad=@C where idFacturacionPlatillo=@id";
            comando.Parameters.AddWithValue("@id", idFacPlatillo);
            comando.Parameters.AddWithValue("@If", numFactura);
            comando.Parameters.AddWithValue("@Ip", idPlatillo);
            comando.Parameters.AddWithValue("@P", Precio);
            comando.Parameters.AddWithValue("@C", Cantidad);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

    }
}
