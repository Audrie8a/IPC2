﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _IPC2_Pracitca3_201801263.zip
{
    class Consulta5
    {
        private DateTime fecha;
        private int Facturacion;

        public Consulta5()
        {
        }

        public Consulta5(DateTime fecha, int facturacion)
        {
            this.fecha = fecha;
            Facturacion = facturacion;
        }

        public DateTime Fecha { get => fecha; set => fecha = value; }
        public int Facturacion1 { get => Facturacion; set => Facturacion = value; }
    }
}
