﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Xml.Linq;

namespace _IPC2_Pracitca3_201801263.zip
{
    public partial class formPlatillosFactura : Form
    {
        GD_FacturacionPedido FacturacionPedido = new GD_FacturacionPedido();
        public SqlConnection conexion;
        public string error;
        public formPlatillosFactura()
        {
            InitializeComponent();
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
            IniciarLLenadoDropDownList();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            formFacturacion f = new formFacturacion();
            f.Show();
            this.Hide();
        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                FacturacionPedido Objeto = new FacturacionPedido();
                Objeto.IdPlatillo = Convert.ToByte(DDLplatillo.Text);
                Objeto.IdFacturacion = Convert.ToByte(DDLfactura2.Text); ;
                Objeto.Precio1 = Convert.ToInt32(txtPrecio.Text);
                Objeto.Cantidad1 = Convert.ToInt32(txtCantidad.Text);

                if (txtPrecio != null && txtCantidad != null )
                {
                    bool agregado = FacturacionPedido.agregar(Objeto);
                    if (agregado)
                    {
                        MessageBox.Show("Factura Agregado Exitosamente");
                        limpiar();
                        IniciarLLenadoDropDownList();

                    }
                    else
                    {
                        MessageBox.Show(FacturacionPedido.error);
                    }
                }
                else
                {
                    MessageBox.Show("Favor Llenar todos los datos");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "Favor Llenar todos los datos");
            }
        }

        private void BtnConsultar_Click(object sender, EventArgs e)
        {
            try
            {
                byte identificacion = Convert.ToByte(DDLidentificacion.Text);

                FacturacionPedido objeto = FacturacionPedido.consultar(identificacion);
                if (objeto != null)
                {

                    DDLplatillo.Text = Convert.ToString(objeto.IdPlatillo);
                    DDLfactura2.Text = Convert.ToString(objeto.IdFacturacion);
                    txtCantidad.Text= Convert.ToString(objeto.Cantidad1);
                    txtPrecio.Text = Convert.ToString(objeto.Precio1); ;
                    MessageBox.Show("Factura consultada");
                    btnEditar.Enabled = true;
                }
                else
                {
                    MessageBox.Show("No hay Facturas agregados a la base de datos");
                }
            }
            catch (Exception) { MessageBox.Show("Favor seleccionar la identificación del Factura a buscar"); }
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {

            if (DDLidentificacion.SelectedIndex == 0)
            {
                MessageBox.Show("Favor consulte el Empleado a Editar");
            }
            else
            {
                try
                {
                    byte idFactP = Convert.ToByte(DDLidentificacion.Text);
                    byte numFactura = Convert.ToByte(DDLfactura2.Text);
                    byte idPlatillo = Convert.ToByte(DDLplatillo.Text);
                    int Precio = Convert.ToInt32(txtPrecio.Text) ;
                    int Cantidad = Convert.ToInt32(txtCantidad.Text);

                    FacturacionPedido.editar(idFactP, numFactura, idPlatillo, Precio, Cantidad);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                    MessageBox.Show("La factura " + numFactura + " ha sido Editado");
                }
                catch (Exception ex) { MessageBox.Show(" " + ex); }
            }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);


                    FacturacionPedido.eliminar(identificacion);
                    MessageBox.Show("Empleado Eliminado exitosamente");
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    MessageBox.Show("Favor ingresar identificación del Empleado a eliminar");
                }

            }
            catch (Exception) { MessageBox.Show("Favor ingresar identificación del Empleado a eliminar"); }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<FacturacionPedido> Lista = FacturacionPedido.Listar();
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Facturas agregadas en la base de datos");
            }
            else
            {
                gvEmpleado.DataSource = Lista;

            }
        }

        public void LimpiarComboBox()
        {
            DDLidentificacion.DataSource = null;
            DDLidentificacion.Items.Clear();

            DDLfactura2.DataSource = null;
            DDLfactura2.Items.Clear();

            DDLplatillo.DataSource = null;
            DDLplatillo.Items.Clear();
        }

        private void IniciarLLenadoDropDownList()
        {
            
            IniciarId();
            IniciarPlatillo();
            IniciarFactura();
        }
        private void IniciarId() {

            DDLidentificacion.Items.Insert(0, "[Seleccionar Facturación]");
            SqlCommand SC = new SqlCommand("select idFacturacionPlatillo from FacturacionPlatillo");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLidentificacion.Items.Add(dr[0]);
            }
            dr.Close();
        }

        private void IniciarFactura() {

            DDLfactura2.Items.Insert(0, "[Seleccionar Facturación]");
            SqlCommand SC = new SqlCommand("select idFacturacion from Facturacion");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLfactura2.Items.Add(dr[0]);
            }
            dr.Close();
        }

        private void IniciarPlatillo() {

            DDLplatillo.Items.Insert(0, "[Seleccionar Facturación]");
            SqlCommand SC = new SqlCommand("select idPlatillo from Platillo");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLplatillo.Items.Add(dr[0]);
            }
            dr.Close();
        }
        private void limpiar()
        {
            txtCantidad.Text = "";
            txtPrecio.Text = "";

        }

        private void BtnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }
    }
}
