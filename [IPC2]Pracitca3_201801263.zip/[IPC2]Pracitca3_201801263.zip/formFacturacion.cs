﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Xml.Linq;


namespace _IPC2_Pracitca3_201801263.zip
{
    public partial class formFacturacion : Form
    {
        GD_Facturacion Facturacion = new GD_Facturacion();
        public SqlConnection conexion;
        public string error;
        public formFacturacion()
        {
            InitializeComponent();
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
            IniciarLLenadoDropDownList();
        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void DTPhoraFin_ValueChanged(object sender, EventArgs e)
        {

        }

        private void DTPhoraIni_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Label16_Click(object sender, EventArgs e)
        {

        }

        private void DTPfechaFin_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Label11_Click(object sender, EventArgs e)
        {

        }

        private void Label12_Click(object sender, EventArgs e)
        {

        }

        private void Label13_Click(object sender, EventArgs e)
        {

        }

        private void Label14_Click(object sender, EventArgs e)
        {

        }

        private void Label15_Click(object sender, EventArgs e)
        {

        }

        private void DTPfechaIni_ValueChanged(object sender, EventArgs e)
        {

        }

        private void DDLtiendaRef_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void TxtContrasena_TextChanged(object sender, EventArgs e)
        {

        }

        private void DDLJefe_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Label9_Click(object sender, EventArgs e)
        {

        }

        private void Label8_Click(object sender, EventArgs e)
        {

        }

        private void Label7_Click(object sender, EventArgs e)
        {

        }

        private void Label6_Click(object sender, EventArgs e)
        {

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void TxtCUI_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtPuesto_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtTelefono_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtApellido_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label11_Click_1(object sender, EventArgs e)
        {

        }

        private void DDLJefe_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Facturacion Objeto = new Facturacion();
                Objeto.SerieFactura1 = txtSerie.Text;
                Objeto.Direccion1 = txtDireccion.Text;
                Objeto.Hora1= Convert.ToString(DTPhora.Value);
                Objeto.Fecha1 = DTPfecha.Value;
                Objeto.Nombre1 = txtNombre1.Text;
                Objeto.TotalFactura1 = 11;

                if (txtSerie != null &&  txtNombre1 != null &&  txtDireccion != null && DTPfecha != null && DTPhora != null  )
                {
                    bool agregado = Facturacion.agregar(Objeto);
                    if (agregado)
                    {
                        MessageBox.Show("Datos Factura Agregado Exitosamente");
                        limpiar();
                        IniciarLLenadoDropDownList();

                    }
                    else
                    {
                        MessageBox.Show(Facturacion.error);
                    }
                }
                else
                {
                    MessageBox.Show("Favor Llenar todos los datos");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "Favor Llenar todos los datos");
            }
        }

        private void BtnListar_Click(object sender, EventArgs e)
        {
            Listar();
            MessageBox.Show("Se ha listado por Municipio");
            IniciarLLenadoDropDownList();
        }
        //Metodo para listaClientes
        public void Listar()
        {
            List<Facturacion> Lista = Facturacion.Listar();
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Facturas agregadas en la base de datos");
            }
            else
            {
                gvEmpleado.DataSource = Lista;

            }
        }

        private void BtnConsultar_Click(object sender, EventArgs e)
        {
            try
            {
                byte identificacion = Convert.ToByte(DDLfacturación.Text);

                Facturacion objeto = Facturacion.consultar(identificacion);
                if (objeto != null)
                {
                    
                    txtSerie.Text = objeto.SerieFactura1;
                    txtDireccion.Text = objeto.Direccion1;
                    DTPhora.Value =Convert.ToDateTime( objeto.Hora1);
                    DTPfecha.Value = objeto.Fecha1;
                    txtNombre1.Text = objeto.Nombre1;
                    lblTotalFactura.Text=Convert.ToString(objeto.TotalFactura1);
                    MessageBox.Show("Factura consultada");
                    btnEditar.Enabled = true;
                }
                else
                {
                    MessageBox.Show("No hay Facturas agregados a la base de datos");
                }
            }
            catch (Exception) { MessageBox.Show("Favor seleccionar la identificación del Factura a buscar"); }
        }

        private void IniciarLLenadoDropDownList()
        {
            LimpiarComboBox();
            DDLfacturación.Items.Insert(0, "[Seleccionar Facturación]");
            SqlCommand SC = new SqlCommand("select idFacturacion from Facturacion");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLfacturación.Items.Add(dr[0]);
            }
            dr.Close();
        }

        public void LimpiarComboBox()
        {
            DDLfacturación.DataSource = null;
            DDLfacturación.Items.Clear();
        }

        private void limpiar()
        {
            txtSerie.Text = "";
            txtDireccion.Text = "";
            txtNombre1.Text = "";
            lblTotalFactura.Text = "";

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            formPlatillosFactura pf = new formPlatillosFactura();
            pf.Show();
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            if (DDLfacturación.SelectedIndex == 0)
            {
                MessageBox.Show("Favor consulte el Empleado a Editar");
            }
            else
            {
                try
                {
                    byte numFactura = Convert.ToByte(DDLfacturación.Text);
                    string Serie = txtSerie.Text;
                    string Direccion = txtDireccion.Text;
                    string nombre = txtNombre1.Text;

                    Facturacion.editar(numFactura,Serie, Direccion, nombre);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                    MessageBox.Show("La factura " + numFactura + " ha sido Editado");
                }
                catch (Exception ex) { MessageBox.Show(" " + ex); }
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
    }
}
