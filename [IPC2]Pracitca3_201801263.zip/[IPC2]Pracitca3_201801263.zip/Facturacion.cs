﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _IPC2_Pracitca3_201801263.zip
{
    class Facturacion
    {
        private byte numFacturacion;
        private string SerieFactura;
        private string Direccion;
        private string Hora;
        private DateTime Fecha;
        private string Nombre;
        private int TotalFactura;

        public Facturacion()
        {
        }

        public Facturacion(byte numFacturacion, string serieFactura, string direccion, string hora, DateTime fecha, string nombre, int totalFactura)
        {
            this.numFacturacion = numFacturacion;
            SerieFactura = serieFactura;
            Direccion = direccion;
            Hora = hora;
            Fecha = fecha;
            Nombre = nombre;
            TotalFactura = totalFactura;
        }

        public byte NumFacturacion { get => numFacturacion; set => numFacturacion = value; }
        public string SerieFactura1 { get => SerieFactura; set => SerieFactura = value; }
        public string Direccion1 { get => Direccion; set => Direccion = value; }
        public string Hora1 { get => Hora; set => Hora = value; }
        public DateTime Fecha1 { get => Fecha; set => Fecha = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public int TotalFactura1 { get => TotalFactura; set => TotalFactura = value; }
    }
}
