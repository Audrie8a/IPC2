﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _IPC2_Pracitca3_201801263.zip
{
    class Consulta1
    {
        private byte idRepartidor;
        private int numPedidos;

        public Consulta1()
        {
        }

        public Consulta1(byte idRepartidor, int numPedidos)
        {
            this.idRepartidor = idRepartidor;
            this.numPedidos = numPedidos;
        }

        public byte IdRepartidor { get => idRepartidor; set => idRepartidor = value; }
        public int NumPedidos { get => numPedidos; set => numPedidos = value; }
    }
}
