﻿namespace _IPC2_Pracitca3_201801263.zip
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnFacturacion = new System.Windows.Forms.Button();
            this.btnPedidoAdomicilio = new System.Windows.Forms.Button();
            this.btnReportes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnFacturacion
            // 
            this.btnFacturacion.Location = new System.Drawing.Point(71, 54);
            this.btnFacturacion.Name = "btnFacturacion";
            this.btnFacturacion.Size = new System.Drawing.Size(134, 92);
            this.btnFacturacion.TabIndex = 0;
            this.btnFacturacion.Text = "Facturación";
            this.btnFacturacion.UseVisualStyleBackColor = true;
            this.btnFacturacion.Click += new System.EventHandler(this.BtnFacturacion_Click);
            // 
            // btnPedidoAdomicilio
            // 
            this.btnPedidoAdomicilio.Location = new System.Drawing.Point(476, 54);
            this.btnPedidoAdomicilio.Name = "btnPedidoAdomicilio";
            this.btnPedidoAdomicilio.Size = new System.Drawing.Size(134, 92);
            this.btnPedidoAdomicilio.TabIndex = 1;
            this.btnPedidoAdomicilio.Text = "Pedido Adomicilio";
            this.btnPedidoAdomicilio.UseVisualStyleBackColor = true;
            this.btnPedidoAdomicilio.Click += new System.EventHandler(this.BtnPedidoAdomicilio_Click);
            // 
            // btnReportes
            // 
            this.btnReportes.Location = new System.Drawing.Point(274, 54);
            this.btnReportes.Name = "btnReportes";
            this.btnReportes.Size = new System.Drawing.Size(134, 92);
            this.btnReportes.TabIndex = 2;
            this.btnReportes.Text = "Reportes";
            this.btnReportes.UseVisualStyleBackColor = true;
            this.btnReportes.Click += new System.EventHandler(this.BtnReportes_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnReportes);
            this.Controls.Add(this.btnPedidoAdomicilio);
            this.Controls.Add(this.btnFacturacion);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnFacturacion;
        private System.Windows.Forms.Button btnPedidoAdomicilio;
        private System.Windows.Forms.Button btnReportes;
    }
}

