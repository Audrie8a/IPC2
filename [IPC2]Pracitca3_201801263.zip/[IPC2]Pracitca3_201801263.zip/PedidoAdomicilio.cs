﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _IPC2_Pracitca3_201801263.zip
{
    class PedidoAdomicilio
    {
        private byte idPedido; 
        private int cui;
        private string nit;
        private string Nombre;
        private string Apellido;
        private string Telefono;
        private string Direccion;
        private string Hora;
        private DateTime Fecha;
        private byte idEmpleado;
        private byte idRepartidor;

        public PedidoAdomicilio()
        {
        }

        public PedidoAdomicilio(byte idPedido, int cui, string nit, string nombre, string apellido, string telefono, string direccion, string hora, DateTime fecha, byte idEmpleado, byte idRepartidor)
        {
            this.idPedido = idPedido;
            this.cui = cui;
            this.nit = nit;
            Nombre = nombre;
            Apellido = apellido;
            Telefono = telefono;
            Direccion = direccion;
            Hora = hora;
            Fecha = fecha;
            this.idEmpleado = idEmpleado;
            this.idRepartidor = idRepartidor;
        }

        public byte IdPedido { get => idPedido; set => idPedido = value; }
        public int Cui { get => cui; set => cui = value; }
        public string Nit { get => nit; set => nit = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public string Apellido1 { get => Apellido; set => Apellido = value; }
        public string Telefono1 { get => Telefono; set => Telefono = value; }
        public string Direccion1 { get => Direccion; set => Direccion = value; }
        public string Hora1 { get => Hora; set => Hora = value; }
        public DateTime Fecha1 { get => Fecha; set => Fecha = value; }
        public byte IdEmpleado { get => idEmpleado; set => idEmpleado = value; }
        public byte IdRepartidor { get => idRepartidor; set => idRepartidor = value; }
    }
}
