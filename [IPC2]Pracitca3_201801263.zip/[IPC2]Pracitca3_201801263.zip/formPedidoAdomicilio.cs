﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Xml.Linq;

namespace _IPC2_Pracitca3_201801263.zip
{
    public partial class formPedidoAdomicilio : Form
    {
        GD_PedidoAdomicilio PedidoAdomicilio = new GD_PedidoAdomicilio();
        public SqlConnection conexion;
        public string error;
        public formPedidoAdomicilio()
        {
            InitializeComponent();
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
            IniciarLLenadoDropDownList();
        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                PedidoAdomicilio Objeto = new PedidoAdomicilio();
                Objeto.Cui = Convert.ToInt32(txtCui.Text);
                Objeto.Nit= txtNit.Text; ;
                Objeto.Nombre1 = txtNombre1.Text;
                Objeto.Apellido1 = txtApellido.Text;
                Objeto.Telefono1= txtTelefono.Text;
                Objeto.Direccion1 = txtDireccion.Text;
                Objeto.Hora1 = Convert.ToString(DTPhora.Value);
                Objeto.Fecha1 = DTPfecha.Value;
                Objeto.IdEmpleado = Convert.ToByte(DDLempleado.Text);
                Objeto.IdRepartidor = Convert.ToByte(DDLrepartidor.Text);

                if (txtNit!= null && txtNombre1!= null)
                {
                    bool agregado = PedidoAdomicilio.agregar(Objeto);
                    if (agregado)
                    {
                        MessageBox.Show("Factura Agregado Exitosamente");
                        limpiar();
                        IniciarLLenadoDropDownList();

                    }
                    else
                    {
                        MessageBox.Show(PedidoAdomicilio.error);
                    }
                }
                else
                {
                    MessageBox.Show("Favor Llenar todos los datos");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "Favor Llenar todos los datos");
            }
        }

        private void BtnConsultar_Click(object sender, EventArgs e)
        {
            try
            {
                byte identificacion = Convert.ToByte(DDLidentificacion.Text);

                PedidoAdomicilio objeto = PedidoAdomicilio.consultar(identificacion);
                if (objeto != null)
                {

                    txtCui.Text = Convert.ToString(objeto.Cui);
                    txtNit.Text = Convert.ToString(objeto.Nit);
                    txtNombre1.Text = Convert.ToString(objeto.Nombre1);
                    txtApellido.Text = Convert.ToString(objeto.Apellido1);
                    txtTelefono.Text = objeto.Telefono1;
                    txtDireccion.Text = objeto.Direccion1;
                    DTPhora.Value = Convert.ToDateTime(objeto.Hora1);
                    DTPfecha.Value = objeto.Fecha1;
                    DDLempleado.Text = Convert.ToString(objeto.IdEmpleado);
                    DDLrepartidor.Text = Convert.ToString(objeto.IdRepartidor);
                    MessageBox.Show("Factura consultada");
                    btnEditar.Enabled = true;
                }
                else
                {
                    MessageBox.Show("No hay Facturas agregados a la base de datos");
                }
            }
            catch (Exception ex) { MessageBox.Show(ex+"Favor seleccionar la identificación del Factura a buscar"); }
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                MessageBox.Show("Favor consulte el Empleado a Editar");
            }
            else
            {
                try
                {
                    byte idPedido = Convert.ToByte(DDLidentificacion.Text);
                    byte idEmpleado = Convert.ToByte(DDLempleado.Text);
                    byte idRepartidor = Convert.ToByte(DDLrepartidor.Text);
                    int Cui = Convert.ToInt32(txtCui.Text);
                    string nit = txtNit.Text;
                    string nOmbre = txtNombre1.Text;
                    string apellido = txtApellido.Text;
                    string telefono = txtTelefono.Text;
                    string hora = Convert.ToString(DTPhora.Value);
                    DateTime fecha = DTPfecha.Value;


                    PedidoAdomicilio.editar(idPedido,Cui, nit, nOmbre, apellido, telefono, txtDireccion.Text, hora, fecha, idEmpleado, idRepartidor);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                    MessageBox.Show("La factura " + idPedido + " ha sido Editado");
                }
                catch (Exception ex) { MessageBox.Show(" " + ex); }
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);


                    PedidoAdomicilio.eliminar(identificacion);
                    MessageBox.Show("Empleado Eliminado exitosamente");
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    MessageBox.Show("Favor ingresar identificación del Empleado a eliminar");
                }

            }
            catch (Exception) { MessageBox.Show("Favor ingresar identificación del Empleado a eliminar"); }
        }

        private void BtnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<PedidoAdomicilio> Lista = PedidoAdomicilio.Listar();
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Facturas agregadas en la base de datos");
            }
            else
            {
                gvEmpleado.DataSource = Lista;

            }
        }

        public void LimpiarComboBox()
        {
            DDLidentificacion.DataSource = null;
            DDLidentificacion.Items.Clear();

            DDLempleado.DataSource = null;
            DDLempleado.Items.Clear();

            DDLrepartidor.DataSource = null;
            DDLrepartidor.Items.Clear();
        }

        private void IniciarLLenadoDropDownList()
        {

            IniciarId();
            IniciarPlatillo();
            IniciarFactura();
        }
        private void IniciarId()
        {

            DDLidentificacion.Items.Insert(0, "[Seleccionar Facturación]");
            SqlCommand SC = new SqlCommand("select idPedidoA from PeiddoAdomicilio ");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLidentificacion.Items.Add(dr[0]);
            }
            dr.Close();
        }

        private void IniciarFactura()
        {

            DDLempleado.Items.Insert(0, "[Seleccionar Facturación]");
            SqlCommand SC = new SqlCommand("select idEmpleado from Empleado where idPuesto=9");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLempleado.Items.Add(dr[0]);
            }
            dr.Close();
        }

        private void IniciarPlatillo()
        {

            DDLrepartidor.Items.Insert(0, "[Seleccionar Facturación]");
            SqlCommand SC = new SqlCommand("select idEmpleado from Empleado where idPuesto=8");
            SC.Connection = conexion;
            SqlDataReader dr = SC.ExecuteReader();
            while (dr.Read())
            {
                DDLrepartidor.Items.Add(dr[0]);
            }
            dr.Close();
        }
        private void limpiar()
        {
            txtNit.Text = "";
            txtCui.Text = "";
            txtNombre1.Text = "";
            txtApellido.Text = "";
            txtTelefono.Text = "";
            txtDireccion.Text = "";
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f = new Form1();
            f.Show();
        }
    }
}
