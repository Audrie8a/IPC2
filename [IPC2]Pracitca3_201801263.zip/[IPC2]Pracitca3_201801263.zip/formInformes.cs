﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Xml.Linq;


namespace _IPC2_Pracitca3_201801263.zip
{
    public partial class formInformes : Form
    {
        GD_Consultas Consulta = new GD_Consultas();
        public SqlConnection conexion;
        public string error;
        public formInformes()
        {
            InitializeComponent();
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            List<Consulta1> Lista = Consulta.ListarConsulta1();
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Facturas agregadas en la base de datos");
            }
            else
            {
                gvConsultas.DataSource = Lista;

            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            List<Consulta2> Lista = Consulta.ListarConsulta2();
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Facturas agregadas en la base de datos");
            }
            else
            {
                gvConsultas.DataSource = Lista;

            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            List<Consulta3> Lista = Consulta.ListarConsulta3();
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Facturas agregadas en la base de datos");
            }
            else
            {
                gvConsultas.DataSource = Lista;

            }
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            List<Consulta5> Lista = Consulta.ListarConsulta5();
            if (Lista.Count == 0)
            {
                MessageBox.Show("No hay Facturas agregadas en la base de datos");
            }
            else
            {
                gvConsultas.DataSource = Lista;

            }
        }
    }
}
