﻿namespace _IPC2_Pracitca3_201801263.zip
{
    partial class formFacturacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DTPhora = new System.Windows.Forms.DateTimePicker();
            this.DTPfecha = new System.Windows.Forms.DateTimePicker();
            this.lblTotalFactura = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtSerie = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNombre1 = new System.Windows.Forms.TextBox();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.DDLfacturación = new System.Windows.Forms.ComboBox();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnEditar = new System.Windows.Forms.Button();
            this.btnConsultar = new System.Windows.Forms.Button();
            this.gvEmpleado = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.btnListar = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.gvEmpleado)).BeginInit();
            this.SuspendLayout();
            // 
            // DTPhora
            // 
            this.DTPhora.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.DTPhora.Location = new System.Drawing.Point(123, 194);
            this.DTPhora.Name = "DTPhora";
            this.DTPhora.Size = new System.Drawing.Size(200, 20);
            this.DTPhora.TabIndex = 84;
            this.DTPhora.ValueChanged += new System.EventHandler(this.DTPhoraIni_ValueChanged);
            // 
            // DTPfecha
            // 
            this.DTPfecha.Location = new System.Drawing.Point(123, 168);
            this.DTPfecha.Name = "DTPfecha";
            this.DTPfecha.Size = new System.Drawing.Size(200, 20);
            this.DTPfecha.TabIndex = 82;
            this.DTPfecha.ValueChanged += new System.EventHandler(this.DTPfechaFin_ValueChanged);
            // 
            // lblTotalFactura
            // 
            this.lblTotalFactura.AutoSize = true;
            this.lblTotalFactura.Location = new System.Drawing.Point(120, 228);
            this.lblTotalFactura.Name = "lblTotalFactura";
            this.lblTotalFactura.Size = new System.Drawing.Size(0, 13);
            this.lblTotalFactura.TabIndex = 80;
            this.lblTotalFactura.Click += new System.EventHandler(this.Label12_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(23, 228);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(73, 13);
            this.label13.TabIndex = 79;
            this.label13.Text = "Total Factura:";
            this.label13.Click += new System.EventHandler(this.Label13_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(22, 197);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(33, 13);
            this.label14.TabIndex = 78;
            this.label14.Text = "Hora:";
            this.label14.Click += new System.EventHandler(this.Label14_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(23, 170);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(40, 13);
            this.label15.TabIndex = 77;
            this.label15.Text = "Fecha:";
            this.label15.Click += new System.EventHandler(this.Label15_Click);
            // 
            // txtSerie
            // 
            this.txtSerie.Location = new System.Drawing.Point(123, 80);
            this.txtSerie.Name = "txtSerie";
            this.txtSerie.Size = new System.Drawing.Size(121, 20);
            this.txtSerie.TabIndex = 75;
            this.txtSerie.TextChanged += new System.EventHandler(this.TxtCUI_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 144);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 69;
            this.label6.Text = "Nombre:";
            this.label6.Click += new System.EventHandler(this.Label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 68;
            this.label5.Text = "Dirección: ";
            this.label5.Click += new System.EventHandler(this.Label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(23, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 67;
            this.label4.Text = "Serie: ";
            this.label4.Click += new System.EventHandler(this.Label4_Click);
            // 
            // txtNombre1
            // 
            this.txtNombre1.Location = new System.Drawing.Point(123, 138);
            this.txtNombre1.Name = "txtNombre1";
            this.txtNombre1.Size = new System.Drawing.Size(121, 20);
            this.txtNombre1.TabIndex = 64;
            this.txtNombre1.TextChanged += new System.EventHandler(this.TxtApellido_TextChanged);
            // 
            // txtDireccion
            // 
            this.txtDireccion.Location = new System.Drawing.Point(123, 111);
            this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(121, 20);
            this.txtDireccion.TabIndex = 63;
            this.txtDireccion.TextChanged += new System.EventHandler(this.TxtNombre_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(24, 51);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 13);
            this.label11.TabIndex = 86;
            this.label11.Text = "No. Factura";
            this.label11.Click += new System.EventHandler(this.Label11_Click_1);
            // 
            // DDLfacturación
            // 
            this.DDLfacturación.FormattingEnabled = true;
            this.DDLfacturación.Location = new System.Drawing.Point(123, 44);
            this.DDLfacturación.Name = "DDLfacturación";
            this.DDLfacturación.Size = new System.Drawing.Size(121, 21);
            this.DDLfacturación.TabIndex = 85;
            this.DDLfacturación.SelectedIndexChanged += new System.EventHandler(this.DDLJefe_SelectedIndexChanged_1);
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(29, 301);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 151;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.BtnAgregar_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.Location = new System.Drawing.Point(193, 301);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(75, 23);
            this.btnEditar.TabIndex = 149;
            this.btnEditar.Text = "Editar";
            this.btnEditar.UseVisualStyleBackColor = true;
            this.btnEditar.Click += new System.EventHandler(this.BtnEditar_Click);
            // 
            // btnConsultar
            // 
            this.btnConsultar.Location = new System.Drawing.Point(112, 301);
            this.btnConsultar.Name = "btnConsultar";
            this.btnConsultar.Size = new System.Drawing.Size(75, 23);
            this.btnConsultar.TabIndex = 148;
            this.btnConsultar.Text = "Consultar";
            this.btnConsultar.UseVisualStyleBackColor = true;
            this.btnConsultar.Click += new System.EventHandler(this.BtnConsultar_Click);
            // 
            // gvEmpleado
            // 
            this.gvEmpleado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvEmpleado.Location = new System.Drawing.Point(494, 59);
            this.gvEmpleado.Name = "gvEmpleado";
            this.gvEmpleado.Size = new System.Drawing.Size(381, 322);
            this.gvEmpleado.TabIndex = 152;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(494, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(381, 40);
            this.button1.TabIndex = 153;
            this.button1.Text = "Regresar a Página Principal";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // btnListar
            // 
            this.btnListar.Location = new System.Drawing.Point(274, 301);
            this.btnListar.Name = "btnListar";
            this.btnListar.Size = new System.Drawing.Size(75, 23);
            this.btnListar.TabIndex = 154;
            this.btnListar.Text = "Listar";
            this.btnListar.UseVisualStyleBackColor = true;
            this.btnListar.Click += new System.EventHandler(this.BtnListar_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(29, 368);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(408, 70);
            this.button2.TabIndex = 155;
            this.button2.Text = "Seleccionar Platillos Consumidos";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // formFacturacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(893, 448);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnListar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.gvEmpleado);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.btnConsultar);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.DDLfacturación);
            this.Controls.Add(this.DTPhora);
            this.Controls.Add(this.DTPfecha);
            this.Controls.Add(this.lblTotalFactura);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtSerie);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtNombre1);
            this.Controls.Add(this.txtDireccion);
            this.Name = "formFacturacion";
            this.Text = "formFacturacion";
            ((System.ComponentModel.ISupportInitialize)(this.gvEmpleado)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DateTimePicker DTPhora;
        private System.Windows.Forms.DateTimePicker DTPfecha;
        private System.Windows.Forms.Label lblTotalFactura;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtSerie;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNombre1;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox DDLfacturación;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.Button btnConsultar;
        private System.Windows.Forms.DataGridView gvEmpleado;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnListar;
        private System.Windows.Forms.Button button2;
    }
}