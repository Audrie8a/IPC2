﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace _IPC2_Pracitca3_201801263.zip
{
    class GD_PedidoAdomicilio
    {
        public SqlConnection conexion;
        public string error;

        public GD_PedidoAdomicilio()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(PedidoAdomicilio Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into PeiddoAdomicilio values(@CuiCliente, @Nit, @NombreCliente, @Apellido, @Telefono,@Direccion, @Hora, @Fecha, @Empleado, @Repartidor);";
            comando.Parameters.AddWithValue("@CuiCliente", Dato.Cui);
            comando.Parameters.AddWithValue("@Nit", Dato.Nit);
            comando.Parameters.AddWithValue("@NombreCliente", Dato.Nombre1);
            comando.Parameters.AddWithValue("@Apellido", Dato.Apellido1);
            comando.Parameters.AddWithValue("@Telefono", Dato.Telefono1);
            comando.Parameters.AddWithValue("@Direccion", Dato.Direccion1);
            comando.Parameters.AddWithValue("@Hora", Dato.Hora1);
            comando.Parameters.AddWithValue("@Fecha", Dato.Fecha1);
            comando.Parameters.AddWithValue("@Empleado", Dato.IdEmpleado);
            comando.Parameters.AddWithValue("@Repartidor", Dato.IdRepartidor);

            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public PedidoAdomicilio consultar(byte ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from PeiddoAdomicilio where idPedidoA=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                PedidoAdomicilio Dato = new PedidoAdomicilio();
                Dato.IdPedido = registro.GetByte(0);
                Dato.Cui = registro.GetInt32(1);
                Dato.Nit = registro.GetString(2);
                Dato.Nombre1= registro.GetString(3);
                Dato.Apellido1 = registro.GetString(4);
                Dato.Telefono1 = registro.GetString(5);
                Dato.Direccion1 = registro.GetString(6);
                Dato.Hora1 = registro.GetString(7);
                Dato.Fecha1 = registro.GetDateTime(8);
                Dato.IdEmpleado = registro.GetByte(9);
                Dato.IdRepartidor = registro.GetByte(10);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(byte ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from PeiddoAdomicilio where idPedidoA=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<PedidoAdomicilio> Listar()
        {
            List<PedidoAdomicilio> Lista = new List<PedidoAdomicilio>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from PeiddoAdomicilio";
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                PedidoAdomicilio Dato1 = new PedidoAdomicilio();
                Dato1.IdPedido = registro.GetByte(0);
                Dato1.Cui= registro.GetInt32(1);
                Dato1.Nit= registro.GetString(2);
                Dato1.Nombre1= registro.GetString(3);
                Dato1.Apellido1= registro.GetString(4);
                Dato1.Telefono1 = registro.GetString(5);
                Dato1.Direccion1 = registro.GetString(6);
                Dato1.Hora1 = registro.GetString(7);
                Dato1.Fecha1 = registro.GetDateTime(8);
                Dato1.IdEmpleado = registro.GetByte(9);
                Dato1.IdRepartidor = registro.GetByte(10);
                Lista.Add(Dato1);
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte idPedido,int cui, string nit, string cliente, string apellido, string telefono, string direcion, string hora, DateTime fecha, byte empleado, byte repartidor)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "update PeiddoAdomicilio set CuiCliente=@CC, NIT=@N , NombreCliente=@Nc, Apellido=@a, Telefono=@t, Direccion=@d, Hora=@h, Fecha=@f, Empleado=@e,Repartidor=@r where idPedidoA=@id";
            comando.Parameters.AddWithValue("@id", idPedido);
            comando.Parameters.AddWithValue("@CC", cui);
            comando.Parameters.AddWithValue("@N", nit);
            comando.Parameters.AddWithValue("@Nc", cliente);
            comando.Parameters.AddWithValue("@a", apellido);
            comando.Parameters.AddWithValue("@t", telefono);
            comando.Parameters.AddWithValue("@d", direcion);
            comando.Parameters.AddWithValue("@h", hora);
            comando.Parameters.AddWithValue("@f", fecha);
            comando.Parameters.AddWithValue("@e", empleado);
            comando.Parameters.AddWithValue("@r", repartidor);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }
    }
}
