﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _IPC2_Pracitca3_201801263.zip
{
    class FacturacionPedido
    {
        private byte idFacPedido;
        private byte idFacturacion;
        private byte idPlatillo;
        private int Precio;
        private int Cantidad;

        public FacturacionPedido()
        {
        }

        public FacturacionPedido(byte idFacPedido, byte idFacturacion, byte idPlatillo, int precio, int cantidad)
        {
            this.idFacPedido = idFacPedido;
            this.idFacturacion = idFacturacion;
            this.idPlatillo = idPlatillo;
            Precio = precio;
            Cantidad = cantidad;
        }

        public byte IdFacPedido { get => idFacPedido; set => idFacPedido = value; }
        public byte IdFacturacion { get => idFacturacion; set => idFacturacion = value; }
        public byte IdPlatillo { get => idPlatillo; set => idPlatillo = value; }
        public int Precio1 { get => Precio; set => Precio = value; }
        public int Cantidad1 { get => Cantidad; set => Cantidad = value; }
    }
}
