﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _IPC2_Pracitca3_201801263.zip
{
    class Consulta3
    {
        private byte idPlatillo;
        private int numOrdenes;

        public Consulta3()
        {
        }

        public byte IdPlatillo { get => idPlatillo; set => idPlatillo = value; }
        public int NumOrdenes { get => numOrdenes; set => numOrdenes = value; }
    }
}
