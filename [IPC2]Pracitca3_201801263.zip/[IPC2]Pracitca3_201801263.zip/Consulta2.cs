﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _IPC2_Pracitca3_201801263.zip
{
    class Consulta2
    {
        private byte idEmpleado;
        private int numOrdenes;

        public Consulta2()
        {
        }

        public Consulta2(byte idEmpleado, int numOrdenes)
        {
            this.idEmpleado = idEmpleado;
            this.numOrdenes = numOrdenes;
        }

        public byte IdEmpleado { get => idEmpleado; set => idEmpleado = value; }
        public int NumOrdenes { get => numOrdenes; set => numOrdenes = value; }
    }
}
