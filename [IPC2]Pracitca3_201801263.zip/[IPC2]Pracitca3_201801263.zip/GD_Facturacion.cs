﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace _IPC2_Pracitca3_201801263.zip
{
    class GD_Facturacion
    {
        public SqlConnection conexion;
        public string error;

        public GD_Facturacion()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Facturacion Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Facturacion values (@serieFactura, @Direccion, @Hora, @Fecha, @Nombre,@TotalFactura);";
            comando.Parameters.AddWithValue("@serieFactura", Dato.Fecha1);
            comando.Parameters.AddWithValue("@Direccion", Dato.Direccion1);
            comando.Parameters.AddWithValue("@Hora", Dato.Hora1);
            comando.Parameters.AddWithValue("@Fecha", Dato.Fecha1);
            comando.Parameters.AddWithValue("@Nombre", Dato.Nombre1);
            comando.Parameters.AddWithValue("@TotalFactura", Dato.TotalFactura1);

            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Facturacion consultar(byte ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Facturacion where idFacturacion=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Facturacion Dato = new Facturacion();
                Dato.NumFacturacion = registro.GetByte(0);
                Dato.SerieFactura1 = registro.GetString(1);
                Dato.Direccion1 = registro.GetString(2);
                Dato.Hora1 = registro.GetString(3);
                Dato.Fecha1= registro.GetDateTime(4);
                Dato.Nombre1 = registro.GetString(5);
                Dato.TotalFactura1= registro.GetInt32(6);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(byte ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Facturacion where idFacturacion=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Facturacion> Listar()
        {
            List<Facturacion> Lista = new List<Facturacion>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Facturacion";
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                Facturacion Dato1 = new Facturacion();
                Dato1.NumFacturacion = registro.GetByte(0);
                Dato1.SerieFactura1 = registro.GetString(1);
                Dato1.Direccion1 = registro.GetString(2);
                Dato1.Hora1 = registro.GetString(3);
                Dato1.Fecha1 = registro.GetDateTime(4);
                Dato1.Nombre1 = registro.GetString(5);
                Dato1.TotalFactura1 = registro.GetInt32(6);
                Lista.Add(Dato1);
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte numFactura, string serie, string direccion, string nombre)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Facturacion set serieFactura=@serie, Direccion=@D,NombreCliente=@N where idFacturacion =@id;";
            comando.Parameters.AddWithValue("@id", numFactura);
            comando.Parameters.AddWithValue("@serie", serie);
            comando.Parameters.AddWithValue("@D", direccion);
            comando.Parameters.AddWithValue("@N", nombre);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

    }
}
