﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace _IPC2_Pracitca3_201801263.zip
{
    class GD_Consultas
    {
        public SqlConnection conexion;
        public string error;
        public GD_Consultas()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        public List<Consulta1> ListarConsulta1()
        {
            List<Consulta1> Lista = new List<Consulta1>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from RepartosRepartidor order by numRepartos desc";
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                Consulta1 Dato1 = new Consulta1();
                Dato1.IdRepartidor = registro.GetByte(1);
                Dato1.NumPedidos = registro.GetInt32(2);
                Lista.Add(Dato1);
            }
            registro.Close();
            return Lista;
        }

        public List<Consulta2> ListarConsulta2()
        {
            List<Consulta2> Lista = new List<Consulta2>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from OrdenesEmpleado order by numOrdenes desc";
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                Consulta2 Dato1 = new Consulta2();
                Dato1.IdEmpleado = registro.GetByte(1);
                Dato1.NumOrdenes = registro.GetInt32(2);
                Lista.Add(Dato1);
            }
            registro.Close();
            return Lista;
        }

        public List<Consulta3> ListarConsulta3()
        {
            List<Consulta3> Lista = new List<Consulta3>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from OrdenPlatillo order by numOrdenes desc";
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                Consulta3 Dato1 = new Consulta3();
                Dato1.IdPlatillo = registro.GetByte(1);
                Dato1.NumOrdenes = registro.GetInt32(2);
                Lista.Add(Dato1);
            }
            registro.Close();
            return Lista;
        }

        public List<Consulta5> ListarConsulta5()
        {
            List<Consulta5> Lista = new List<Consulta5>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from totalFacturacionDía order by idTotalFacturacionDía  desc";
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            while (registro.Read())
            {
                Consulta5 Dato1 = new Consulta5();
                Dato1.Fecha = registro.GetDateTime(1);
                Dato1.Facturacion1 = registro.GetInt32(2);
                Lista.Add(Dato1);
            }
            registro.Close();
            return Lista;
        }
    }
}
