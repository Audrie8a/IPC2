﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_ClienteEmpresa
    {
        public SqlConnection conexion;
        public string error;

        public GD_ClienteEmpresa()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar Clientes de la Empresa a la base de datos
        public bool agregarClienteEmpresa(ClienteEmpresa Cliente)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "AgregarClienteEmpresa";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@NIT", Cliente.IdClienteE);
            comando.Parameters.AddWithValue("@Nombre", Cliente.NOMBRE);
            comando.Parameters.AddWithValue("@Direccion", Cliente.DIRECCION);
            comando.Parameters.AddWithValue("@Telefono", Cliente.TELEFONO);
            comando.Parameters.AddWithValue("@idContactoEncargado", Cliente.CONTACTO_ENCARGADO);
            comando.Parameters.AddWithValue("@Correo", Cliente.CORREO);
            comando.Parameters.AddWithValue("@LimiteCredito", Cliente.LIMITE_CREDITO);
            comando.Parameters.AddWithValue("@TiempoCredito", Cliente.TIEMPO_CREDITO);
            comando.Parameters.AddWithValue("@idCodigoCategoria", Cliente.CODIGO_CATEGORIA);            
            comando.Parameters.AddWithValue("@idEstadoCliente", Cliente.ESTADO_CLIENTE);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar un Cliente de la Empresa
        public ClienteEmpresa consultarClienteEmpresa(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "ConsultarClienteEmpresa";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                ClienteEmpresa Cliente = new ClienteEmpresa();
                Cliente.IdClienteE = registro.GetByte(0);
                Cliente.Nit = registro.GetString(1);
                Cliente.NOMBRE = registro.GetString(2);
                Cliente.DIRECCION = registro.GetString(3);
                Cliente.TELEFONO = registro.GetString(4);
                Cliente.CONTACTO_ENCARGADO = registro.GetString(5);
                Cliente.CORREO = registro.GetString(6);
                Cliente.LIMITE_CREDITO = registro.GetInt32(7);
                Cliente.TIEMPO_CREDITO = registro.GetByte(8);
                Cliente.CODIGO_CATEGORIA = registro.GetByte(9);
                Cliente.ESTADO_CLIENTE = registro.GetByte(10);
                registro.Close();
                return Cliente;
               
            }
            else
            {
                registro.Close();
                return null;
            }
            //comando.Parameters.Clear();
        }

        //Métodos para Eliminar un Cliente de la Empresa
        public void eliminarClienteEmpresa(int ID) {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "EliminarClienteEmpresa";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
            
        }

        //Método para mostrar la lista de clientes de la Empresa
        public List<ClienteEmpresa> lstClientesEmpresa()
        {
            List<ClienteEmpresa> LClientesEmpresa = new List<ClienteEmpresa>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from ClienteEmpresa";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                ClienteEmpresa Cliente = new ClienteEmpresa();
                Cliente.IdClienteE = registro.GetByte(0);
                Cliente.Nit = registro.GetString(1);
                Cliente.NOMBRE = registro.GetString(2);
                Cliente.DIRECCION = registro.GetString(3);
                Cliente.TELEFONO = registro.GetString(4);
                Cliente.CONTACTO_ENCARGADO = registro.GetString(5);
                Cliente.CORREO = registro.GetString(6);
                Cliente.LIMITE_CREDITO = registro.GetInt32(7);
                Cliente.TIEMPO_CREDITO = registro.GetByte(8);
                Cliente.CODIGO_CATEGORIA = registro.GetByte(9);
                Cliente.ESTADO_CLIENTE = registro.GetByte(10);
                LClientesEmpresa.Add(Cliente);
                comando.Parameters.Clear();
            }
            registro.Close();
            return LClientesEmpresa;
        }

        //Método para Editar
        public void editarClienteEmpres(int idClienteE, string NIT, string Nombre, string Direccion, 
            string Telefono, string ContactoEncargado, string Correo, byte CodigoCategoria, int LimiteCredito, byte TiempoCredito, byte EstadoCliente) {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "EditarClienteEmresa";
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("@idClienteE", idClienteE);
            comando.Parameters.AddWithValue("@Nit", NIT);
            comando.Parameters.AddWithValue("@Nombre", Nombre);
            comando.Parameters.AddWithValue("@Direccion", Direccion);
            comando.Parameters.AddWithValue("@Telefono", Telefono);
            comando.Parameters.AddWithValue("@idContactoEncargado", ContactoEncargado);
            comando.Parameters.AddWithValue("@Correo", Correo);
            comando.Parameters.AddWithValue("@LimiteCredito", LimiteCredito);
            comando.Parameters.AddWithValue("@TiempoCredito", TiempoCredito);
            comando.Parameters.AddWithValue("@idCodigoCategoria", CodigoCategoria);
            comando.Parameters.AddWithValue("@idEstadoCliente", EstadoCliente);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar las categorías existentes
        public DataSet Consultar(string Consulta) {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }

       
    }
}