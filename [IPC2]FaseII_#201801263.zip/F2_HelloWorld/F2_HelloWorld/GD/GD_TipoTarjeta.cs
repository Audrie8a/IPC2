﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_TipoTarjeta
    {
        public SqlConnection conexion;
        public string error;

        public GD_TipoTarjeta()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(TipoTarjeta Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into TipoTarjeta values (@TipoTarjeta);";
            comando.Parameters.AddWithValue("@TipoTarjeta", Dato.TipoT1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public TipoTarjeta consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from TipoTarjeta where idTipoTarjeta=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                TipoTarjeta Dato = new TipoTarjeta();
                Dato.IdTipoTarjeta = registro.GetByte(0);
                Dato.TipoT1 = registro.GetString(1);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from TipoTarjeta where idTipoTarjeta=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<TipoTarjeta> Listar()
        {
            List<TipoTarjeta> Lista = new List<TipoTarjeta>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from TipoTarjeta";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                TipoTarjeta Objeto = new TipoTarjeta();
                Objeto.IdTipoTarjeta = registro.GetByte(0);
                Objeto.TipoT1 = registro.GetString(1);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idTipoTarjeta, string TipoT)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update TipoTarjeta set TipoTarjeta=@TipoTarjeta where idTipoTarjeta=@idTipoTarjeta";
            comando.Parameters.AddWithValue("@idTipoTarjeta", idTipoTarjeta);
            comando.Parameters.AddWithValue("@TipoTarjeta", TipoT);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}