﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Bodega
    {
        public SqlConnection conexion;
        public string error;

        public GD_Bodega() {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Bodega Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Bodega values (@Bodega, @idInventario);";
            comando.Parameters.AddWithValue("@Bodega", Dato.BodegaN1);
            comando.Parameters.AddWithValue("@idInventario", Dato.IdInventario);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Bodega consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Bodega where idBodega=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Bodega Dato = new Bodega();
                Dato.IdBodega= registro.GetByte(0);
                Dato.BodegaN1 = registro.GetString(1);
                Dato.IdInventario = registro.GetByte(2);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Bodega where idBodega=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Bodega> Listar()
        {
            List<Bodega> Lista = new List<Bodega>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Bodega";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Bodega Objeto = new Bodega();
                Objeto.IdBodega= registro.GetByte(0);
                Objeto.BodegaN1 = registro.GetString(1);
                Objeto.IdInventario = registro.GetByte(2);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idBodega, string Bodega, byte idInventario)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Bodega set Bodega=@Bodega, idInventario=@idInventario where idBodega=@idBodega";
            comando.Parameters.AddWithValue("@idBodega", idBodega);
            comando.Parameters.AddWithValue("@Bodega", Bodega);
            comando.Parameters.AddWithValue("@idInventario", idInventario);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}