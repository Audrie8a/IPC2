﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Facturacion
    {
        public SqlConnection conexion;
        public string error;

        public GD_Facturacion() {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Facturacion Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Facturacion values (@idCliente, @idVendedor);";
            comando.Parameters.AddWithValue("@idCliente", Dato.IdClienteE);
            comando.Parameters.AddWithValue("@idVendedor", Dato.IdVendedor);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Facturacion consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Facturacion where idFacturacion=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Facturacion Dato = new Facturacion();
                Dato.IdFacturacion= registro.GetByte(0);
                Dato.IdClienteE = registro.GetByte(1);
                Dato.IdVendedor = registro.GetByte(2);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Facturacion where idFacturacion=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Facturacion> Listar()
        {
            List<Facturacion> Lista = new List<Facturacion>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Facturacion";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Facturacion Objeto = new Facturacion();
                Objeto.IdFacturacion= registro.GetByte(0);
                Objeto.IdClienteE = registro.GetByte(1);
                Objeto.IdVendedor= registro.GetByte(2);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idFacturacion, byte idClienteE, byte idVendedor)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Facturacion set idClienteE=@idClienteE, idVendedor=@idVendedor where idFacturacion=@idFacturacion";
            comando.Parameters.AddWithValue("@idFacturacion", idFacturacion);
            comando.Parameters.AddWithValue("@idClienteE", idClienteE);
            comando.Parameters.AddWithValue("@idVendedor", idVendedor);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}