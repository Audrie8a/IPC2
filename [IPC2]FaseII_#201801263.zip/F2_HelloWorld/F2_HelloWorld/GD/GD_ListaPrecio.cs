﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_ListaPrecio
    {
        public SqlConnection conexion;
        public string error;

        public GD_ListaPrecio()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(ListaPrecio Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into ListaPrecio values (@fechaIni, @fechaFin, @ChangeDQ);";
            comando.Parameters.AddWithValue("@fechaIni", Dato.FechaIni);
            comando.Parameters.AddWithValue("@fechaFin", Dato.FechaFin);
            comando.Parameters.AddWithValue("@ChangeDQ", Dato.CambioDolarQuetzal1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public ListaPrecio consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from ListaPrecio where idListaPrecio=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                ListaPrecio Dato = new ListaPrecio();
                Dato.IdListaPrecio = registro.GetByte(0);
                Dato.FechaIni = registro.GetDateTime(1);
                Dato.FechaFin = registro.GetDateTime(2);
                Dato.CambioDolarQuetzal1 = registro.GetInt32(3);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from ListaPrecio where idListaPrecio=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<ListaPrecio> Listar()
        {
            List<ListaPrecio> Lista = new List<ListaPrecio>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from ListaPrecio";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                ListaPrecio Objeto = new ListaPrecio();
                Objeto.IdListaPrecio = registro.GetByte(0);
                Objeto.FechaIni = registro.GetDateTime(1);
                Objeto.FechaFin = registro.GetDateTime(2);
                Objeto.CambioDolarQuetzal1 = registro.GetInt32(3);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idListaPrecio, DateTime fI, DateTime fF, int CDQ)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "update ListaPrecio set fechaInicio=@fI,fechaFin=@fF,CambioDolarQuetzal=@CDQ where idListaPrecio=@idListaPrecio";
            comando.Parameters.AddWithValue("@idListaPrecio", idListaPrecio);
            comando.Parameters.AddWithValue("@fI", fI);
            comando.Parameters.AddWithValue("@fF", fF);
            comando.Parameters.AddWithValue("@CDQ", CDQ);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}