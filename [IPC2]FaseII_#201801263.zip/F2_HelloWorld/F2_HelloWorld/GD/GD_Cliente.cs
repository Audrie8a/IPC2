﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Cliente
    {
        public SqlConnection conexion;
        public string error;

        public GD_Cliente()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Cliente Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Cliente values (@NIT, @Nombre, @tipoEmpresa, @tamanioEmpresa, @tarjetaCredidto, @iUsuario);";
            comando.Parameters.AddWithValue("@NIT", Dato.NIT1);
            comando.Parameters.AddWithValue("@Nombre", Dato.Nombre1);
            comando.Parameters.AddWithValue("@tipoEmpresa", Dato.Id_TipoEmpresa);
            comando.Parameters.AddWithValue("@tamanioEmpresa", Dato.Id_TamanoEmpresa);
            comando.Parameters.AddWithValue("@tarjetaCredidto", Dato.Id_TarjetaCredito);
            comando.Parameters.AddWithValue("@iUsuario", Dato.IdUsuarioAdministrador);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Cliente consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Cliente where idCliente=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Cliente Dato = new Cliente();
                Dato.IdCliente = registro.GetByte(0);
                Dato.NIT1 = registro.GetString(1);
                Dato.Nombre1 = registro.GetString(2);
                Dato.Id_TipoEmpresa = registro.GetByte(3);
                Dato.Id_TamanoEmpresa = registro.GetByte(4);
                Dato.Id_TarjetaCredito = registro.GetByte(5);
                Dato.IdUsuarioAdministrador = registro.GetByte(6);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Cliente where idCliente=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Cliente> Listar()
        {
            List<Cliente> Lista = new List<Cliente>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Cliente";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Cliente Dato = new Cliente();
                Dato.IdCliente = registro.GetByte(0);
                Dato.NIT1 = registro.GetString(1);
                Dato.Nombre1 = registro.GetString(2);
                Dato.Id_TipoEmpresa = registro.GetByte(3);
                Dato.Id_TamanoEmpresa = registro.GetByte(4);
                Dato.Id_TarjetaCredito = registro.GetByte(5);
                Dato.IdUsuarioAdministrador = registro.GetByte(6);
                Lista.Add(Dato);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte idCliente, string nit, string Nombre, byte tipoE, byte tamaE, byte tarjetaC, byte idU )
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Cliente set NIT=@nit, Nombre=@Nombre , id_TipoEmpresa=@tipoE , id_TamañoEmpresa=@tamaE, id_TarjetaCredito=@tarjetaC , idUsuarioAdministrador=@idU  where idCliente=@idCliente";
            comando.Parameters.AddWithValue("@nit", nit);
            comando.Parameters.AddWithValue("@Nombre", Nombre);
            comando.Parameters.AddWithValue("@tipoE", tipoE);
            comando.Parameters.AddWithValue("@tamaE", tamaE);
            comando.Parameters.AddWithValue("@tarjetaC", tarjetaC);
            comando.Parameters.AddWithValue("@idU", idU);
            comando.Parameters.AddWithValue("@idCliente", idCliente);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}