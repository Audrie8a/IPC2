﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;


namespace F2_HelloWorld
{
    public class GD_PresentacionProducto
    {
        public SqlConnection conexion;
        public string error;

        public GD_PresentacionProducto() {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(PresentacionProducto Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into PresentacionProducto values (@PresentacionProducto);";            
            comando.Parameters.AddWithValue("@PresentacionProducto", Dato.PresentacionP);            
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public PresentacionProducto consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from PresentacionProducto where idPresentacionProducto=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                PresentacionProducto Dato = new PresentacionProducto();
                Dato.IdPresentacionProducto = registro.GetByte(0);
                Dato.PresentacionP = registro.GetString(1);                
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from PresentacionProducto where idPresentacionProducto=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<PresentacionProducto> Listar()
        {
            List<PresentacionProducto> Lista = new List<PresentacionProducto>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from PresentacionProducto";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                PresentacionProducto Objeto = new PresentacionProducto();
                Objeto.IdPresentacionProducto= registro.GetByte(0);
                Objeto.PresentacionP = registro.GetString(1);                
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idPresentacionProducto, string PresentacionProducto)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update PresentacionProducto set PresentacionProducto=@PresentacionProducto where idPresentacionProducto=@idPresentacionProducto";
            comando.Parameters.AddWithValue("@idPresentacionProducto", idPresentacionProducto);
            comando.Parameters.AddWithValue("@PresentacionProducto", PresentacionProducto);            
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}