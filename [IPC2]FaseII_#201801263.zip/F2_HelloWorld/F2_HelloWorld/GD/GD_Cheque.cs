﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Cheque
    {
        public SqlConnection conexion;
        public string error;
        public GD_Cheque()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Cheque Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Cheque values (@Banco,@cuentaBancaria, @idempleado);";
            comando.Parameters.AddWithValue("@Banco", Dato.Banco1);
            comando.Parameters.AddWithValue("@cuentaBancaria", Dato.CuentaBanco);
            comando.Parameters.AddWithValue("@idempleado", Dato.IdEmpleado);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Cheque consultar(byte ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Cheque where numCheque=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Cheque Dato = new Cheque();
                Dato.NumCheque = registro.GetByte(0);
                Dato.Banco1 = registro.GetString(1);
                Dato.CuentaBanco = registro.GetString(2);
                Dato.IdEmpleado = registro.GetByte(3);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(byte ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Cheque where numCheque=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();

        }

        //Método para mostrar 
        public List<Cheque> Listar()
        {
            List<Cheque> Lista = new List<Cheque>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Cheque";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Cheque Objeto = new Cheque();
                Objeto.NumCheque = registro.GetByte(0);
                Objeto.Banco1 = registro.GetString(1);
                Objeto.CuentaBanco = registro.GetString(2);
                Objeto.IdEmpleado = registro.GetByte(3);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte numCheque, string Banco, string cuentaBancaria, byte idEmpleado)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Cheque set Banco=@Banco,cuentaBancario=@cuentaBancario ,idEmpleadoFirma=@idEmpleado where numCheque=@numCheque";
            comando.Parameters.AddWithValue("@numCheque", numCheque);
            comando.Parameters.AddWithValue("@Banco", Banco);
            comando.Parameters.AddWithValue("@cuentaBancario", cuentaBancaria);
            comando.Parameters.AddWithValue("@idEmpleado", idEmpleado);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}