﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_TarjetaCredito
    {
        public SqlConnection conexion;
        public string error;

        public GD_TarjetaCredito()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(TarjetaCredito Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into TarjetaCredito values (@Nombre, @fechaV, @idTipoT, @CRV);";
            comando.Parameters.AddWithValue("@Nombre", Dato.Nombre1);
            comando.Parameters.AddWithValue("@fechaV", Dato.FechaV);
            comando.Parameters.AddWithValue("@idTipoT", Dato.IdTipoTarjeta);
            comando.Parameters.AddWithValue("@CRV", Dato.CRV1);

            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public TarjetaCredito consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from TarjetaCredito where numTarjeta=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                TarjetaCredito Dato = new TarjetaCredito();
                Dato.NumTarjeta = registro.GetByte(0);
                Dato.Nombre1 = registro.GetString(1); 
                Dato.FechaV = registro.GetDateTime(2);
                Dato.IdTipoTarjeta = registro.GetByte(3);
                Dato.CRV1 = registro.GetString(4);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from TarjetaCredito where numTarjeta=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<TarjetaCredito> Listar()
        {
            List<TarjetaCredito> Lista = new List<TarjetaCredito>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from TarjetaCredito";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                TarjetaCredito Objeto = new TarjetaCredito();
                Objeto.NumTarjeta = registro.GetByte(0);
                Objeto.Nombre1 = registro.GetString(1);
                Objeto.FechaV = registro.GetDateTime(2);
                Objeto.IdTipoTarjeta = registro.GetByte(3);
                Objeto.CRV1 = registro.GetString(4);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int numTarjeta, string Nombre, DateTime fechaV, byte idTipoT, string CRV)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update TarjetaCredito set Nombre=@Nombre, fechaVencimiento=@fechaV, id_TipoTarjeta=@idTipoTarjeta, CRV=@CRV where numTarjeta=@numTarjeta";
            comando.Parameters.AddWithValue("@numTarjeta",numTarjeta );
            comando.Parameters.AddWithValue("@Nombre", Nombre);
            comando.Parameters.AddWithValue("@fechaV", fechaV);
            comando.Parameters.AddWithValue("@idTipoTarjeta", idTipoT);
            comando.Parameters.AddWithValue("@CRV", CRV);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}