﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Modulo_Usuario
    {
        public SqlConnection conexion;
        public string error;

        public GD_Modulo_Usuario()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Modulo_Usuario Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Modulo_Usuario values (@idUsuario,@idPagoSus);";
            comando.Parameters.AddWithValue("@idUsuario", Dato.IdUsuario);
            comando.Parameters.AddWithValue("@idPagoSus", Dato.IdPagoSus);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Modulo_Usuario consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Modulo_Usuario where idMOdulo_Usuario=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Modulo_Usuario Dato = new Modulo_Usuario();
                Dato.IdModulo_Usuario = registro.GetByte(0);
                Dato.IdUsuario = registro.GetByte(1);
                Dato.IdPagoSus = registro.GetByte(2);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Modulo_Usuario where idMOdulo_Usuario=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Modulo_Usuario> Listar()
        {
            List<Modulo_Usuario> Lista = new List<Modulo_Usuario>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Modulo_Usuario";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Modulo_Usuario Objeto = new Modulo_Usuario();
                Objeto.IdModulo_Usuario = registro.GetByte(0);
                Objeto.IdUsuario = registro.GetByte(1);
                Objeto.IdPagoSus= registro.GetByte(2);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte idMU, byte idps, byte idU)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Modulo_Usuario set idUsuario=@idUsuario, idPagoSuscripcion=@idPS where idMOdulo_Usuario=@idModUsuario";
            comando.Parameters.AddWithValue("@idUsuario", idU);
            comando.Parameters.AddWithValue("@idPS", idps);
            comando.Parameters.AddWithValue("@idModUsuario", idMU);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}