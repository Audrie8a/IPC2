﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Comentario
    {
        public SqlConnection conexion;
        public string error;

        public GD_Comentario()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Comentario Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Comentario values (@Comentario, @Autor, @idAnuncio);";
            comando.Parameters.AddWithValue("@Comentario", Dato.Ccomentario1);
            comando.Parameters.AddWithValue("@Autor", Dato.Autro1);
            comando.Parameters.AddWithValue("@idAnuncio", Dato.IdAnuncio);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Comentario consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Comentario where idComentario=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Comentario Dato = new Comentario();
                Dato.IdComentario = registro.GetByte(0);
                Dato.Ccomentario1 = registro.GetString(1); 
                Dato.Autro1 = registro.GetString(2);
                Dato.IdAnuncio = registro.GetByte(3);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Comentario where idComentario=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<Comentario> Listar()
        {
            List<Comentario> Lista = new List<Comentario>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select B.idBlog, B.Descripcion, A.idAnuncio, A.Anuncio, C.idComentario, C.Comentario from Blog as B, Anuncio as A, Comentario as C where A.idBlog=B.idBlog and C.idAnuncio= A.idAnuncio";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Comentario Objeto = new Comentario();
                Objeto.IdBlog = registro.GetByte(0);
                Objeto.Blog1 = registro.GetString(1);
                Objeto.IdAnuncio = registro.GetByte(2);
                Objeto.Anuncio1 = registro.GetString(3);
                Objeto.IdComentario = registro.GetByte(4);
                Objeto.Ccomentario1 = registro.GetString(5);
                
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte idComentario, string Comentario, string Autor, byte idAnuncio)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Comentario set Comentario=@Comentario,Autor=@Autor, idAnuncio=@idAnuncio where idComentario=@idComentario";
            comando.Parameters.AddWithValue("@idComentario", idComentario);
            comando.Parameters.AddWithValue("@Comentario", Comentario);
            comando.Parameters.AddWithValue("@Autor", Autor);
            comando.Parameters.AddWithValue("@idAnuncio", idAnuncio);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }

}