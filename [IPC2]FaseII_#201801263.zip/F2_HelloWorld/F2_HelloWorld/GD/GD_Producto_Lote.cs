﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Producto_Lote
    {
        public SqlConnection conexion;
        public string error;

        public GD_Producto_Lote() {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Producto_Lote Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Producto_Lote values (@idInventario,@idLote, @codigoProducto, @cantidadProducto);";
            comando.Parameters.AddWithValue("@idInventario", Dato.IdInventario);
            comando.Parameters.AddWithValue("@idLote", Dato.IdLote);
            comando.Parameters.AddWithValue("@codigoProducto", Dato.CodigoProducto);
            comando.Parameters.AddWithValue("@cantidadProducto", Dato.CantidadProducto);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Producto_Lote consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Producto_Lote where idProducto_Lote =@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Producto_Lote Dato = new Producto_Lote();
                Dato.IdProducto_Lote= registro.GetByte(0);
                Dato.IdInventario = registro.GetByte(1);
                Dato.IdLote = registro.GetByte(2);
                Dato.CodigoProducto = registro.GetByte(3);
                Dato.CantidadProducto = registro.GetInt32(4);                
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Producto_Lote where idProducto_Lote=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();

        }

        //Método para mostrar 
        public List<Producto_Lote> Listar()
        {
            List<Producto_Lote> Lista = new List<Producto_Lote>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select PL.idProducto_Lote,PL.idInventario,B.idBodega,PL.idLote,PL.codigoProducto,PE.Nombre,PL.cantidadProducto from Producto_Lote as PL,Inventario as I,ProductoEmpresa as PE, Bodega as B where PL.idInventario=I.idInventario and PL.codigoProducto=PE.codigoProducto and I.idInventario=B.idInventario;";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Producto_Lote Objeto = new Producto_Lote();
                Objeto.IdProducto_Lote = registro.GetByte(0);
                Objeto.IdInventario = registro.GetByte(1);
                Objeto.IdBodega = registro.GetByte(2);
                Objeto.IdLote = registro.GetByte(3);
                Objeto.CodigoProducto = registro.GetByte(4);
                Objeto.Producto1 = registro.GetString(5);
                Objeto.CantidadProducto = registro.GetInt32(6);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idProducto_Lote, byte idInventario, byte idLote, byte codigoProducto,
            int cantidadProducto)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Producto_Lote set idInventario=@idInventario,idLote=@idLote,codigoProducto=@codigoProducto,cantidadProducto=@cantidadProducto where idProducto_Lote =@idProducto_Lote ";
            comando.Parameters.AddWithValue("@idProducto_Lote", idProducto_Lote);
            comando.Parameters.AddWithValue("@idInventario", idInventario);
            comando.Parameters.AddWithValue("@idLote", idLote);
            comando.Parameters.AddWithValue("@codigoProducto", codigoProducto);
            comando.Parameters.AddWithValue("@cantidadProducto", cantidadProducto);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}