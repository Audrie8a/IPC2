﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_EmpleadoEmpresa
    {
        public SqlConnection conexion;
        public string error;

        public GD_EmpleadoEmpresa()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(EmpleadoEmpresa Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into EmpleadoEmpres values (@Nombre, @telefono, @idPuesto, @idUsuario);";
            comando.Parameters.AddWithValue("@Nombre", Dato.Nombre1);
            comando.Parameters.AddWithValue("@telefono", Dato.Telefono);
            comando.Parameters.AddWithValue("@idPuesto", Dato.IdPuesto);
            comando.Parameters.AddWithValue("@idUsuario", Dato.IdUsuario);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public EmpleadoEmpresa consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from EmpleadoEmpres where idEmpleado=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                EmpleadoEmpresa Dato = new EmpleadoEmpresa();
                Dato.IdEmpleadoE = registro.GetByte(0);
                Dato.Nombre1 = registro.GetString(1);
                Dato.Telefono = registro.GetString(2);
                Dato.IdPuesto = registro.GetByte(3);
                Dato.IdUsuario = registro.GetByte(4);
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from EmpleadoEmpres where idEmpleado=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para mostrar 
        public List<EmpleadoEmpresa> Listar()
        {
            List<EmpleadoEmpresa> Lista = new List<EmpleadoEmpresa>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from EmpleadoEmpres";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                EmpleadoEmpresa Objeto = new EmpleadoEmpresa();
                Objeto.IdEmpleadoE = registro.GetByte(0);
                Objeto.Nombre1 = registro.GetString(1);
                Objeto.Telefono = registro.GetString(2);
                Objeto.IdPuesto = registro.GetByte(3);
                Objeto.IdUsuario = registro.GetByte(4);
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(byte idEmplead, string Nombre, string telefono, byte idPuesto, byte idUsuario )
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update EmpleadoEmpres set Nombre=@Nombre, telefono=@telefono, idPuesto=@idPuesto, idUsuario=@idUsuario where idEmpleado=@idEmpleado";
            comando.Parameters.AddWithValue("@idEmpleado", idEmplead);
            comando.Parameters.AddWithValue("@Nombre", Nombre);
            comando.Parameters.AddWithValue("@telefono", telefono);
            comando.Parameters.AddWithValue("@idPuesto", idPuesto);
            comando.Parameters.AddWithValue("@idUsuario", idUsuario);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}