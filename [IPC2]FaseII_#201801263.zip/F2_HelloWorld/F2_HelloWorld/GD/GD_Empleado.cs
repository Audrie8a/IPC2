﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace F2_HelloWorld
{
    public class GD_Empleado
    {
        public SqlConnection conexion;
        public string error;

        public GD_Empleado()
        {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        //Método para Agregar a la base de datos
        public bool agregar(Empleado Dato)
        {

            bool agrega = false;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "insert into Empleado values (@Nombre, @Puesto);";
            comando.Parameters.AddWithValue("@Nombre", Dato.Nombre1);
            comando.Parameters.AddWithValue("@Puesto", Dato.Puesto1);
            try
            {
                comando.ExecuteNonQuery();
                agrega = true;
                comando.Parameters.Clear();
            }
            catch (SqlException ex)
            {
                this.error = ex.Message;
            }
            return agrega;
        }

        //Método para consultar 
        public Empleado consultar(int ID)
        {

            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Empleado where idEmpleado=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                Empleado Dato = new Empleado();
                Dato.IdEmpleado = registro.GetByte(0);
                Dato.Nombre1 = registro.GetString(1);
                Dato.Puesto1 = registro.GetString(2);
                
                registro.Close();
                return Dato;

            }
            else
            {
                registro.Close();
                return null;
            }
        }

        //Métodos para Eliminar 
        public void eliminar(int ID)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "delete from Empleado where idEmpleado=@Id";
            comando.Parameters.AddWithValue("@Id", ID);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();

        }

        //Método para mostrar 
        public List<Empleado> Listar()
        {
            List<Empleado> Lista = new List<Empleado>();
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select * from Empleado";
            SqlDataReader registro = comando.ExecuteReader();
            while (registro.Read())
            {
                Empleado Objeto = new Empleado();
                Objeto.IdEmpleado = registro.GetByte(0);
                Objeto.Nombre1 = registro.GetString(1);
                Objeto.Puesto1 = registro.GetString(2);                
                Lista.Add(Objeto);
                comando.Parameters.Clear();
            }
            registro.Close();
            return Lista;
        }

        //Método para Editar
        public void editar(int idEmplead, string Nombre, string Puesto)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "Update Empleado set Nombre=@Nombre,Puesto=@Puesto where idEmpleado=@idEmpleado";
            comando.Parameters.AddWithValue("@idEmpleado", idEmplead);
            comando.Parameters.AddWithValue("@Nombre", Nombre);
            comando.Parameters.AddWithValue("@Puesto", Puesto);
            comando.ExecuteNonQuery();
            comando.Parameters.Clear();
        }

        //Método para llamar datos existentes
        public DataSet Consultar(string Consulta)
        {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = Consulta;
            SqlDataAdapter DA = new SqlDataAdapter(comando);
            DataSet ds = new DataSet();
            DA.Fill(ds);
            //comando.Connection.Close();
            return ds;
        }
    }
}