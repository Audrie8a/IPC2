﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWAccesoUsuario : System.Web.UI.Page
    {
        GD_AccesoUsuario AccesoUsuario = new GD_AccesoUsuario();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                AccesoUsuario Objeto = new AccesoUsuario();
                Objeto.IdPermisoUsuario = Convert.ToByte(DDLpermisoUsuario.Text);
                Objeto.IdUsuario = Convert.ToByte(DDLidUsuario.Text);
                Objeto.CodigoModulo = Convert.ToByte(DDLcodigoModulo.Text);

                if (DDLcodigoModulo.SelectedIndex!=0 && DDLidUsuario.SelectedIndex != 0 && DDLpermisoUsuario.SelectedIndex != 0)
                {
                    bool agregado = AccesoUsuario.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "AccesoUsuario Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += AccesoUsuario.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte la AccesoUsuario a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    byte idPermisoU = Convert.ToByte(DDLpermisoUsuario.Text);
                    byte idUsuario = Convert.ToByte(DDLidUsuario.Text);
                    byte codigoMod= Convert.ToByte(DDLcodigoModulo.Text);

                    AccesoUsuario.editar(identificacion, idPermisoU,idUsuario,codigoMod);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    AccesoUsuario.eliminar(identificacion);
                    lblMensaje.Text = "AccesoUsuario Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de AccesoUsuario a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de AccesoUsuario a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                AccesoUsuario objeto = AccesoUsuario.consultar(identificacion);
                if (objeto != null)
                {
                    DDLcodigoModulo.Text =Convert.ToString(objeto.CodigoModulo);
                    DDLidUsuario.Text = Convert.ToString(objeto.IdUsuario);
                    DDLpermisoUsuario.Text = Convert.ToString(objeto.IdPermisoUsuario);
                    lblMensaje.Text = "AccesoUsuario consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay AccesoUsuario agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de AccesoUsuario a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<AccesoUsuario> Lista = AccesoUsuario.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay AccesoUsuario agregados en la base de datos";
            }
            else
            {
                gvAccesoUsuario.DataSource = Lista;
                gvAccesoUsuario.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = AccesoUsuario.Consultar("Select idAccesoUsuario from AccesoUsuario");
            DDLidentificacion.DataTextField = "idAccesoUsuario";
            DDLidentificacion.DataValueField = "idAccesoUsuario";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLpermisoUsuario.DataSource = AccesoUsuario.Consultar("Select idPermisoUsuario, Permiso from PermisoUsuario");
            DDLpermisoUsuario.DataTextField = "Permiso";
            DDLpermisoUsuario.DataValueField = "idPermisoUsuario";
            DDLpermisoUsuario.DataBind();
            DDLpermisoUsuario.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLidUsuario.DataSource = AccesoUsuario.Consultar("Select idUsuario from Usuario");
            DDLidUsuario.DataTextField = "idUsuario";
            DDLidUsuario.DataValueField = "idUsuario";
            DDLidUsuario.DataBind();
            DDLidUsuario.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLcodigoModulo.DataSource = AccesoUsuario.Consultar("Select codigoModulo, Nombre from Modulo");
            DDLcodigoModulo.DataTextField = "Nombre";
            DDLcodigoModulo.DataValueField = "codigoModulo";
            DDLcodigoModulo.DataBind();
            DDLcodigoModulo.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }
    }
}