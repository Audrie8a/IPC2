﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWAnuncio : System.Web.UI.Page
    {
        GD_Anuncio Anuncio = new GD_Anuncio();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Anuncio Objeto = new Anuncio();
                Objeto.IdBlog = Convert.ToByte(DDLanuncio.Text);
                Objeto.Anuncios1 = txtAnuncio.Text;
                Objeto.Autor1 = txtAutor.Text;

                if (txtAnuncio.Text != null && txtAutor.Text != null && DDLanuncio.SelectedIndex!=0)
                {
                    bool agregado = Anuncio.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Anuncio Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Anuncio.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte Anuncio a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    byte idBlog = Convert.ToByte(DDLanuncio.Text);
                    string Anuncios = txtAnuncio.Text;
                    string Autor = txtAutor.Text;

                    Anuncio.editar(identificacion, idBlog,Anuncios, Autor);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Anuncio.eliminar(identificacion);
                    lblMensaje.Text = "Anuncio Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación Anuncio a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación Anuncio a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Anuncio objeto = Anuncio.consultar(identificacion);
                if (objeto != null)
                {
                    DDLanuncio.Text = Convert.ToString(objeto.IdBlog);
                    txtAnuncio.Text = objeto.Anuncios1;
                    txtAutor.Text = objeto.Autor1;
                    lblMensaje.Text = "Anuncio consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Anuncios agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación Anuncio a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Anuncio> Lista = Anuncio.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Anuncios agregados en la base de datos";
            }
            else
            {
                gvAnuncio.DataSource = Lista;
                gvAnuncio.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtAutor.Text = "";
            txtAnuncio.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = Anuncio.Consultar("Select idAnuncio from Anuncio");
            DDLidentificacion.DataTextField = "idAnuncio";
            DDLidentificacion.DataValueField = "idAnuncio";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));

            //Datos idPresentacionProducto
            DDLanuncio.DataSource = Anuncio.Consultar("Select idBlog from Blog");
            DDLanuncio.DataTextField = "idBlog";
            DDLanuncio.DataValueField = "idBlog";
            DDLanuncio.DataBind();
            DDLanuncio.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }
    }
}