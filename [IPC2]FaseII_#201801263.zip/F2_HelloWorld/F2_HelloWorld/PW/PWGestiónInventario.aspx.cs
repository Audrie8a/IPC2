﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWGestiónInventario : System.Web.UI.Page
    {
        GD_Producto_Lote Producto_Lote = new GD_Producto_Lote();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Producto_Lote Objeto = new Producto_Lote();
                Objeto.IdInventario =Convert.ToByte( DDLinventario.Text);
                Objeto.IdLote = Convert.ToByte(DDLlote.Text);
                Objeto.CodigoProducto = Convert.ToByte(DDLproducto.Text);
                Objeto.CantidadProducto= Convert.ToInt32(txtCantidadProducto.Text);

                if (txtCantidadProducto.Text != null && DDLinventario.SelectedIndex !=0 && DDLlote.SelectedIndex !=0 && DDLproducto.SelectedIndex !=0)
                {
                    bool agregado = Producto_Lote.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Información Inventario Agregada Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Producto_Lote.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte la información de Inventario a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    int cantidadProducto = Convert.ToInt32(txtCantidadProducto.Text);
                    byte idInventario =Convert.ToByte( DDLinventario.Text);
                    byte idLote = Convert.ToByte(DDLlote.Text);
                    byte codigoProducto = Convert.ToByte(DDLproducto.Text);

                    Producto_Lote.editar(identificacion, idInventario, idLote, codigoProducto, cantidadProducto);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Producto_Lote.eliminar(identificacion);
                    lblMensaje.Text = "Información Inventario Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de la Información Inventario a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de la Información Inventario a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {           
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Producto_Lote objeto = Producto_Lote.consultar(identificacion);
                if (objeto != null)
                {                    
                    DDLinventario.Text = Convert.ToString(objeto.IdInventario);
                    DDLlote.Text = Convert.ToString(objeto.IdLote);                    
                    txtCantidadProducto.Text = Convert.ToString(objeto.CantidadProducto);
                    DDLproducto.Text = Convert.ToString(objeto.CodigoProducto);
                    lblMensaje.Text = "Información Inventario consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Información Inventario agregadas a la base de datos";
                }
            }
            catch (Exception ex) { lblMensaje.Text +=ex+ "Favor seleccionar la identificación de la Información Inventario  a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Producto_Lote> Lista = Producto_Lote.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Información Inventario agregados en la base de datos";
            }
            else
            {
                gvGestionInventario.DataSource = Lista;
                gvGestionInventario.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtCantidadProducto.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idProducto_Lote
            DDLidentificacion.DataSource = Producto_Lote.Consultar("Select idProducto_Lote from Producto_Lote");
            DDLidentificacion.DataTextField = "idProducto_Lote";
            DDLidentificacion.DataValueField = "idProducto_Lote";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación Información Inventario]", "0"));

            //Datos idInventario
            DDLinventario.DataSource = Producto_Lote.Consultar("Select idInventario from Inventario");
            DDLinventario.DataTextField = "idInventario";
            DDLinventario.DataValueField = "idInventario";
            DDLinventario.DataBind();
            DDLinventario.Items.Insert(0, new ListItem("[Seleccionar identificación Información Inventario]", "0"));

            //Datos idLote
            DDLlote.DataSource = Producto_Lote.Consultar("Select idLote from Lote");
            DDLlote.DataTextField = "idLote";
            DDLlote.DataValueField = "idLote";
            DDLlote.DataBind();
            DDLlote.Items.Insert(0, new ListItem("[Seleccionar identificación Información Inventario]", "0"));

            //Datos codigoProducto
            DDLproducto.DataSource = Producto_Lote.Consultar("Select codigoProducto, Nombre from ProductoEmpresa");
            DDLproducto.DataTextField = "Nombre";
            DDLproducto.DataValueField = "codigoProducto";
            DDLproducto.DataBind();
            DDLproducto.Items.Insert(0, new ListItem("[Seleccionar identificación Información Inventario]", "0"));
        }

        protected void Button3_Click(object sender, EventArgs e)
        {

        }

        protected void btnInventario_Click(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWInventario.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWLote.aspx");
        }

        protected void Button3_Click1(object sender, EventArgs e)
        {
            Response.Redirect("PWBodega.aspx");

        }
    }
}