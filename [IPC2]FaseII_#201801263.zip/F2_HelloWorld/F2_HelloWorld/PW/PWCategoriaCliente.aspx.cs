﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld.PW
{
    public partial class PWCategoriaCliente : System.Web.UI.Page
    {
        GD_CategoriaCliente CategoriaCliente = new GD_CategoriaCliente();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminarCC.Enabled = false;
                btnEditarCC.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

     
        protected void Button1_Click(object sender, EventArgs e)
        {
            
        }

        //Método para limpiar
        private void limpiar()
        {
            txtAbrevCatCliente.Text = "";
            txtDescripCatCliente.Text = "";            
            lblMensaje.Text = "RESULTADO: ";
        }

        //Metodo para listaCategorias

        public void ListaCategoriaCliente()
        {
            List<CategoriaCliente> lstClienteEmpresa = CategoriaCliente.lstCategoriaClientes();
            if (lstClienteEmpresa.Count == 0)
            {
                lblMensaje.Text += "No hay Categorias agregadas en la base de datos";
            }
            else
            {
                gvCatCliente.DataSource = lstClienteEmpresa;
                gvCatCliente.DataBind();
            }
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {

            //Datos CategoriaCliente
            DDLidentificacionCategoriaCliente.DataSource = CategoriaCliente.Consultar("Select codigoCategoria, Abreviatura from CategoriaCliente");
            DDLidentificacionCategoriaCliente.DataTextField = "codigoCategoria";
            DDLidentificacionCategoriaCliente.DataValueField = "codigoCategoria";
            DDLidentificacionCategoriaCliente.DataBind();
            DDLidentificacionCategoriaCliente.Items.Insert(0, new ListItem("[Seleccionar]", "0"));

           
        }

        protected void btnListarCE_Click(object sender, EventArgs e)
        {
                     
        }

        //Botón para agregar Categorias
        protected void btnAgregarCC2_Click(object sender, EventArgs e)
        {
            try
            {
                CategoriaCliente CatCliente = new CategoriaCliente();
                CatCliente.Abreviatura1 = txtAbrevCatCliente.Text;
                CatCliente.Descripcion1 = txtDescripCatCliente.Text;

                if (txtAbrevCatCliente.Text != null && txtDescripCatCliente.Text != null)
                {
                    bool agregado = CategoriaCliente.agregarCategoriaCliente(CatCliente);
                    if (agregado)
                    {
                        lblMensaje.Text += "Categoría Agregada Exitosamente";
                        limpiar();
                        ListaCategoriaCliente();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += CategoriaCliente.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        //Botón para Editar
        protected void btnEditarCC_Click(object sender, EventArgs e)
        {
            if (DDLidentificacionCategoriaCliente.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte la Categoria a Editar";
            }
            else
            {
                try
                {
                   



                    byte identificacion = Convert.ToByte(DDLidentificacionCategoriaCliente.Text);
                    string Abreviatura = txtAbrevCatCliente.Text;
                    string Descripcion = txtDescripCatCliente.Text;
                    


                    CategoriaCliente.editarCategoriaCliente(identificacion, Abreviatura, Descripcion);
                    ListaCategoriaCliente();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnListarCC_Click(object sender, EventArgs e)
        {
            ListaCategoriaCliente();
        }

        //Método para consultar Categorias
        public void ConsultarCategoria()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacionCategoriaCliente.Text);

                CategoriaCliente cliente = CategoriaCliente.consultarCategoriaCliente(identificacion);
                if (cliente != null)
                {
                    txtAbrevCatCliente.Text = cliente.Abreviatura1;
                    txtDescripCatCliente.Text = cliente.Descripcion1;                    
                    lblMensaje.Text = "Categoría consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay categorias agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación la Catgoria a buscar"; }
        }

        protected void btnConsultarCC_Click(object sender, EventArgs e)
        {
            ConsultarCategoria();
            btnEditarCC.Enabled = true;
            btnEliminarCC.Enabled = true;
        }

        protected void btnEliminarCC_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacionCategoriaCliente.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacionCategoriaCliente.Text);


                    CategoriaCliente.eliminarCategoriaCliente(identificacion);
                    lblMensaje.Text = "Categoria Eliminado exitosamente";
                    ListaCategoriaCliente();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de la Categoría a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de la Categoría a eliminar"; }
        }
    }
}