﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWFacturacion : System.Web.UI.Page
    {
        GD_Facturacion Facturacion = new GD_Facturacion();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Facturacion Objeto = new Facturacion();
                Objeto.IdClienteE=Convert.ToByte( DDLcliente.Text);
                Objeto.IdVendedor= Convert.ToByte(DDLvendedor.Text);

                if (DDLcliente.SelectedIndex != 0 && DDLvendedor.SelectedIndex != 0)
                {
                    bool agregado = Facturacion.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Facturacion Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Facturacion.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte Facturacion a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    byte idClienteE = Convert.ToByte(DDLcliente.Text);
                    byte idVendedor = Convert.ToByte(DDLvendedor.Text);

                    Facturacion.editar(identificacion, idClienteE, idVendedor);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Facturacion.eliminar(identificacion);
                    lblMensaje.Text = "Facturacion Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de Facturacion a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de Facturacion a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Facturacion objeto = Facturacion.consultar(identificacion);
                if (objeto != null)
                {
                    DDLcliente.Text =Convert.ToString(objeto.IdClienteE);
                    DDLvendedor.Text = Convert.ToString(objeto.IdVendedor);
                    lblMensaje.Text = "Facturacion consultada";
                }
                else
                {
                    lblMensaje.Text = "No hay Facturacion agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de la Facturacion a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Facturacion> Lista = Facturacion.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Facturacion  agregadas en la base de datos";
            }
            else
            {
                gvFacturacion.DataSource = Lista;
                gvFacturacion.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idFacturacion
            DDLidentificacion.DataSource = Facturacion.Consultar("Select idFacturacion from Facturacion");
            DDLidentificacion.DataTextField = "idFacturacion";
            DDLidentificacion.DataValueField = "idFacturacion";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación Facturacion]", "0"));

            //Datos idVendedor
            DDLvendedor.DataSource = Facturacion.Consultar("select idEmpleado, Nombre from Vendedor");
            DDLvendedor.DataTextField = "Nombre";
            DDLvendedor.DataValueField = "idEmpleado";
            DDLvendedor.DataBind();
            DDLvendedor.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));

            //Datos idCliente
            DDLcliente.DataSource = Facturacion.Consultar("Select idClienteE, Nombre from ClienteEmpresa");
            DDLcliente.DataTextField = "Nombre";
            DDLcliente.DataValueField = "idClienteE";
            DDLcliente.DataBind();
            DDLcliente.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));


        }
    }
}