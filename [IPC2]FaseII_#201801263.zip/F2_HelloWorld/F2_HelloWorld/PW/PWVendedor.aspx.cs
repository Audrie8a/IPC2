﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWVendedor : System.Web.UI.Page
    {
        GD_Vendedor Vendedor = new GD_Vendedor();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Listar();
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Vendedor Objeto = new Vendedor();
                Objeto.Nombre1 = txtNombre.Text;

                if (txtNombre.Text != null)
                {
                    bool agregado = Vendedor.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Vendedor Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Vendedor.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte el Vendedor a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string Nombre = txtNombre.Text;

                    Vendedor.editar(identificacion, Nombre);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Vendedor.eliminar(identificacion);
                    lblMensaje.Text = "Vendedor Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación del Vendedor a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación del Vendedor a eliminar"; }
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Vendedor objeto = Vendedor.consultar(identificacion);
                if (objeto != null)
                {
                    txtNombre.Text = objeto.Nombre1;
                    lblMensaje.Text = "Vendedor consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Vendedores agregados a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación del Vendedor a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Vendedor> Lista = Vendedor.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Vendedores agregados en la base de datos";
            }
            else
            {
                gvVendedor.DataSource = Lista;
                gvVendedor.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtNombre.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idEmpleado
            DDLidentificacion.DataSource = Vendedor.Consultar("Select idEmpleado from Vendedor");
            DDLidentificacion.DataTextField = "idEmpleado";
            DDLidentificacion.DataValueField = "idEmpleado";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación Vendedor]", "0"));
        }

    }
}