﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWTipoTarjeta : System.Web.UI.Page
    {
        GD_TipoTarjeta TipoTarjeta = new GD_TipoTarjeta();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                TipoTarjeta Objeto = new TipoTarjeta();
                Objeto.TipoT1 = txtTipoT.Text;

                if (txtTipoT.Text != null)
                {
                    bool agregado = TipoTarjeta.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "TipoTarjeta Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += TipoTarjeta.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte TipoTarjeta a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string TipoT = txtTipoT.Text;

                    TipoTarjeta.editar(identificacion, TipoT);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    TipoTarjeta.eliminar(identificacion);
                    lblMensaje.Text = "TipoTarjeta Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación TipoTarjeta a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación TipoTarjeta a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }
        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                TipoTarjeta objeto = TipoTarjeta.consultar(identificacion);
                if (objeto != null)
                {
                    txtTipoT.Text = objeto.TipoT1;
                    lblMensaje.Text = "TipoTarjeta consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay TipoTarjeta agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de TipoTarjeta a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<TipoTarjeta> Lista = TipoTarjeta.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay TipoTarjeta agregados en la base de datos";
            }
            else
            {
                gvTipoTarjeta.DataSource = Lista;
                gvTipoTarjeta.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtTipoT.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = TipoTarjeta.Consultar("Select idTipoTarjeta from TipoTarjeta");
            DDLidentificacion.DataTextField = "idTipoTarjeta";
            DDLidentificacion.DataValueField = "idTipoTarjeta";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }
    }
}