﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWLote : System.Web.UI.Page
    {
        GD_Lote Lote = new GD_Lote();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Lote Objeto = new Lote();
                Objeto.LoteN1 = txtLote.Text;
                Objeto.IdTipoLogica =Convert.ToByte(DDLtipoLogica.Text);
                Objeto.IdBodega = Convert.ToByte( DDLbodega.Text);

                if (txtLote.Text != null && DDLtipoLogica.SelectedIndex !=0 && DDLbodega.SelectedIndex !=0)
                {
                    bool agregado = Lote.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Lote Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Lote.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte el Lote a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string lote = txtLote.Text;
                    byte TipoLogica = Convert.ToByte(DDLtipoLogica.Text);
                    byte Bodega = Convert.ToByte(DDLbodega.Text);

                    Lote.editar(identificacion, lote, TipoLogica,Bodega);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Lote.eliminar(identificacion);
                    lblMensaje.Text = "Lote Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación del Lote a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación del Lote a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Lote objeto = Lote.consultar(identificacion);
                if (objeto != null)
                {
                    txtLote.Text = objeto.LoteN1;
                    DDLtipoLogica.Text = Convert.ToString (objeto.IdTipoLogica);
                    DDLbodega.Text = Convert.ToString(objeto.IdBodega);
                    lblMensaje.Text = "Lote consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Lotes agregados a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación del Lote a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Lote> Lista = Lote.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Lotes agregados en la base de datos";
            }
            else
            {
                gvLote.DataSource = Lista;
                gvLote.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtLote.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idLote
            DDLidentificacion.DataSource = Lote.Consultar("Select idLote from Lote");
            DDLidentificacion.DataTextField = "idLote";
            DDLidentificacion.DataValueField = "idLote";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación Lote]", "0"));

            //Datos idTipoLogica
            DDLtipoLogica.DataSource = Lote.Consultar("Select idTipoLogica, TipoLogica from TipoLogica");
            DDLtipoLogica.DataTextField = "TipoLogica";
            DDLtipoLogica.DataValueField = "idTipoLogica";
            DDLtipoLogica.DataBind();
            DDLtipoLogica.Items.Insert(0, new ListItem("[Seleccionar Tipo Lógica]", "0"));

            //Datos idBodega
            DDLbodega.DataSource = Lote.Consultar("Select idBodega, Bodega from Bodega");
            DDLbodega.DataTextField = "idBodega";
            DDLbodega.DataValueField = "idBodega";
            DDLbodega.DataBind();
            DDLbodega.Items.Insert(0, new ListItem("[Seleccionar Bodega]", "0"));
        }
    }
}