﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWRegistroPedido : System.Web.UI.Page
    {
        GD_RegistroPedido RegistroPedido = new GD_RegistroPedido();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                RegistroPedido Objeto = new RegistroPedido();

                Objeto.IdPedido = Convert.ToByte(DDLPedido.Text);
                Objeto.CodigoProducto = Convert.ToByte(DDLProducto.Text);

                if (DDLPedido.SelectedIndex!=0 && DDLProducto.SelectedIndex!=0)
                {
                    bool agregado = RegistroPedido.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Registro Pedido Agregada Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += RegistroPedido.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception ex)
            {
                lblMensaje.Text += ex + "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLIdentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte el Registro Pedido a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLIdentificacion.Text);
                    byte idPedido =Convert.ToByte(DDLPedido.Text);
                    byte codigoProducto= Convert.ToByte(DDLProducto.Text);
                    int MontoTotal=0;

                    RegistroPedido.editar(identificacion, idPedido,codigoProducto,MontoTotal);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLIdentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLIdentificacion.Text);


                    RegistroPedido.eliminar(identificacion);
                    lblMensaje.Text = "Registro Pedido Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación del Registro a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación del Registro a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }
        
        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLIdentificacion.Text);

                RegistroPedido objeto = RegistroPedido.consultar(identificacion);
                if (objeto != null)
                {
                    DDLPedido.Text = Convert.ToString(objeto.IdPedido);
                    DDLProducto.Text = Convert.ToString(objeto.CodigoProducto);
                    lblMontoTotal.Text = Convert.ToString(objeto.MontoTotal1);
                    lblMensaje.Text = "Registro Pedido consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Registro Pedidos agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación del Registro del Pedido a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<RegistroPedido> Lista = RegistroPedido.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Registro Pedidos agregados en la base de datos";
            }
            else
            {
                gvGestionCompras.DataSource = Lista;
                gvGestionCompras.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            lblMensaje.Text = "RESULTADO: ";
            lblMontoTotal.Text = "";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLIdentificacion.DataSource = RegistroPedido.Consultar("Select idRegistroPedido from RegistroPedido");
            DDLIdentificacion.DataTextField = "idRegistroPedido";
            DDLIdentificacion.DataValueField = "idRegistroPedido";
            DDLIdentificacion.DataBind();
            DDLIdentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));

            
            //Datos idPresentacionProducto
            DDLPedido.DataSource = RegistroPedido.Consultar("Select idPedido from Pedido");
            DDLPedido.DataTextField = "idPedido";
            DDLPedido.DataValueField = "idPedido";
            DDLPedido.DataBind();
            DDLPedido.Items.Insert(0, new ListItem("[Seleccionar identificación Producto ]", "0"));

            //Datos idPresentacionProducto
            DDLProducto.DataSource = RegistroPedido.Consultar("Select codigoProducto, Nombre from ProductoEmpresa");
            DDLProducto.DataTextField = "Nombre";
            DDLProducto.DataValueField = "codigoProducto";
            DDLProducto.DataBind();
            DDLProducto.Items.Insert(0, new ListItem("[Seleccionar identificación Pedido ]", "0"));


        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWPedido.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWProveedorEmpresa.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWProductoEmpresa.aspx");
        }
    }
}