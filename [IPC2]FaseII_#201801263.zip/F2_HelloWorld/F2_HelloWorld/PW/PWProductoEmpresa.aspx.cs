﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWProductoEmpresa : System.Web.UI.Page
    {
        GD_ProductoEmpresa ProductoEmpresa = new GD_ProductoEmpresa();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        //Botón Agregar
        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                ProductoEmpresa Objeto = new ProductoEmpresa();
                Objeto.CodigoBarra= txtCodigoBarra.Text;
                Objeto.Nombre1 = txtNombre.Text;
                Objeto.Descripcion1 = txtDescripcion.Text;
                Objeto.IdPresentacionproducto = Convert.ToByte(DDLPresentacionProducto.Text);
                Objeto.IdclasificacionProducto= Convert.ToByte(DDLClasificacionProducto.Text);
                Objeto.IdeEstadoProducto= Convert.ToByte(DDLPresentacionProducto.Text);
                Objeto.Precio1 = Convert.ToInt32(txtPrecio.Text);                


                if (txtCodigoBarra.Text != null && txtNombre.Text != null && txtDescripcion.Text != null && DDLPresentacionProducto.SelectedIndex !=0 && DDLClasificacionProducto.SelectedIndex!= 0
                    && DDlEstadoProducto.SelectedIndex!= 0 && txtPrecio.Text != null )
                {
                    bool agregado = ProductoEmpresa.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Producto Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += ProductoEmpresa.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        //Botón Consultar
        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        //Botón Editar
        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLcodigoP.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte el Producto a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLcodigoP.Text);
                    string codigoBarra = txtCodigoBarra.Text;
                    string NOMBRE = txtNombre.Text;
                    string Descripcion = txtDescripcion.Text;
                    byte idPresentacionP = Convert.ToByte(DDLPresentacionProducto.Text);
                    byte idclasificaconP = Convert.ToByte(DDLClasificacionProducto.Text);
                    byte idEstadoP = Convert.ToByte(DDlEstadoProducto.Text);
                    int Precio = Convert.ToInt32(txtPrecio.Text);
                    

                    ProductoEmpresa.editar(identificacion, codigoBarra, NOMBRE, Descripcion, idPresentacionP, idclasificaconP, idEstadoP, Precio);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        //Botón Eliminar
         protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLcodigoP.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLcodigoP.Text);


                    ProductoEmpresa.eliminar(identificacion);
                    lblMensaje.Text = "Producto Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar el código del Producto a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar el código del Producto a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLcodigoP.Text);

                ProductoEmpresa objeto = ProductoEmpresa.consultar(identificacion);
                if (objeto != null)
                {
                    txtCodigoBarra.Text = objeto.CodigoBarra;
                    txtNombre.Text = objeto.Nombre1;
                    txtDescripcion.Text = objeto.Descripcion1;
                    DDLPresentacionProducto.Text = Convert.ToString(objeto.IdPresentacionproducto);
                    DDLClasificacionProducto.Text = Convert.ToString(objeto.IdclasificacionProducto);
                    DDlEstadoProducto.Text = Convert.ToString(objeto.IdeEstadoProducto);
                    txtPrecio.Text =Convert.ToString(objeto.Precio1);
                    
                    lblMensaje.Text = "Producto consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Productos agregados a la base de datos con ese código";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar el código del producto a buscar"; }
        }

        //Metodo para listaProducto
        public void Listar()
        {
            List<ProductoEmpresa> Lista = ProductoEmpresa.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Productos agregados en la base de datos";
            }
            else
            {
                gvProductos.DataSource = Lista;
                gvProductos.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtCodigoBarra.Text = "";
            txtNombre.Text = "";
            txtDescripcion.Text = "";
            txtPrecio.Text = "";            
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos Presentación Producto
            DDLPresentacionProducto.DataSource = ProductoEmpresa.Consultar("Select idPresentacionProducto, PresentacionProducto from PresentacionProducto");
            DDLPresentacionProducto.DataTextField = "PresentacionProducto";
            DDLPresentacionProducto.DataValueField = "idPresentacionProducto";
            DDLPresentacionProducto.DataBind();
            DDLPresentacionProducto.Items.Insert(0, new ListItem("[Seleccionar]", "0"));


            //Datos ClasificacionProducto
            DDLClasificacionProducto.DataSource = ProductoEmpresa.Consultar("Select idClasificacionProducto, ClasificacionProducto from ClasificacionProducto");
            DDLClasificacionProducto.DataTextField = "ClasificacionProducto";
            DDLClasificacionProducto.DataValueField = "idClasificacionProducto";
            DDLClasificacionProducto.DataBind();
            DDLClasificacionProducto.Items.Insert(0, new ListItem("[Seleccionar identificación Cliente]", "0"));

            //Datos EstadoProducto
            DDlEstadoProducto.DataSource = ProductoEmpresa.Consultar("Select idEstadoProducto, EstadoProducto from EstadoProducto");
            DDlEstadoProducto.DataTextField = "EstadoProducto";
            DDlEstadoProducto.DataValueField = "idEstadoProducto";
            DDlEstadoProducto.DataBind();
            DDlEstadoProducto.Items.Insert(0, new ListItem("[Seleccionar]", "0"));


            //Datos codigoProducto
            DDLcodigoP.DataSource = ProductoEmpresa.Consultar("Select codigoProducto from ProductoEmpresa");
            DDLcodigoP.DataTextField = "codigoProducto";
            DDLcodigoP.DataValueField = "codigoProducto";
            DDLcodigoP.DataBind();
            DDLcodigoP.Items.Insert(0, new ListItem("[Seleccionar identificación Cliente]", "0"));
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWClasificacionProducto.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWPresentacionProducto.aspx");
        }
    }
}