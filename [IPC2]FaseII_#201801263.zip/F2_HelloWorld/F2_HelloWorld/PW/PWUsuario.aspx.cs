﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWUsuario : System.Web.UI.Page
    {
        GD_Usuario Usuario = new GD_Usuario();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Usuario Objeto = new Usuario();
                Objeto.Password = txtPassword.Text;
                Objeto.IdContacto = Convert.ToByte(DDLidContacto.Text);
                Objeto.Nombre1 =txtNombre.Text;
                Objeto.Correo1 =txtCorreo.Text;
                Objeto.Celular1 =txtCelular.Text;
                Objeto.Puesto1 =txtPuesto.Text;
                Objeto.IdTipoUsuario =Convert.ToByte(DDLtipoUsuario.Text);

                if (txtCelular.Text != null && txtCorreo.Text != null && txtNombre.Text != null && txtPassword.Text != null &&txtPuesto.Text != null  && DDLtipoUsuario.SelectedIndex!=0)
                {
                    
                    bool agregado = Usuario.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Usuario Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Usuario.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte Usuario a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string Password = txtPassword.Text;
                    byte IdContacto = Convert.ToByte(DDLidContacto.Text);
                    string Nombre1 = txtNombre.Text;
                    string Correo1 = txtCorreo.Text;
                    string Celular1 = txtCelular.Text;
                    string Puesto1 = txtPuesto.Text;
                    byte IdTipoUsuario = Convert.ToByte(DDLtipoUsuario.Text);

                    Usuario.editar(identificacion, Password,IdContacto,Nombre1, Correo1, Celular1,Puesto1, IdTipoUsuario);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Usuario.eliminar(identificacion);
                    lblMensaje.Text = "Usuario Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de Usuario a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de Usuarioo a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Usuario objeto = Usuario.consultar(identificacion);
                if (objeto != null)
                {
                    txtPassword.Text=objeto.Password;
                    DDLidContacto.Text = Convert.ToString(objeto.IdContacto);
                    txtNombre.Text=objeto.Nombre1;
                    txtCorreo.Text=objeto.Correo1;
                    txtCelular.Text=objeto.Celular1;
                    txtPuesto.Text=objeto.Puesto1;
                    DDLtipoUsuario.Text=Convert.ToString(objeto.IdTipoUsuario);
                    lblMensaje.Text = "Usuario consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Usuario agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de Usuario a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Usuario> Lista = Usuario.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Presentaciones del Producto agregados en la base de datos";
            }
            else
            {
                gvUsuario.DataSource = Lista;
                gvUsuario.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtCelular.Text = "";
            txtCorreo.Text = "";
            txtNombre.Text = "";
            txtPassword.Text = "";
            txtPuesto.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = Usuario.Consultar("Select idUsuario from Usuario");
            DDLidentificacion.DataTextField = "idUsuario";
            DDLidentificacion.DataValueField = "idUsuario";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLidContacto.DataSource = Usuario.Consultar("Select idContacto,Nombre from Contacto");
            DDLidContacto.DataTextField = "Nombre";
            DDLidContacto.DataValueField = "idContacto";
            DDLidContacto.DataBind();
            DDLidContacto.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLtipoUsuario.DataSource = Usuario.Consultar("Select idTipoUsuario, TipoUsuario from TipoUsuario");
            DDLtipoUsuario.DataTextField = "TipoUsuario";
            DDLtipoUsuario.DataValueField = "idTipoUsuario";
            DDLtipoUsuario.DataBind();
            DDLtipoUsuario.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }
    }
}