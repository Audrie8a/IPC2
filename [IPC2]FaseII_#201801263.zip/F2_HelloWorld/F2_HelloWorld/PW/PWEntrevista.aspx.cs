﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWEntrevista : System.Web.UI.Page
    {
        GD_Entrevista Entrevista = new GD_Entrevista();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Entrevista Objeto = new Entrevista();
                Objeto.Fecha1 = Cfecha.SelectedDate;
                Objeto.IdSolicitante = Convert.ToByte(DDLsolicitante.Text);
                Objeto.IdEstadoEntrevista = Convert.ToByte(DDLestadoEntrevista.Text);

                if (DDLestadoEntrevista.SelectedIndex != 0 && DDLsolicitante.SelectedIndex!=0)
                {
                    bool agregado = Entrevista.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Entrevista Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Entrevista.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {

            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte la Entrevista a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    DateTime fecha= Cfecha.SelectedDate;
                    byte idSolicitante = Convert.ToByte(DDLsolicitante.Text);
                    byte idEstadoEntrevista = Convert.ToByte(DDLestadoEntrevista.Text);

                    Entrevista.editar(identificacion, fecha,idSolicitante,idEstadoEntrevista);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Entrevista.eliminar(identificacion);
                    lblMensaje.Text = "Entrevista Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de laEntrevista a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de la Entrevista a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Entrevista objeto = Entrevista.consultar(identificacion);
                if (objeto != null)
                {
                    Cfecha.SelectedDate = objeto.Fecha1;
                    DDLsolicitante.Text = Convert.ToString(objeto.IdSolicitante);
                    DDLestadoEntrevista.Text = Convert.ToString(objeto.IdEstadoEntrevista);
                    lblMensaje.Text = "Entrevista consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Entrevistas agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de la Entrevista a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Entrevista> Lista = Entrevista.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Entrevistas agregados en la base de datos";
            }
            else
            {
                gvEntrevista.DataSource = Lista;
                gvEntrevista.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = Entrevista.Consultar("Select idEntrevista from Entrevista");
            DDLidentificacion.DataTextField = "idEntrevista";
            DDLidentificacion.DataValueField = "idEntrevista";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));

            //Datos idPresentacionProducto
            DDLsolicitante.DataSource = Entrevista.Consultar("Select idSolicitante, Nombre from Solicitante");
            DDLsolicitante.DataTextField = "Nombre";
            DDLsolicitante.DataValueField = "idSolicitante";
            DDLsolicitante.DataBind();
            DDLsolicitante.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));

            //Datos idPresentacionProducto
            DDLestadoEntrevista.DataSource = Entrevista.Consultar("Select idEstadoEntrevista, EstadoEntrevista from EstadoEntrevista");
            DDLestadoEntrevista.DataTextField = "EstadoEntrevista";
            DDLestadoEntrevista.DataValueField = "idEstadoEntrevista";
            DDLestadoEntrevista.DataBind();
            DDLestadoEntrevista.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWAgenda.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("PWSolicitante.aspx");
        }
    }
}