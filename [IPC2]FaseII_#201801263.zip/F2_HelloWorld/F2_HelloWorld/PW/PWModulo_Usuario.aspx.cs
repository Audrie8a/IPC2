﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWModulo_Usuario : System.Web.UI.Page
    {
        GD_Modulo_Usuario Modulo_Usuario = new GD_Modulo_Usuario();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Modulo_Usuario Objeto = new Modulo_Usuario();
                Objeto.IdUsuario= Convert.ToByte(DDLusuario.Text);
                Objeto.IdPagoSus = Convert.ToByte(DDLpagoSus.Text);

                if (DDLusuario.SelectedIndex != 0 && DDLpagoSus.SelectedIndex != 0)
                {
                    bool agregado = Modulo_Usuario.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Modulo_Usuario Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Modulo_Usuario.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte Modulo_Usuario a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    byte idUsuario = Convert.ToByte(DDLusuario.Text);
                    byte idPagosus = Convert.ToByte(DDLpagoSus.Text);

                    Modulo_Usuario.editar(identificacion,idPagosus, idUsuario);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Modulo_Usuario.eliminar(identificacion);
                    lblMensaje.Text = "Modulo_Usuario Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de Modulo_Usuario a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de Modulo_Usuario a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }

        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Modulo_Usuario objeto = Modulo_Usuario.consultar(identificacion);
                if (objeto != null)
                {
                    DDLusuario.Text = Convert.ToString(objeto.IdUsuario);
                    DDLpagoSus.Text = Convert.ToString(objeto.IdPagoSus);
                    lblMensaje.Text = "Modulo_Usuario consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Modulo_Usuario agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de Modulo_Usuario a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Modulo_Usuario> Lista = Modulo_Usuario.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay PModulo_Usuario agregados en la base de datos";
            }
            else
            {
                gvModuloU.DataSource = Lista;
                gvModuloU.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = Modulo_Usuario.Consultar("Select idMOdulo_Usuario from Modulo_Usuario");
            DDLidentificacion.DataTextField = "idMOdulo_Usuario";
            DDLidentificacion.DataValueField = "idMOdulo_Usuario";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLusuario.DataSource = Modulo_Usuario.Consultar("Select idUsuario from Usuario");
            DDLusuario.DataTextField = "idUsuario";
            DDLusuario.DataValueField = "idUsuario";
            DDLusuario.DataBind();
            DDLusuario.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
            //Datos idPresentacionProducto
            DDLpagoSus.DataSource = Modulo_Usuario.Consultar("Select idPagoSuscripcion from PagoSuscripcion");
            DDLpagoSus.DataTextField = "idPagoSuscripcion";
            DDLpagoSus.DataValueField = "idPagoSuscripcion";
            DDLpagoSus.DataBind();
            DDLpagoSus.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }
    }
}