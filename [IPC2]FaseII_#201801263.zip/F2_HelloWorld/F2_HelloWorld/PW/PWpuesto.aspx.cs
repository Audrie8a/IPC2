﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWpuesto : System.Web.UI.Page
    {
        GD_Puesto Puesto = new GD_Puesto();
             
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                Puesto Objeto = new Puesto();
                Objeto.Nombre1 = txtPuesto.Text;

                if (txtPuesto.Text != null)
                {
                    bool agregado = Puesto.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "Puesto Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += Puesto.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte Puesto a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string Puesto1 = txtPuesto.Text;

                    Puesto.editar(identificacion, Puesto1);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    Puesto.eliminar(identificacion);
                    lblMensaje.Text = "Puesto Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación de Puesto a eliminar";
                }
            }


            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación del Puesto a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }


        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                Puesto objeto = Puesto.consultar(identificacion);
                if (objeto != null)
                {
                    txtPuesto.Text = objeto.Nombre1;
                    lblMensaje.Text = "Puesto consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay Puesto agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de Puesto a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<Puesto> Lista = Puesto.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay Puesto agregados en la base de datos";
            }
            else
            {
                gvPuesto.DataSource = Lista;
                gvPuesto.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtPuesto.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = Puesto.Consultar("Select idPuesto from Puesto");
            DDLidentificacion.DataTextField = "idPuesto";
            DDLidentificacion.DataValueField = "idPuesto";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }
    }
}