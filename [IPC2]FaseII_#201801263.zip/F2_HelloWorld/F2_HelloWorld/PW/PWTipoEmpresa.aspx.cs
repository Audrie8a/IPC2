﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace F2_HelloWorld
{
    public partial class PWTipoEmpresa : System.Web.UI.Page
    {
        GD_TipoEmpresa TipoEmpresa = new GD_TipoEmpresa();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IniciarLLenadoDropDownList();
                btnEliminar.Enabled = false;
                btnEditar.Enabled = false;
            }
            lblMensaje.Text = "RESULTADO:  ";
        }

        protected void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                TipoEmpresa Objeto = new TipoEmpresa();
                Objeto.TipoE1 = txtTipoE.Text;

                if (txtTipoE.Text != null)
                {
                    bool agregado = TipoEmpresa.agregar(Objeto);
                    if (agregado)
                    {
                        lblMensaje.Text += "TipoEmpresa Agregado Exitosamente";
                        limpiar();
                        Listar();
                        IniciarLLenadoDropDownList();
                    }
                    else
                    {
                        lblMensaje.Text += TipoEmpresa.error;
                    }
                }
                else
                {
                    lblMensaje.Text += "Favor Llenar todos los datos";
                }
            }         
            catch (Exception)
            {
                lblMensaje.Text += "Favor Llenar todos los datos";
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            Consultar();
            btnEditar.Enabled = true;
            btnEliminar.Enabled = true;
        }

        protected void btnEditar_Click(object sender, EventArgs e)
        {
            if (DDLidentificacion.SelectedIndex == 0)
            {
                lblMensaje.Text += "Favor consulte TipoEmpresa a Editar";
            }
            else
            {
                try
                {
                    byte identificacion = Convert.ToByte(DDLidentificacion.Text);
                    string TipoE = txtTipoE.Text;

                    TipoEmpresa.editar(identificacion, TipoE);
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                catch (Exception ex) { lblMensaje.Text += " " + ex; }
            }
        }

        protected void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (DDLidentificacion.SelectedIndex != 0)
                {
                    int identificacion = Convert.ToInt32(DDLidentificacion.Text);


                    TipoEmpresa.eliminar(identificacion);
                    lblMensaje.Text = "TipoEmpresa Eliminado exitosamente";
                    Listar();
                    IniciarLLenadoDropDownList();
                    limpiar();
                }
                else
                {
                    lblMensaje.Text += "Favor ingresar identificación TipoEmpresa a eliminar";
                }

            }
            catch (Exception) { lblMensaje.Text += "Favor ingresar identificación de TipoEmpresa a eliminar"; }
        }

        protected void btnListar_Click(object sender, EventArgs e)
        {
            Listar();
        }
        
        //Metodo para Consultar 
        public void Consultar()
        {
            try
            {
                int identificacion = Convert.ToInt32(DDLidentificacion.Text);

                TipoEmpresa objeto = TipoEmpresa.consultar(identificacion);
                if (objeto != null)
                {
                    txtTipoE.Text = objeto.TipoE1;
                    lblMensaje.Text = "TipoEmpresa consultado";
                }
                else
                {
                    lblMensaje.Text = "No hay TipoEmpresa agregadas a la base de datos";
                }
            }
            catch (Exception) { lblMensaje.Text += "Favor seleccionar la identificación de TipoEmpresa a buscar"; }
        }

        //Metodo para listaClientes
        public void Listar()
        {
            List<TipoEmpresa> Lista = TipoEmpresa.Listar();
            if (Lista.Count == 0)
            {
                lblMensaje.Text += "No hay TipoEmpresa agregados en la base de datos";
            }
            else
            {
                gvTipoE.DataSource = Lista;
                gvTipoE.DataBind();
            }
        }

        //Método para limpiar
        private void limpiar()
        {
            txtTipoE.Text = "";
            lblMensaje.Text = "RESULTADO: ";
        }

        //Métodos para llenar las DropDownList
        private void IniciarLLenadoDropDownList()
        {
            //Datos idPresentacionProducto
            DDLidentificacion.DataSource = TipoEmpresa.Consultar("Select id_Tipoempresa from TipoEmpresa");
            DDLidentificacion.DataTextField = "id_Tipoempresa";
            DDLidentificacion.DataValueField = "id_Tipoempresa";
            DDLidentificacion.DataBind();
            DDLidentificacion.Items.Insert(0, new ListItem("[Seleccionar identificación]", "0"));
        }
    }
}