﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Bodega
    {
        private byte idBodega;
        private string BodegaN;
        private byte idInventario;

        public Bodega() {
        }
        public Bodega(byte idBodega, string bodegaN, byte idInventario)
        {
            this.idBodega = idBodega;
            BodegaN = bodegaN;
            this.idInventario = idInventario;
        }

        public byte IdBodega { get => idBodega; set => idBodega = value; }
        public string BodegaN1 { get => BodegaN; set => BodegaN = value; }
        public byte IdInventario { get => idInventario; set => idInventario = value; }
    }
}