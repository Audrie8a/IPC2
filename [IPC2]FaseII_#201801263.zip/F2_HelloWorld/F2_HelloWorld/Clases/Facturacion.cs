﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Facturacion
    {
        private byte idFacturacion;
        private byte idClienteE;
        private byte idVendedor;

        public Facturacion() { }
        public Facturacion(byte idFacturacion, byte idClienteE, byte idVendedor)
        {
            this.idFacturacion = idFacturacion;
            this.idClienteE = idClienteE;
            this.idVendedor = idVendedor;
        }

        public byte IdFacturacion { get => idFacturacion; set => idFacturacion = value; }
        public byte IdClienteE { get => idClienteE; set => idClienteE = value; }
        public byte IdVendedor { get => idVendedor; set => idVendedor = value; }
    }
}