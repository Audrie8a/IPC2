﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Entrevista
    {
        private byte idEntrevista;
        private DateTime Fecha;
        private byte idSolicitante;
        private byte idEstadoEntrevista;

        public Entrevista()
        {
        }

        public Entrevista(byte idEntrevista, DateTime fecha, byte idSolicitante, byte idEstadoEntrevista)
        {
            this.idEntrevista = idEntrevista;
            Fecha = fecha;
            this.idSolicitante = idSolicitante;
            this.idEstadoEntrevista = idEstadoEntrevista;
        }

        public byte IdEntrevista { get => idEntrevista; set => idEntrevista = value; }
        public DateTime Fecha1 { get => Fecha; set => Fecha = value; }
        public byte IdSolicitante { get => idSolicitante; set => idSolicitante = value; }
        public byte IdEstadoEntrevista { get => idEstadoEntrevista; set => idEstadoEntrevista = value; }
    }
}