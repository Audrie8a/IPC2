﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class AccesoUsuario
    {
        private byte idAccesoUsuario;
        private byte idPermisoUsuario;
        private byte idUsuario;
        private byte codigoModulo;

        public AccesoUsuario()
        {
        }

        public AccesoUsuario(byte idAccesoUsuario, byte idPermisoUsuario, byte idUsuario, byte codigoModulo)
        {
            this.idAccesoUsuario = idAccesoUsuario;
            this.idPermisoUsuario = idPermisoUsuario;
            this.idUsuario = idUsuario;
            this.codigoModulo = codigoModulo;
        }

        public byte IdAccesoUsuario { get => idAccesoUsuario; set => idAccesoUsuario = value; }
        public byte IdPermisoUsuario { get => idPermisoUsuario; set => idPermisoUsuario = value; }
        public byte IdUsuario { get => idUsuario; set => idUsuario = value; }
        public byte CodigoModulo { get => codigoModulo; set => codigoModulo = value; }
    }
}