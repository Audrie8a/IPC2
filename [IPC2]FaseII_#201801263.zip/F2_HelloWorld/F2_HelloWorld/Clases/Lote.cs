﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Lote
    {
        private byte idLote;
        private string LoteN;
        private byte idTipoLogica;
        private byte idBodega;

        public Lote() {
        }
        public Lote(byte idLote, string loteN, byte idTipoLogica, byte idBodega)
        {
            this.idLote = idLote;
            LoteN = loteN;
            this.idTipoLogica = idTipoLogica;
            this.idBodega = idBodega;
        }

        public byte IdLote { get => idLote; set => idLote = value; }
        public string LoteN1 { get => LoteN; set => LoteN = value; }
        public byte IdTipoLogica { get => idTipoLogica; set => idTipoLogica = value; }
        public byte IdBodega { get => idBodega; set => idBodega = value; }
    }
}