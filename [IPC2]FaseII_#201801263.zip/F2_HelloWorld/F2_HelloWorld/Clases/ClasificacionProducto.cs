﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class ClasificacionProducto
    {
        private byte idClasificacionP;
        private string ClasificacionP;

        public ClasificacionProducto() {
        }
        public ClasificacionProducto(byte idClasificacionP, string clasificacionP)
        {
            this.idClasificacionP = idClasificacionP;
            ClasificacionP = clasificacionP;
        }

        public byte IdClasificacionP { get => idClasificacionP; set => idClasificacionP = value; }
        public string ClasificacionP1 { get => ClasificacionP; set => ClasificacionP = value; }
    }
}