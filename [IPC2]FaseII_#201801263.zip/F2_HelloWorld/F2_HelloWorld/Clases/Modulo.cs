﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Modulo
    {
        private byte codigoModulo;
        private string Nombre;
        private string Abreviatura;
        private string Descripcion;
        private byte idTipoModulo;
        private byte idEstadoModulo;

        public Modulo()
        {
        }

        public Modulo(byte codigoModulo, string nombre, string abreviatura, string descripcion, byte idTipoModulo, byte idEstadoModulo)
        {
            this.codigoModulo = codigoModulo;
            Nombre = nombre;
            Abreviatura = abreviatura;
            Descripcion = descripcion;
            this.idTipoModulo = idTipoModulo;
            this.idEstadoModulo = idEstadoModulo;
        }

        public byte CodigoModulo { get => codigoModulo; set => codigoModulo = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public string Abreviatura1 { get => Abreviatura; set => Abreviatura = value; }
        public string Descripcion1 { get => Descripcion; set => Descripcion = value; }
        public byte IdTipoModulo { get => idTipoModulo; set => idTipoModulo = value; }
        public byte IdEstadoModulo { get => idEstadoModulo; set => idEstadoModulo = value; }
    }
}