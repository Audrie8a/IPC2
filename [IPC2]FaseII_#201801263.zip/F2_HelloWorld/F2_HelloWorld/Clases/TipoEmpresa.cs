﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class TipoEmpresa
    {
        private byte idTipoEmpresa;
        private String TipoE;

        public TipoEmpresa()
        {
        }

        public TipoEmpresa(byte idTipoEmpresa, string tipoE)
        {
            this.idTipoEmpresa = idTipoEmpresa;
            TipoE = tipoE;
        }

        public byte IdTipoEmpresa { get => idTipoEmpresa; set => idTipoEmpresa = value; }
        public string TipoE1 { get => TipoE; set => TipoE = value; }
    }
}