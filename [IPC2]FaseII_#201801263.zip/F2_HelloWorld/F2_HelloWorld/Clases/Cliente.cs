﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Cliente
    {
        private byte idCliente;
        private string NIT;
        private string Nombre;
        private byte id_TipoEmpresa;
        private byte id_TamanoEmpresa;
        private byte id_TarjetaCredito;
        private byte idUsuarioAdministrador;

        public Cliente()
        {
        }

        public Cliente(byte idCliente, string nIT, string nombre, byte id_TipoEmpresa, byte id_TamanoEmpresa, byte id_TarjetaCredito, byte idUsuarioAdministrador)
        {
            this.idCliente = idCliente;
            NIT = nIT;
            Nombre = nombre;
            this.id_TipoEmpresa = id_TipoEmpresa;
            this.id_TamanoEmpresa = id_TamanoEmpresa;
            this.id_TarjetaCredito = id_TarjetaCredito;
            this.idUsuarioAdministrador = idUsuarioAdministrador;
        }

        public byte IdCliente { get => idCliente; set => idCliente = value; }
        public string NIT1 { get => NIT; set => NIT = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public byte Id_TipoEmpresa { get => id_TipoEmpresa; set => id_TipoEmpresa = value; }
        public byte Id_TamanoEmpresa { get => id_TamanoEmpresa; set => id_TamanoEmpresa = value; }
        public byte Id_TarjetaCredito { get => id_TarjetaCredito; set => id_TarjetaCredito = value; }
        public byte IdUsuarioAdministrador { get => idUsuarioAdministrador; set => idUsuarioAdministrador = value; }
    }
}