﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class FacturaProveedor
    {
        private byte numfacturaProveedor;
        private DateTime fechaEmision;
        private byte idProveedorEmpresa;
        private string Serie;
        private int Valor;
        private int impuestos;

        public FacturaProveedor()
        {
        }

        public FacturaProveedor(byte numfacturaProveedor, DateTime fechaEmision, byte idProveedorEmpresa, string serie, int valor, int impuestos)
        {
            this.numfacturaProveedor = numfacturaProveedor;
            this.fechaEmision = fechaEmision;
            this.idProveedorEmpresa = idProveedorEmpresa;
            Serie = serie;
            Valor = valor;
            this.impuestos = impuestos;
        }

        public byte NumfacturaProveedor { get => numfacturaProveedor; set => numfacturaProveedor = value; }
        public DateTime FechaEmision { get => fechaEmision; set => fechaEmision = value; }
        public byte IdProveedorEmpresa { get => idProveedorEmpresa; set => idProveedorEmpresa = value; }
        public string Serie1 { get => Serie; set => Serie = value; }
        public int Valor1 { get => Valor; set => Valor = value; }
        public int Impuestos { get => impuestos; set => impuestos = value; }
    }
}