﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Usuario
    {
        private byte idUsuario;
        private string password;
        private byte idContacto;
        private string Nombre;
        private string Correo;
        private string Celular;
        private string Puesto;
        private byte idTipoUsuario;

        public Usuario()
        {
        }

        public Usuario(byte idUsuario, string password, byte idContacto, string nombre, string correo, string celular, string puesto, byte idTipoUsuario)
        {
            this.idUsuario = idUsuario;
            this.password = password;
            this.idContacto = idContacto;
            Nombre = nombre;
            Correo = correo;
            Celular = celular;
            Puesto = puesto;
            this.idTipoUsuario = idTipoUsuario;
        }

        public byte IdUsuario { get => idUsuario; set => idUsuario = value; }
        public string Password { get => password; set => password = value; }
        public byte IdContacto { get => idContacto; set => idContacto = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public string Correo1 { get => Correo; set => Correo = value; }
        public string Celular1 { get => Celular; set => Celular = value; }
        public string Puesto1 { get => Puesto; set => Puesto = value; }
        public byte IdTipoUsuario { get => idTipoUsuario; set => idTipoUsuario = value; }
    }
}