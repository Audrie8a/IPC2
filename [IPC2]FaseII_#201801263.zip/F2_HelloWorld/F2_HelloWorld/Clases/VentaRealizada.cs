﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class VentaRealizada
    {
        private byte idVentaRealizada;
        private int importeTotalVenta;
        private int Impuesto;
        private DateTime fecha;
        private int ImpuestosDato;
        private byte idFacturacion;
        private byte idCliente;
        private byte idVendedor;

        public VentaRealizada() { }

        public VentaRealizada(byte idVentaRealizada, int importeTotalVenta, int impuesto, DateTime fecha, int impuestosDato, byte idFacturacion, byte idCliente, byte idVendedor)
        {
            this.idVentaRealizada = idVentaRealizada;
            this.importeTotalVenta = importeTotalVenta;
            Impuesto = impuesto;
            this.fecha = fecha;
            ImpuestosDato = impuestosDato;
            this.idFacturacion = idFacturacion;
            this.idCliente = idCliente;
            this.idVendedor = idVendedor;
        }

        public byte IdVentaRealizada { get => idVentaRealizada; set => idVentaRealizada = value; }
        public int ImporteTotalVenta { get => importeTotalVenta; set => importeTotalVenta = value; }
        public int Impuesto1 { get => Impuesto; set => Impuesto = value; }
        public DateTime Fecha { get => fecha; set => fecha = value; }
        public int ImpuestosDato1 { get => ImpuestosDato; set => ImpuestosDato = value; }
        public byte IdFacturacion { get => idFacturacion; set => idFacturacion = value; }
        public byte IdCliente { get => idCliente; set => idCliente = value; }
        public byte IdVendedor { get => idVendedor; set => idVendedor = value; }
    }
}