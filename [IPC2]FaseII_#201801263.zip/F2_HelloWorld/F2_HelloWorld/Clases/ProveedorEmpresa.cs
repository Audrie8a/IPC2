﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class ProveedorEmpresa
    {
        private byte idProveedor;
        private string NIT;
        private string Nombre;
        private string Direccion;
        private string Telefono;
        private string ContactoEncargado;
        private int LimiteCredito;
        private string Correo;
        private byte idestadoProveedor;

        public ProveedorEmpresa() {
        }
        public ProveedorEmpresa(byte idProveedor, string nIT, string nombre, string direccion, string telefono, string contactoEncargado, int limiteCredito, string correo, byte idestadoProveedor)
        {
            this.idProveedor = idProveedor;
            NIT = nIT;
            Nombre = nombre;
            Direccion = direccion;
            Telefono = telefono;
            ContactoEncargado = contactoEncargado;
            LimiteCredito = limiteCredito;
            Correo = correo;
            this.idestadoProveedor = idestadoProveedor;
        }

        public byte IdProveedor { get => idProveedor; set => idProveedor = value; }
        public string NIT1 { get => NIT; set => NIT = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public string Direccion1 { get => Direccion; set => Direccion = value; }
        public string Telefono1 { get => Telefono; set => Telefono = value; }
        public string ContactoEncargado1 { get => ContactoEncargado; set => ContactoEncargado = value; }
        public int LimiteCredito1 { get => LimiteCredito; set => LimiteCredito = value; }
        public string Correo1 { get => Correo; set => Correo = value; }
        public byte IdestadoProveedor { get => idestadoProveedor; set => idestadoProveedor = value; }
    }

}