﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Blog
    {
        private byte idBlog;
        private string Descripcion;

        public Blog()
        {
        }

        public Blog(byte idBlog, string descripcion)
        {
            this.idBlog = idBlog;
            Descripcion = descripcion;
        }

        public byte IdBlog { get => idBlog; set => idBlog = value; }
        public string Descripcion1 { get => Descripcion; set => Descripcion = value; }
    }
}