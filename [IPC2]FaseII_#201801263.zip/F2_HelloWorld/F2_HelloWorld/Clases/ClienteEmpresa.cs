﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class ClienteEmpresa
    {
        private int idClienteE;
        private string NIT;
        private string Nombre;
        private string Direccion;
        private string Telefono;
        private string ContactoEncargado;
        private string Correo;
        private byte CodigoCategoria;
        private int LimiteCredito;
        private byte TiempoCredito;
        private byte EstadoCliente;

        public ClienteEmpresa()
        {

        }

        public ClienteEmpresa(
        int idClienteE, string NIT, string Nombre, string Direccion, string Telefono, string ContactoEncargado, string Correo, byte CodigoCategoria, int LimiteCredito, byte TiempoCredito, byte EstadoCliente)
        {
            this.idClienteE = idClienteE;
            this.NIT = NIT;
            this.Nombre = Nombre;
            this.Direccion = Direccion;
            this.Telefono = Telefono;
            this.ContactoEncargado = ContactoEncargado;
            this.Correo = Correo;
            this.CodigoCategoria = CodigoCategoria;
            this.LimiteCredito = LimiteCredito;
            this.TiempoCredito = TiempoCredito;
            this.EstadoCliente = EstadoCliente;
        }

        public int IdClienteE
         {
             get { return idClienteE; }
             set { idClienteE = value; }
         }
         public string Nit
        {
            get { return NIT; }
            set { NIT = value; }
        }
        public string NOMBRE
        {
            get { return Nombre; }
            set { Nombre = value; }
        }
        public string DIRECCION
        {
            get { return Direccion; }
            set { Direccion = value; }
        }
        public string TELEFONO
        {
            get { return Telefono; }
            set { Telefono = value; }
        }
        public string CONTACTO_ENCARGADO
        {
            get { return ContactoEncargado; }
            set { ContactoEncargado = value; }
        }
        public String CORREO
        {
            get { return Correo; }
            set { Correo = value; }
        }

        public byte CODIGO_CATEGORIA
        {
            get { return CodigoCategoria; }
            set { CodigoCategoria = value; }
        }
        public int LIMITE_CREDITO
        {
            get { return LimiteCredito; }
            set { LimiteCredito = value; }
        }
        public byte TIEMPO_CREDITO
        {
            get { return TiempoCredito; }
            set { TiempoCredito = value; }
        }
        public byte ESTADO_CLIENTE
        {
            get { return EstadoCliente; }
            set { EstadoCliente = value; }
        }
        
    }
}