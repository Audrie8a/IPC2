﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class ListaPrecio
    {
        private byte idListaPrecio;
        private DateTime fechaIni;
        private DateTime fechaFin;
        private int CambioDolarQuetzal;

        public ListaPrecio()
        {
        }

        public ListaPrecio(byte idListaPrecio, DateTime fechaIni, DateTime fechaFin, int cambioDolarQuetzal)
        {
            this.idListaPrecio = idListaPrecio;
            this.fechaIni = fechaIni;
            this.fechaFin = fechaFin;
            CambioDolarQuetzal = cambioDolarQuetzal;
        }

        public byte IdListaPrecio { get => idListaPrecio; set => idListaPrecio = value; }
        public DateTime FechaIni { get => fechaIni; set => fechaIni = value; }
        public DateTime FechaFin { get => fechaFin; set => fechaFin = value; }
        public int CambioDolarQuetzal1 { get => CambioDolarQuetzal; set => CambioDolarQuetzal = value; }
    }
}