﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class ProductoEmpresa
    {
        private byte codigoProducto;
        private string codigoBarra;
        private string Nombre;
        private string Descripcion;
        private byte idPresentacionproducto;
        private byte idclasificacionProducto;
        private byte ideEstadoProducto;
        private int Precio;

        public ProductoEmpresa() {
        }
        public ProductoEmpresa(byte codigoProducto, string codigoBarra, string nombre, string descripcion, byte idPresentacionproducto, byte idclasificacionProducto, byte ideEstadoProducto, int precio)
        {
            this.codigoProducto = codigoProducto;
            this.codigoBarra = codigoBarra;
            Nombre = nombre;
            Descripcion = descripcion;
            this.idPresentacionproducto = idPresentacionproducto;
            this.idclasificacionProducto = idclasificacionProducto;
            this.ideEstadoProducto = ideEstadoProducto;
            Precio = precio;
        }

        public byte CodigoProducto { get => codigoProducto; set => codigoProducto = value; }
        public string CodigoBarra { get => codigoBarra; set => codigoBarra = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public string Descripcion1 { get => Descripcion; set => Descripcion = value; }
        public byte IdPresentacionproducto { get => idPresentacionproducto; set => idPresentacionproducto = value; }
        public byte IdclasificacionProducto { get => idclasificacionProducto; set => idclasificacionProducto = value; }
        public byte IdeEstadoProducto { get => ideEstadoProducto; set => ideEstadoProducto = value; }
        public int Precio1 { get => Precio; set => Precio = value; }
    }
}