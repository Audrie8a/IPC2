﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Producto_Lote
    {
        private byte idProducto_Lote;
        private byte idInventario;
        private byte idBodega;
        private byte idLote;
        private byte codigoProducto;
        private string Producto;
        private int cantidadProducto;

        public Producto_Lote() { }

        public Producto_Lote(byte idProducto_Lote, byte idInventario, byte idBodega, byte idLote, byte codigoProducto, string producto, int cantidadProducto)
        {
            this.idProducto_Lote = idProducto_Lote;
            this.idInventario = idInventario;
            this.idBodega = idBodega;
            this.idLote = idLote;
            this.codigoProducto = codigoProducto;
            Producto = producto;
            this.cantidadProducto = cantidadProducto;
        }

        public byte IdProducto_Lote { get => idProducto_Lote; set => idProducto_Lote = value; }
        public byte IdInventario { get => idInventario; set => idInventario = value; }
        public byte IdBodega { get => idBodega; set => idBodega = value; }
        public byte IdLote { get => idLote; set => idLote = value; }
        public byte CodigoProducto { get => codigoProducto; set => codigoProducto = value; }
        public string Producto1 { get => Producto; set => Producto = value; }
        public int CantidadProducto { get => cantidadProducto; set => cantidadProducto = value; }
    }
}