﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class VentaProducto
    {
        private byte idVentaProducto;
        private byte idFacturacion;
        private byte codigoProducto;
        private int cantidad;
        private int Pago;

        public VentaProducto() { }
        public VentaProducto(byte idVentaProducto, byte idFacturacion, byte codigoProducto, int cantidad, int pago)
        {
            this.idVentaProducto = idVentaProducto;
            this.idFacturacion = idFacturacion;
            this.codigoProducto = codigoProducto;
            this.cantidad = cantidad;
            Pago = pago;
        }

        public byte IdVentaProducto { get => idVentaProducto; set => idVentaProducto = value; }
        public byte IdFacturacion { get => idFacturacion; set => idFacturacion = value; }
        public byte CodigoProducto { get => codigoProducto; set => codigoProducto = value; }
        public int Cantidad { get => cantidad; set => cantidad = value; }
        public int Pago1 { get => Pago; set => Pago = value; }
    }
}