﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class CategoriaCliente
    {
        private byte codigoCategoria;
        private string Abreviatura;
        private string Descripcion;

        public CategoriaCliente() {

        }

        public CategoriaCliente(byte codigoCategoria, string Abreviatura, string Descripcion)
        {
            this.codigoCategoria = codigoCategoria;
            this.Abreviatura = Abreviatura;
            this.Descripcion = Descripcion;
        }

        public byte CodigoCategoria { get => codigoCategoria; set => codigoCategoria = value; }
        public string Abreviatura1 { get => Abreviatura; set => Abreviatura = value; }
        public string Descripcion1 { get => Descripcion; set => Descripcion = value; }
    }
}