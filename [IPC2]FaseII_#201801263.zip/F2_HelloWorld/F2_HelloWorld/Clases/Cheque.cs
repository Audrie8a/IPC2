﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Cheque
    {
        private byte numCheque;
        private string Banco;
        private string cuentaBanco;
        private byte idEmpleado;

        public Cheque()
        {
        }

        public Cheque(byte numCheque, string banco, string cuentaBanco, byte idEmpleado)
        {
            this.numCheque = numCheque;
            Banco = banco;
            this.cuentaBanco = cuentaBanco;
            this.idEmpleado = idEmpleado;
        }

        public byte NumCheque { get => numCheque; set => numCheque = value; }
        public string Banco1 { get => Banco; set => Banco = value; }
        public string CuentaBanco { get => cuentaBanco; set => cuentaBanco = value; }
        public byte IdEmpleado { get => idEmpleado; set => idEmpleado = value; }
    }
}