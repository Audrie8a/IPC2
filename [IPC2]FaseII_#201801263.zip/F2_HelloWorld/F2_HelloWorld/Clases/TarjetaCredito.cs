﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class TarjetaCredito
    {
        private byte numTarjeta;
        private string Nombre;
        private DateTime fechaV;
        private byte idTipoTarjeta;
        private string CRV;

        public TarjetaCredito()
        {
        }

        public TarjetaCredito(byte numTarjeta, string nombre, DateTime fechaV, byte idTipoTarjeta, string cRV)
        {
            this.numTarjeta = numTarjeta;
            Nombre = nombre;
            this.fechaV = fechaV;
            this.idTipoTarjeta = idTipoTarjeta;
            CRV = cRV;
        }

        public byte NumTarjeta { get => numTarjeta; set => numTarjeta = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public DateTime FechaV { get => fechaV; set => fechaV = value; }
        public byte IdTipoTarjeta { get => idTipoTarjeta; set => idTipoTarjeta = value; }
        public string CRV1 { get => CRV; set => CRV = value; }
    }
}