﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Comentario
    {
        private byte idComentario;
        private string Ccomentario;
        private string Autro;
        private byte idAnuncio;
        private string Anuncio;
        private byte idBlog;
        private string Blog;

        public Comentario()
        {
        }

        public Comentario(byte idComentario, string ccomentario, string autro, byte idAnuncio, string anuncio, byte idBlog, string blog)
        {
            this.idComentario = idComentario;
            Ccomentario = ccomentario;
            Autro = autro;
            this.idAnuncio = idAnuncio;
            Anuncio = anuncio;
            this.idBlog = idBlog;
            Blog = blog;
        }

        public byte IdComentario { get => idComentario; set => idComentario = value; }
        public string Ccomentario1 { get => Ccomentario; set => Ccomentario = value; }
        public string Autro1 { get => Autro; set => Autro = value; }
        public byte IdAnuncio { get => idAnuncio; set => idAnuncio = value; }
        public string Anuncio1 { get => Anuncio; set => Anuncio = value; }
        public byte IdBlog { get => idBlog; set => idBlog = value; }
        public string Blog1 { get => Blog; set => Blog = value; }
    }
}