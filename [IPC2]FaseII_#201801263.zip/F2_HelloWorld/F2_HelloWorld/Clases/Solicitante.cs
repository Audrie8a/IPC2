﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace F2_HelloWorld
{
    public class Solicitante
    {
        private byte idsolicitante;
        private string Nombre;
        private string Descripcion;

        public Solicitante()
        {
        }

        public Solicitante(byte idsolicitante, string nombre, string descripcion)
        {
            this.idsolicitante = idsolicitante;
            Nombre = nombre;
            Descripcion = descripcion;
        }

        public byte Idsolicitante { get => idsolicitante; set => idsolicitante = value; }
        public string Nombre1 { get => Nombre; set => Nombre = value; }
        public string Descripcion1 { get => Descripcion; set => Descripcion = value; }
    }
}