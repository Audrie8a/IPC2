﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace F2_HelloWorld
{
    public class GD_Login
    {
        public SqlConnection conexion;
        public string error;

        public GD_Login() {
            this.conexion = Conexion.getConexion(); //Estableciendo la conexion
        }

        public int validar_usuario(string usuario, string contra)
        {

            int id = -1;
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select idUsuario, Password  from Usuario as U";
            SqlDataReader registro = comando.ExecuteReader();



            while (registro.Read())
            {
                byte Usuario = registro.GetByte(0);
                string Contrasena = registro.GetString(1);
                if ( Usuario== Convert.ToByte(usuario) && Contrasena == contra)

                {

                    id = 0;
                }
            }
            registro.Close();
            return id;

        }

        public byte determinarTipoUsuario(byte idUsuario) {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select idTipoUsuario from  Usuario where idUsuario=@Id";
            comando.Parameters.AddWithValue("@Id", idUsuario);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {                
                byte idTipoUsuario= registro.GetByte(0);                
                registro.Close();
                return idTipoUsuario;

            }
            else
            {
                registro.Close();
                return 0;
            }


        }

        public byte determinarTipoContacto(byte idUsuario) {
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            comando.CommandText = "select C.idTipoContacto from Usuario as U, Contacto as C where U.idUsuario=@ID and U.idContacto=C.idContacto";
            comando.Parameters.AddWithValue("@ID", idUsuario);
            SqlDataReader registro = comando.ExecuteReader();
            comando.Parameters.Clear();
            if (registro.Read())
            {
                byte idTipoContacto = registro.GetByte(0);
                registro.Close();
                return idTipoContacto;

            }
            else
            {
                registro.Close();
                return 0;
            }
        }
    }
}